import { execFile } from 'child_process';
import express from 'express';
import http from 'http';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type RoomMode = 'coop' | 'competitive' | 'arena';
type RoomStatus = 'waiting' | 'playing' | 'finished';

interface RoomPlayer {
  id: string;
  displayName: string;
  weapon: string;
  skin: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  action: string;
  hp: number;
  maxHp: number;
  score: number;
  progress: number;
  ready: boolean;
  finished: boolean;
  finishTimeMs: number | null;
  aimAngle?: number;
  jetpackActive?: boolean;
  kills?: number;
  deaths?: number;
  arenaGun?: string;
  alive?: boolean;
}

interface MultiplayerRoom {
  code: string;
  hostId: string;
  mode: RoomMode;
  stageId: string;
  status: RoomStatus;
  bossHp: number;
  bossMaxHp: number;
  startTimeMs: number | null;
  winnerId: string | null;
  players: Map<string, RoomPlayer>;
  sockets: Map<string, WebSocket>;
}

const rooms = new Map<string, MultiplayerRoom>();

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? generateRoomCode() : code;
}

function serializeRoom(room: MultiplayerRoom) {
  return {
    code: room.code,
    hostId: room.hostId,
    mode: room.mode,
    stageId: room.stageId,
    status: room.status,
    bossHp: room.bossHp,
    bossMaxHp: room.bossMaxHp,
    startTimeMs: room.startTimeMs,
    winnerId: room.winnerId,
    players: Array.from(room.players.values()),
  };
}

function broadcastToRoom(room: MultiplayerRoom, payload: unknown, excludePlayerId?: string) {
  const raw = JSON.stringify(payload);
  for (const [pid, socket] of room.sockets.entries()) {
    if (excludePlayerId && pid === excludePlayerId) continue;
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(raw);
    }
  }
}

function getBossHpForStage(stageId: string): number {
  switch (stageId) {
    case '1':
      return 480;
    case '2':
      return 640;
    case '3':
      return 820;
    case '4':
      return 1020;
    case '5':
      return 1350;
    case 'seasonal':
      return 1150;
    default:
      return 600;
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeRooms: rooms.size });
  });

  if (process.env.NODE_ENV !== 'production') {
    app.get('/api/download-project', (_req, res) => {
      const outZip = path.join(os.tmpdir(), 'moonlit-shadows-app.zip');
      const pyScript = [
        'import os, sys, zipfile',
        'root, out = sys.argv[1], sys.argv[2]',
        'skip_dirs = {"node_modules", "dist", ".aistudio", ".git"}',
        'skip_files = {".env"}',
        'with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:',
        '  for dirpath, dirnames, filenames in os.walk(root):',
        '    dirnames[:] = [d for d in dirnames if d not in skip_dirs]',
        '    for fn in filenames:',
        '      if fn in skip_files or fn.endswith(".zip") or fn.endswith(".tar.gz"):',
        '        continue',
        '      full = os.path.join(dirpath, fn)',
        '      rel = os.path.relpath(full, root)',
        '      zf.write(full, rel)',
      ].join('\n');

      execFile('python3', ['-c', pyScript, __dirname, outZip], (err) => {
        if (err) {
          res.status(500).json({ error: 'Failed to package project archive' });
          return;
        }
        res.download(outZip, 'moonlit-shadows-app.zip');
      });
    });
  }

  app.get('/api/updates', (_req, res) => {
    res.json({
      version: '1.4.0',
      releases: [
        {
          version: '1.4.0',
          date: '2026-11-12',
          titleAr: 'موسم كسوف القمر القرمزي',
          titleEn: 'Crimson Lunar Eclipse Season',
          notesAr: [
            'إضافة تحدي كسوف القمر مع مضاعفة الجواهر ونقاط الخبرة.',
            'إطلاق سلاح السيف القمري العظيم (Odachi) بضربة الكسوف الأرضية.',
            'دعم الغرف الجماعية التعاونية والتنافسية عبر رمز الغرفة.',
          ],
          notesEn: [
            'Added Crimson Lunar Eclipse seasonal gauntlet with bonus gems & XP.',
            'Released the Lunar Odachi greatsword with Eclipse Slam skill.',
            'Launched Co-op and Competitive online rooms via invite codes.',
          ],
        },
        {
          version: '1.3.0',
          date: '2026-10-28',
          titleAr: 'ترقية فيزياء الوشاح والتحكم باللمس',
          titleEn: 'Cloth Scarf Physics & Mobile Touch Overhaul',
          notesAr: [
            'محاكاة فيزيائية حية لوشاح النينجا عند القفز والاندفاع السريع.',
            'تحسين أزرار اللمس المتعدد للهواتف الذكية.',
          ],
          notesEn: [
            'Live Verlet cloth simulation for the shinobi scarf on jumps and dashes.',
            'Ergonomic multi-touch mobile controls overhaul.',
          ],
        },
      ],
    });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    let currentRoomCode: string | null = null;
    let currentPlayerId: string | null = null;

    const leaveCurrentRoom = () => {
      if (!currentRoomCode || !currentPlayerId) return;
      const room = rooms.get(currentRoomCode);
      if (!room) return;

      room.players.delete(currentPlayerId);
      room.sockets.delete(currentPlayerId);

      if (room.players.size === 0) {
        rooms.delete(currentRoomCode);
      } else {
        if (room.hostId === currentPlayerId) {
          const nextHost = room.players.keys().next().value;
          if (nextHost) {
            room.hostId = nextHost;
          }
        }
        broadcastToRoom(room, {
          type: 'room_state',
          room: serializeRoom(room),
        });
      }
      currentRoomCode = null;
      currentPlayerId = null;
    };

    ws.on('message', (data) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'create_room') {
        leaveCurrentRoom();
        const code = generateRoomCode();
        const playerId = String(msg.playerId || `ninja_${Math.random().toString(36).slice(2, 8)}`);
        const displayName = String(msg.displayName || 'Shinobi').slice(0, 32);
        const mode: RoomMode =
          msg.mode === 'competitive'
            ? 'competitive'
            : msg.mode === 'arena'
            ? 'arena'
            : 'coop';
        const stageId = String(msg.stageId || '1');
        const weapon = String(msg.weapon || 'katana');
        const skin = String(msg.skin || 'obsidian');
        const bossMaxHp = getBossHpForStage(stageId);

        const room: MultiplayerRoom = {
          code,
          hostId: playerId,
          mode,
          stageId,
          status: 'waiting',
          bossHp: bossMaxHp,
          bossMaxHp,
          startTimeMs: null,
          winnerId: null,
          players: new Map(),
          sockets: new Map(),
        };

        room.players.set(playerId, {
          id: playerId,
          displayName,
          weapon,
          skin,
          x: mode === 'arena' ? 420 : 120,
          y: mode === 'arena' ? 680 : 300,
          vx: 0,
          vy: 0,
          facing: 1,
          action: 'idle',
          hp: 100,
          maxHp: 100,
          score: 0,
          progress: 0,
          ready: true,
          finished: false,
          finishTimeMs: null,
          aimAngle: 0,
          jetpackActive: false,
          kills: 0,
          deaths: 0,
          arenaGun: 'shuriken_smg',
          alive: true,
        });
        room.sockets.set(playerId, ws);
        rooms.set(code, room);

        currentRoomCode = code;
        currentPlayerId = playerId;

        ws.send(JSON.stringify({ type: 'room_joined', playerId, room: serializeRoom(room) }));
        return;
      }

      if (type === 'join_room') {
        leaveCurrentRoom();
        const code = String(msg.code || '').trim().toUpperCase();
        const room = rooms.get(code);
        if (!room) {
          ws.send(JSON.stringify({ type: 'room_error', code: 'NOT_FOUND' }));
          return;
        }
        if (room.players.size >= 4) {
          ws.send(JSON.stringify({ type: 'room_error', code: 'ROOM_FULL' }));
          return;
        }

        const playerId = String(msg.playerId || `ninja_${Math.random().toString(36).slice(2, 8)}`);
        const displayName = String(msg.displayName || 'Shinobi').slice(0, 32);
        const weapon = String(msg.weapon || 'katana');
        const skin = String(msg.skin || 'obsidian');

        room.players.set(playerId, {
          id: playerId,
          displayName,
          weapon,
          skin,
          x: 160,
          y: 300,
          vx: 0,
          vy: 0,
          facing: 1,
          action: 'idle',
          hp: 100,
          maxHp: 100,
          score: 0,
          progress: 0,
          ready: true,
          finished: false,
          finishTimeMs: null,
          aimAngle: 0,
          jetpackActive: false,
          kills: 0,
          deaths: 0,
          arenaGun: 'shuriken_smg',
          alive: true,
        });
        room.sockets.set(playerId, ws);

        currentRoomCode = code;
        currentPlayerId = playerId;

        ws.send(JSON.stringify({ type: 'room_joined', playerId, room: serializeRoom(room) }));
        broadcastToRoom(room, { type: 'room_state', room: serializeRoom(room) }, playerId);
        return;
      }

      if (!currentRoomCode || !currentPlayerId) return;
      const room = rooms.get(currentRoomCode);
      if (!room) return;

      if (type === 'update_room_settings' && room.hostId === currentPlayerId && room.status === 'waiting') {
        if (msg.mode === 'coop' || msg.mode === 'competitive' || msg.mode === 'arena') {
          room.mode = msg.mode;
        }
        if (typeof msg.stageId === 'string') {
          room.stageId = msg.stageId;
          room.bossMaxHp = getBossHpForStage(room.stageId);
          room.bossHp = room.bossMaxHp;
        }
        broadcastToRoom(room, { type: 'room_state', room: serializeRoom(room) });
        return;
      }

      if (type === 'start_match' && room.hostId === currentPlayerId) {
        room.status = 'playing';
        room.bossMaxHp = getBossHpForStage(room.stageId);
        room.bossHp = room.bossMaxHp;
        room.startTimeMs = Date.now();
        room.winnerId = null;
        for (const p of room.players.values()) {
          p.finished = false;
          p.finishTimeMs = null;
          p.score = 0;
          p.progress = 0;
          p.hp = p.maxHp;
          p.kills = 0;
          p.deaths = 0;
          p.alive = true;
        }
        broadcastToRoom(room, { type: 'match_started', room: serializeRoom(room) });
        return;
      }

      if (type === 'player_state') {
        const player = room.players.get(currentPlayerId);
        if (!player) return;
        player.x = Number(msg.x) || 0;
        player.y = Number(msg.y) || 0;
        player.vx = Number(msg.vx) || 0;
        player.vy = Number(msg.vy) || 0;
        player.facing = Number(msg.facing) >= 0 ? 1 : -1;
        player.action = String(msg.action || 'idle').slice(0, 20);
        player.weapon = String(msg.weapon || player.weapon);
        player.skin = String(msg.skin || player.skin);
        player.hp = Math.max(0, Number(msg.hp) || 0);
        player.maxHp = Math.max(1, Number(msg.maxHp) || 100);
        player.score = Math.max(0, Number(msg.score) || 0);
        player.progress = Math.max(0, Math.min(100, Number(msg.progress) || 0));
        if (typeof msg.aimAngle === 'number') player.aimAngle = msg.aimAngle;
        if (typeof msg.jetpackActive === 'boolean') player.jetpackActive = msg.jetpackActive;
        if (typeof msg.arenaGun === 'string') player.arenaGun = msg.arenaGun.slice(0, 24);
        if (typeof msg.alive === 'boolean') player.alive = msg.alive;

        broadcastToRoom(
          room,
          {
            type: 'peer_state',
            player,
          },
          currentPlayerId
        );
        return;
      }

      if (type === 'boss_damage' && room.status === 'playing') {
        const dmg = Math.max(0, Math.min(250, Number(msg.damage) || 0));
        if (room.mode === 'coop') {
          room.bossHp = Math.max(0, room.bossHp - dmg);
          broadcastToRoom(room, {
            type: 'boss_sync',
            bossHp: room.bossHp,
            bossMaxHp: room.bossMaxHp,
            attackerId: currentPlayerId,
          });
          if (room.bossHp <= 0) {
            room.status = 'finished';
            room.winnerId = currentPlayerId;
            broadcastToRoom(room, {
              type: 'match_victory',
              mode: room.mode,
              winnerId: currentPlayerId,
              elapsedMs: room.startTimeMs ? Date.now() - room.startTimeMs : 0,
              room: serializeRoom(room),
            });
          }
        }
        return;
      }

      if (type === 'pvp_slash' && room.status === 'playing' && room.mode === 'competitive') {
        const targetId = String(msg.targetId || '');
        const dmg = Math.max(0, Math.min(80, Number(msg.damage) || 0));
        if (targetId && targetId !== currentPlayerId && room.players.has(targetId)) {
          broadcastToRoom(room, {
            type: 'pvp_hit',
            attackerId: currentPlayerId,
            targetId,
            damage: dmg,
          });
        }
        return;
      }

      if (type === 'arena_shot' && room.status === 'playing' && room.mode === 'arena') {
        broadcastToRoom(
          room,
          {
            type: 'arena_shot',
            shooterId: currentPlayerId,
            x: Number(msg.x) || 0,
            y: Number(msg.y) || 0,
            angle: Number(msg.angle) || 0,
            gunId: String(msg.gunId || 'shuriken_smg'),
          },
          currentPlayerId
        );
        return;
      }

      if (type === 'arena_grenade' && room.status === 'playing' && room.mode === 'arena') {
        broadcastToRoom(
          room,
          {
            type: 'arena_grenade',
            throwerId: currentPlayerId,
            x: Number(msg.x) || 0,
            y: Number(msg.y) || 0,
            vx: Number(msg.vx) || 0,
            vy: Number(msg.vy) || 0,
          },
          currentPlayerId
        );
        return;
      }

      if (type === 'arena_hit' && room.status === 'playing' && room.mode === 'arena') {
        const targetId = String(msg.targetId || '');
        const dmg = Math.max(0, Math.min(120, Number(msg.damage) || 0));
        if (targetId && targetId !== currentPlayerId && room.players.has(targetId)) {
          broadcastToRoom(room, {
            type: 'arena_hit',
            attackerId: currentPlayerId,
            targetId,
            damage: dmg,
            weaponLabel: String(msg.weaponLabel || 'Shuriken'),
          });
        }
        return;
      }

      if (type === 'arena_kill' && room.status === 'playing' && room.mode === 'arena') {
        const ARENA_KILL_TARGET = 10;
        const killerId = String(msg.killerId || '');
        const weaponLabel = String(msg.weaponLabel || 'Shuriken').slice(0, 32);
        const victim = room.players.get(currentPlayerId);
        const killer = room.players.get(killerId);
        if (victim) {
          victim.deaths = (victim.deaths || 0) + 1;
          victim.alive = false;
        }
        if (killer && killerId !== currentPlayerId) {
          killer.kills = (killer.kills || 0) + 1;
          killer.score = killer.kills * 150;
        }
        const droppedGun = String(msg.droppedGun || victim?.arenaGun || 'shuriken_smg');
        broadcastToRoom(room, {
          type: 'arena_kill',
          killerId,
          killerName: killer?.displayName || 'Shinobi',
          victimId: currentPlayerId,
          victimName: victim?.displayName || 'Shinobi',
          weaponLabel,
          droppedGun,
          victimX: victim?.x || 1200,
          victimY: victim?.y || 900,
          room: serializeRoom(room),
        });

        if (killer && (killer.kills || 0) >= ARENA_KILL_TARGET && room.status === 'playing') {
          room.status = 'finished';
          room.winnerId = killer.id;
          broadcastToRoom(room, {
            type: 'match_victory',
            mode: 'arena',
            winnerId: killer.id,
            winReason: 'target_reached',
            elapsedMs: room.startTimeMs ? Date.now() - room.startTimeMs : 0,
            room: serializeRoom(room),
          });
        }
        return;
      }

      if (type === 'arena_finish' && room.status === 'playing' && room.mode === 'arena') {
        const sorted = Array.from(room.players.values()).sort(
          (a, b) => (b.kills || 0) - (a.kills || 0) || (a.deaths || 0) - (b.deaths || 0)
        );
        const winner = sorted[0];
        room.status = 'finished';
        room.winnerId = winner?.id || currentPlayerId;
        broadcastToRoom(room, {
          type: 'match_victory',
          mode: 'arena',
          winnerId: room.winnerId,
          winReason: 'time_up',
          elapsedMs: room.startTimeMs ? Date.now() - room.startTimeMs : 120000,
          room: serializeRoom(room),
        });
        return;
      }

      if (type === 'stage_finished' && room.status === 'playing') {
        const player = room.players.get(currentPlayerId);
        if (!player) return;
        player.finished = true;
        player.finishTimeMs = room.startTimeMs ? Date.now() - room.startTimeMs : 0;
        player.score = Math.max(player.score, Number(msg.score) || 0);

        if (!room.winnerId) {
          room.winnerId = currentPlayerId;
          room.status = 'finished';
          broadcastToRoom(room, {
            type: 'match_victory',
            mode: room.mode,
            winnerId: currentPlayerId,
            elapsedMs: player.finishTimeMs,
            room: serializeRoom(room),
          });
        }
        return;
      }

      if (type === 'leave_room') {
        leaveCurrentRoom();
      }
    });

    ws.on('close', () => {
      leaveCurrentRoom();
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Moonlit Shadows server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
