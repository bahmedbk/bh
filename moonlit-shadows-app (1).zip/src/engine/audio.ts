import type { GameSettings, WeaponId } from '../types/game';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxVolume = 0.9;
  private sfxMuted = false;
  private musicVolume = 0.75;
  private musicMuted = false;

  // High-energy Japanese battle music sequencer state
  private musicDesired = false;
  private musicTimerId: number | null = null;
  private musicStep = 0;

  // 20-second cinematic 3D story cutscene music state
  private cutsceneDesired = false;
  private cutsceneTimerId: number | null = null;
  private cutsceneStep = 0;

  // Calm & motivating tactical Arena mountain music state
  private arenaDesired = false;
  private arenaTimerId: number | null = null;
  private arenaStep = 0;

  private getEffectiveSfxGain(): number {
    return this.sfxMuted ? 0 : Math.max(0, Math.min(1, this.sfxVolume)) * 0.95;
  }

  private getEffectiveMusicGain(): number {
    return this.musicMuted ? 0 : Math.max(0, Math.min(1, this.musicVolume)) * 0.36;
  }

  private syncBusGains() {
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setTargetAtTime(this.getEffectiveSfxGain(), this.ctx.currentTime, 0.03);
    }
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(this.getEffectiveMusicGain(), this.ctx.currentTime, 0.04);
    }
  }

  private syncMusicPlayback() {
    if (this.musicMuted || this.musicVolume <= 0.001) {
      this.clearMusicInterval();
      this.clearCutsceneInterval();
      this.clearArenaInterval();
    } else if (this.cutsceneDesired && this.cutsceneTimerId === null) {
      this.startCutsceneLoop();
    } else if (this.arenaDesired && this.arenaTimerId === null) {
      this.startArenaLoop();
    } else if (this.musicDesired && this.musicTimerId === null) {
      this.startMusicLoop();
    }
  }

  public applySettings(
    settings: Pick<GameSettings, 'sfxVolume' | 'sfxMuted' | 'musicVolume' | 'musicMuted'>
  ) {
    this.sfxVolume = Math.max(0, Math.min(1, settings.sfxVolume));
    this.sfxMuted = settings.sfxMuted;
    this.musicVolume = Math.max(0, Math.min(1, settings.musicVolume));
    this.musicMuted = settings.musicMuted;
    this.syncBusGains();
    this.syncMusicPlayback();
  }

  public setSfxVolume(volume: number) {
    this.sfxVolume = Math.max(0, Math.min(1, volume));
    this.syncBusGains();
  }

  public setSfxMuted(muted: boolean) {
    this.sfxMuted = muted;
    this.syncBusGains();
  }

  public setMusicVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    this.syncBusGains();
    this.syncMusicPlayback();
  }

  public setMusicMuted(muted: boolean) {
    this.musicMuted = muted;
    this.syncBusGains();
    this.syncMusicPlayback();
  }

  public setMuted(muted: boolean) {
    this.sfxMuted = muted;
    this.musicMuted = muted;
    this.syncBusGains();
    this.syncMusicPlayback();
  }

  public isMuted(): boolean {
    return this.sfxMuted && this.musicMuted;
  }

  public isMusicActive(): boolean {
    return !this.musicMuted && this.musicVolume > 0.001;
  }

  public isSfxActive(): boolean {
    return !this.sfxMuted && this.sfxVolume > 0.001;
  }

  public isAudioSuspended(): boolean {
    return (this.isMusicActive() || this.isSfxActive()) && (!this.ctx || this.ctx.state === 'suspended');
  }

  public async unlockAudio(): Promise<boolean> {
    if (!this.isMusicActive() && !this.isSfxActive()) return false;
    const ctx = this.ensureContext();
    if (!ctx) return false;
    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        return false;
      }
    }
    if (ctx.state === 'running') {
      this.syncMusicPlayback();
      return true;
    }
    return false;
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.isMusicActive() && !this.isSfxActive()) return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.getEffectiveSfxGain();
      this.sfxGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.getEffectiveMusicGain();
      this.musicGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx
        .resume()
        .then(() => {
          if (this.ctx?.state === 'running') {
            this.syncMusicPlayback();
          }
        })
        .catch(() => {
          // Ignore autoplay restriction until first user interaction
        });
    }
    return this.ctx;
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainPeak = 0.14,
    toMusicBus = false,
    delaySec = 0
  ) {
    if (toMusicBus && !this.isMusicActive()) return;
    if (!toMusicBus && !this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const dest = toMusicBus ? this.musicGain || ctx.destination : this.sfxGain || ctx.destination;
    const now = ctx.currentTime + delaySec;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freqStart), now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + duration);

    gain.gain.setValueAtTime(0.0008, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + duration);

    osc.connect(gain);
    gain.connect(dest);
    osc.start(now);
    osc.stop(now + duration + 0.025);
  }

  private playFilteredNoise(
    duration: number,
    freqStart: number,
    freqEnd: number,
    gainPeak = 0.16,
    q = 1.8,
    filterType: BiquadFilterType = 'bandpass',
    toMusicBus = false
  ) {
    if (toMusicBus && !this.isMusicActive()) return;
    if (!toMusicBus && !this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const dest = toMusicBus ? this.musicGain || ctx.destination : this.sfxGain || ctx.destination;
    const now = ctx.currentTime;
    const bufferSize = Math.max(128, Math.floor(ctx.sampleRate * duration));
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(freqStart, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(60, freqEnd), now + duration);
    filter.Q.value = q;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(gainPeak, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(dest);
    noise.start(now);
  }

  // Dramatic 20-Second Japanese Orchestral / Shakuhachi Story Cutscene Score
  public startCutsceneMusic() {
    this.stopBattleMusic();
    this.cutsceneDesired = true;
    const ctx = this.ensureContext();
    if (!ctx || !this.isMusicActive()) return;
    if (this.cutsceneTimerId === null) {
      this.startCutsceneLoop();
    }
  }

  public stopCutsceneMusic() {
    this.cutsceneDesired = false;
    this.clearCutsceneInterval();
  }

  private clearCutsceneInterval() {
    if (this.cutsceneTimerId !== null) {
      window.clearInterval(this.cutsceneTimerId);
      this.cutsceneTimerId = null;
    }
  }

  private startCutsceneLoop() {
    if (typeof window === 'undefined' || !this.isMusicActive()) return;
    this.clearCutsceneInterval();
    this.cutsceneStep = 0;

    // 250ms per step => 80 steps = 20 seconds of evolving dramatic story music
    const fluteNotes = [
      293.66, 0, 0, 349.23, 392.0, 0, 440.0, 0,
      392.0, 0, 311.13, 0, 293.66, 0, 0, 0,
      440.0, 0, 466.16, 0, 587.33, 0, 523.25, 0,
      440.0, 392.0, 349.23, 0, 392.0, 440.0, 587.33, 0,
    ];
    const celloDrones = [73.42, 73.42, 77.78, 87.31, 98.0, 82.41, 73.42, 110.0];

    this.cutsceneTimerId = window.setInterval(() => {
      if (!this.isMusicActive() || !this.cutsceneDesired) return;
      const ctx = this.ctx;
      if (!ctx || ctx.state !== 'running') return;

      const s = this.cutsceneStep;
      this.cutsceneStep++;
      const act = Math.min(3, Math.floor(s / 20)); // 4 acts across 20 seconds

      // Deep cinematic drone swell every 8 steps
      if (s % 8 === 0) {
        const drone = celloDrones[Math.floor(s / 8) % celloDrones.length];
        this.playTone(drone, drone * 0.995, 1.9, 'sawtooth', 0.08 + act * 0.015, true);
        this.playTone(drone * 2, drone * 2, 1.7, 'triangle', 0.07, true);
      }

      // Haunting Shakuhachi breath flute melody + wind whisper
      const fNote = fluteNotes[s % fluteNotes.length];
      if (fNote > 0) {
        this.playTone(fNote * 0.985, fNote, 0.72, 'sine', 0.14, true);
        this.playFilteredNoise(0.28, fNote * 2.2, fNote * 1.4, 0.045, 3.0, 'bandpass', true);
      }

      // Taiko heartbeat builds across Acts 2, 3, 4
      if (act === 0 && s % 8 === 0) {
        this.playTone(95, 38, 0.34, 'sine', 0.22, true);
      } else if (act >= 1 && (s % 4 === 0 || (act >= 2 && s % 4 === 3))) {
        const heavy = s % 8 === 0;
        this.playTone(heavy ? 115 : 88, 36, 0.28, 'sine', heavy ? 0.28 : 0.18, true);
        this.playFilteredNoise(0.08, 380, 120, 0.1, 1.2, 'lowpass', true);
      }

      // Rising Koto / Shamisen heroic arpeggios in Acts 3 & 4
      if (act >= 2 && s % 2 === 0) {
        const arp = [293.66, 349.23, 440.0, 587.33, 698.46, 880.0];
        const n = arp[(s + act) % arp.length];
        this.playTone(n, n * 0.99, 0.19, 'triangle', 0.11, true);
      }
    }, 250);
  }

  public playCutsceneSwordDraw() {
    this.playFilteredNoise(0.26, 4600, 1800, 0.22, 3.2);
    this.playTone(2350, 3150, 0.32, 'sine', 0.12);
    this.playTone(3420, 3280, 0.42, 'triangle', 0.07, false, 0.04);
  }

  // Exciting Japanese Taiko & Shamisen Battle Music Sequencer (138 BPM)
  public startBattleMusic() {
    this.stopCutsceneMusic();
    this.stopArenaMusic();
    this.musicDesired = true;
    const ctx = this.ensureContext();
    if (!ctx || !this.isMusicActive()) return;
    if (this.musicTimerId === null) {
      this.startMusicLoop();
    }
  }

  public stopBattleMusic() {
    this.musicDesired = false;
    this.clearMusicInterval();
  }

  private clearMusicInterval() {
    if (this.musicTimerId !== null) {
      window.clearInterval(this.musicTimerId);
      this.musicTimerId = null;
    }
  }

  // Calm & Motivating Tactical Arena Mountain Music (~88 BPM steady ambient pulse)
  public startArenaMusic() {
    this.stopCutsceneMusic();
    this.stopBattleMusic();
    this.arenaDesired = true;
    const ctx = this.ensureContext();
    if (!ctx || !this.isMusicActive()) return;
    if (this.arenaTimerId === null) {
      this.startArenaLoop();
    }
  }

  public stopArenaMusic() {
    this.arenaDesired = false;
    this.clearArenaInterval();
  }

  private clearArenaInterval() {
    if (this.arenaTimerId !== null) {
      window.clearInterval(this.arenaTimerId);
      this.arenaTimerId = null;
    }
  }

  private startArenaLoop() {
    if (typeof window === 'undefined' || !this.isMusicActive()) return;
    this.clearArenaInterval();
    this.arenaStep = 0;

    // Warm D-Dorian / Japanese Yo-scale inspiring mountain theme
    const fluteNotes = [
      293.66, 0, 349.23, 0, 440.0, 0, 392.0, 0,
      349.23, 0, 329.63, 0, 293.66, 0, 0, 0,
      440.0, 0, 523.25, 0, 587.33, 0, 523.25, 0,
      440.0, 0, 392.0, 349.23, 293.66, 0, 0, 0,
    ];
    const padRoots = [73.42, 87.31, 98.0, 82.41];

    this.arenaTimerId = window.setInterval(() => {
      if (!this.isMusicActive() || !this.arenaDesired) return;
      const ctx = this.ctx;
      if (!ctx || ctx.state !== 'running') return;

      const s = this.arenaStep % 32;
      this.arenaStep++;

      // Warm sustained mountain chord pad every 8 steps
      if (s % 8 === 0) {
        const root = padRoots[Math.floor(s / 8) % padRoots.length];
        this.playTone(root, root, 2.35, 'sine', 0.11, true);
        this.playTone(root * 1.5, root * 1.5, 2.15, 'triangle', 0.06, true);
      }

      // Soft motivating Taiko pulse on steady quarter-beats
      if (s % 4 === 0) {
        const accent = s % 8 === 0;
        this.playTone(accent ? 98 : 82, 38, 0.28, 'sine', accent ? 0.18 : 0.12, true);
      }
      if (s % 4 === 2) {
        this.playFilteredNoise(0.06, 950, 420, 0.04, 1.8, 'bandpass', true);
      }

      // Expressive calm flute / koto lead
      const note = fluteNotes[s];
      if (note > 0) {
        this.playTone(note * 0.992, note, 0.68, 'sine', 0.11, true);
        this.playTone(note * 2, note * 2, 0.26, 'triangle', 0.032, true);
      }
    }, 340);
  }

  private startMusicLoop() {
    if (typeof window === 'undefined' || !this.isMusicActive()) return;
    this.clearMusicInterval();
    this.musicStep = 0;

    // Japanese In-sen / Hirajoshi energetic battle riff (D minor pentatonic with b2 tension)
    const melodyHz = [
      293.66, 0, 311.13, 392.0,
      440.0, 0, 392.0, 311.13,
      293.66, 440.0, 587.33, 0,
      523.25, 440.0, 392.0, 311.13,
      293.66, 0, 349.23, 440.0,
      587.33, 622.25, 587.33, 440.0,
      392.0, 0, 440.0, 523.25,
      622.25, 587.33, 440.0, 349.23,
    ];
    const bassHz = [
      73.42, 0, 73.42, 0, 73.42, 0, 110.0, 0,
      73.42, 0, 73.42, 73.42, 98.0, 0, 110.0, 0,
      77.78, 0, 77.78, 0, 87.31, 0, 98.0, 0,
      110.0, 0, 110.0, 110.0, 98.0, 0, 82.41, 0,
    ];

    const stepMs = 108; // ~138 BPM 16th-note battle groove
    this.musicTimerId = window.setInterval(() => {
      if (!this.isMusicActive() || !this.musicDesired) return;
      const ctx = this.ctx;
      if (!ctx || ctx.state !== 'running') return;

      const s = this.musicStep % 32;
      this.musicStep++;

      // 1. Driving Taiko War Drums
      if (s % 4 === 0 || s % 16 === 6 || s % 16 === 14) {
        const isAccent = s % 8 === 0;
        this.playTone(isAccent ? 128 : 102, 38, isAccent ? 0.19 : 0.14, 'sine', isAccent ? 0.28 : 0.2, true);
        this.playFilteredNoise(0.055, 420, 140, isAccent ? 0.12 : 0.08, 1.1, 'lowpass', true);
      }

      // 2. Crisp Wooden Hyoshigi / Snare Rim Hits
      if (s % 4 === 2 || s % 16 === 11 || s % 16 === 15) {
        this.playFilteredNoise(0.045, 2200, 1100, 0.08, 2.5, 'bandpass', true);
      }

      // 3. Shamisen Plucked Battle Lead
      const mel = melodyHz[s];
      if (mel > 0) {
        this.playTone(mel, mel * 0.992, 0.14, 'triangle', 0.13, true);
        this.playTone(mel * 2, mel * 1.98, 0.08, 'sawtooth', 0.045, true);
      }

      // 4. Driving Low Bass Pulse
      const b = bassHz[s];
      if (b > 0) {
        this.playTone(b, b * 0.96, 0.15, 'sawtooth', 0.11, true);
      }
    }, stepMs);
  }

  public playJump(isDouble = false) {
    this.playTone(isDouble ? 360 : 230, isDouble ? 700 : 470, 0.13, 'triangle', 0.11);
  }

  public playDash() {
    this.playFilteredNoise(0.16, 1800, 420, 0.19, 1.4);
    this.playTone(520, 130, 0.14, 'sawtooth', 0.07);
  }

  // Crisp metallic razor-steel slash sound per weapon class
  public playSlash(weapon: WeaponId) {
    if (weapon === 'kodachi') {
      // Twin razor flick: rapid crisp steel slice + high shimmer
      this.playFilteredNoise(0.09, 3600, 1200, 0.22, 2.2);
      this.playTone(2350, 1450, 0.08, 'sine', 0.09);
      this.playTone(760, 290, 0.08, 'triangle', 0.09);
    } else if (weapon === 'odachi') {
      // Heavy roaring greatsword cleave: deep air rip + steel resonance
      this.playFilteredNoise(0.24, 1500, 320, 0.28, 1.3);
      this.playTone(980, 390, 0.18, 'triangle', 0.11);
      this.playTone(240, 72, 0.22, 'sawtooth', 0.13);
    } else if (weapon === 'kusarigama') {
      // Whipping chain rattle + sickle whistle
      this.playFilteredNoise(0.17, 2900, 950, 0.22, 2.6);
      this.playTone(1720, 1180, 0.14, 'sine', 0.08);
      this.playTone(510, 260, 0.14, 'triangle', 0.09);
    } else {
      // Classic Shadow Katana: razor wind-cut + iconic high metallic ring
      this.playFilteredNoise(0.13, 3200, 880, 0.24, 2.0);
      this.playTone(2080, 1340, 0.11, 'sine', 0.095);
      this.playTone(590, 210, 0.12, 'triangle', 0.1);
    }
  }

  // Realistic steel-on-steel sword clash / deflection clang
  public playSwordClash(heavy = false) {
    // Crisp high-frequency metallic partials (inharmonic ring of crossed steel blades)
    const base = heavy ? 1980 : 2420;
    this.playTone(base, base * 0.94, heavy ? 0.26 : 0.19, 'sine', heavy ? 0.15 : 0.12);
    this.playTone(base * 1.49, base * 1.42, heavy ? 0.22 : 0.16, 'triangle', heavy ? 0.12 : 0.09);
    this.playTone(base * 2.13, base * 2.02, 0.12, 'sine', 0.07);
    // Sharp metallic snap + low impact punch
    this.playFilteredNoise(0.085, 4200, 1600, heavy ? 0.26 : 0.2, 2.4);
    this.playTone(heavy ? 165 : 220, 52, 0.11, 'square', heavy ? 0.14 : 0.09);
  }

  public playSpecial(weapon: WeaponId) {
    this.playFilteredNoise(0.3, weapon === 'odachi' ? 950 : 2800, 480, 0.28, 1.8);
    this.playTone(340, 980, 0.22, 'sawtooth', 0.12);
    this.playSwordClash(true);
    this.playTone(720, 240, 0.26, 'triangle', 0.12, false, 0.06);
  }

  public playHit(heavy = false) {
    this.playSwordClash(heavy);
  }

  public playEnemyDefeat() {
    this.playTone(290, 82, 0.2, 'sawtooth', 0.14);
    this.playTone(540, 810, 0.16, 'triangle', 0.1, false, 0.05);
  }

  public playGemPickup() {
    this.playTone(720, 1080, 0.09, 'sine', 0.11);
    this.playTone(1080, 1460, 0.11, 'sine', 0.1, false, 0.055);
  }

  public playDamage() {
    this.playTone(170, 62, 0.24, 'sawtooth', 0.18);
    this.playFilteredNoise(0.14, 700, 220, 0.18, 1.2);
  }

  // Menacing Ronin / Armored Oni villain alert & blade-draw
  public playEnemyAlert(kind: 'ronin' | 'armored' | 'dragon' | 'boar') {
    if (kind === 'boar') {
      this.playBoarCharge();
    } else if (kind === 'dragon') {
      // Deep winged dragon pre-fire growl
      this.playTone(125, 68, 0.28, 'sawtooth', 0.15);
      this.playFilteredNoise(0.22, 620, 240, 0.14, 1.5);
    } else if (kind === 'armored') {
      // Heavy oni armor rattle & deep war grunt
      this.playTone(115, 58, 0.24, 'sawtooth', 0.15);
      this.playTone(1450, 1850, 0.12, 'triangle', 0.07);
    } else {
      // Ronin sinister katana unsheath shing + dark battle cry
      this.playTone(2400, 3300, 0.11, 'sine', 0.08);
      this.playTone(220, 115, 0.16, 'sawtooth', 0.1);
    }
  }

  public playBossRoar() {
    // Thunderous Shogun war horn + demonic roar
    this.playTone(118, 46, 0.55, 'sawtooth', 0.22);
    this.playTone(177, 69, 0.52, 'sawtooth', 0.14);
    this.playFilteredNoise(0.45, 520, 160, 0.2, 1.1);
  }

  public playVictory() {
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((n, idx) => {
      this.playTone(n, n * 1.015, 0.24, 'triangle', 0.13, false, idx * 0.095);
    });
  }

  public playUiClick() {
    this.playTone(540, 720, 0.05, 'sine', 0.065);
  }

  public playWeaponSwap() {
    this.playTone(1750, 2600, 0.09, 'sine', 0.09);
    this.playTone(460, 780, 0.08, 'triangle', 0.09);
  }

  public playMineBeep() {
    this.playTone(960, 1020, 0.065, 'square', 0.09);
  }

  public playExplosion() {
    this.playTone(118, 28, 0.4, 'sawtooth', 0.26);
    this.playFilteredNoise(0.38, 520, 120, 0.28, 0.9);
  }

  // Roaring Dragon fireball breath
  public playFireball() {
    this.playFilteredNoise(0.28, 980, 260, 0.22, 1.2);
    this.playTone(150, 58, 0.24, 'sawtooth', 0.15);
    this.playTone(360, 120, 0.2, 'triangle', 0.1);
  }

  // Aggressive Wild Boar snort + charging hoof rush
  public playBoarCharge() {
    // Double guttural wild-boar snort
    this.playTone(145, 225, 0.11, 'sawtooth', 0.16);
    this.playTone(185, 82, 0.22, 'sawtooth', 0.17, false, 0.09);
    // Hoof stomp + dirt dust burst
    this.playFilteredNoise(0.2, 540, 190, 0.16, 1.3);
  }

  public playRangedShot(gunId: 'shuriken_smg' | 'venom_kunai' | 'fire_crossbow' | 'dragon_cannon') {
    if (gunId === 'dragon_cannon') {
      this.playTone(180, 48, 0.22, 'sawtooth', 0.18);
      this.playFilteredNoise(0.2, 1100, 220, 0.24, 1.1, 'lowpass');
    } else if (gunId === 'fire_crossbow') {
      this.playFilteredNoise(0.12, 2600, 740, 0.2, 2.0);
      this.playTone(620, 240, 0.14, 'triangle', 0.12);
    } else if (gunId === 'venom_kunai') {
      this.playFilteredNoise(0.06, 3800, 1400, 0.15, 2.6);
      this.playTone(1180, 620, 0.06, 'sine', 0.08);
    } else {
      this.playFilteredNoise(0.075, 3100, 1100, 0.16, 2.2);
      this.playTone(880, 410, 0.07, 'triangle', 0.09);
    }
  }

  public playGrenadeBounce() {
    this.playTone(280, 140, 0.06, 'triangle', 0.09);
  }

  public playPickup() {
    this.playTone(587.33, 880, 0.09, 'triangle', 0.11);
    this.playTone(880, 1174.66, 0.11, 'sine', 0.1, false, 0.06);
  }

  public playReload() {
    this.playTone(1450, 2100, 0.06, 'sine', 0.08);
    this.playTone(980, 1650, 0.08, 'triangle', 0.08, false, 0.09);
  }

  public playKillConfirm() {
    this.playTone(659.25, 987.77, 0.11, 'triangle', 0.12);
    this.playTone(987.77, 1318.51, 0.14, 'sine', 0.12, false, 0.07);
  }
}

export const soundEngine = new SoundEngine();
