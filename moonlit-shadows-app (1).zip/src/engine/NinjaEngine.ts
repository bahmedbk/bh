import moonlitBgUrl from '../assets/images/arena_moonlit_night_1794531264735.jpg';
import bloodMoonBgUrl from '../assets/images/arena_blood_eclipse_1794531265442.jpg';
import {
  DEFAULT_SEASONAL_EVENT,
  SKINS,
  WEAPONS,
  getStageById,
} from '../data/gameCatalog';
import type {
  HudSnapshot,
  MatchResult,
  PlayerProfile,
  RoomPlayer,
  SeasonalEvent,
  SkinDefinition,
  StageConfig,
  WeaponDefinition,
  WeaponId,
} from '../types/game';
import { soundEngine } from './audio';

export interface InputState {
  left: boolean;
  right: boolean;
  jumpHeld: boolean;
  jumpPressed: boolean;
  dashPressed: boolean;
  attackPressed: boolean;
  specialPressed: boolean;
}

interface Platform {
  id: number;
  x: number;
  y: number;
  w: number;
  h: number;
  kind: 'roof' | 'moving' | 'crumbling' | 'wall' | 'arena';
  originX: number;
  originY: number;
  moveAxis?: 'x' | 'y';
  moveRange?: number;
  moveSpeed?: number;
  phase?: number;
  crumbleState?: 'solid' | 'shaking' | 'fallen';
  crumbleTimer?: number;
  vx: number;
  vy: number;
}

interface Hazard {
  x: number;
  y: number;
  r: number;
  angle: number;
  originX: number;
  moveRange: number;
  speed: number;
}

interface Landmine {
  id: number;
  x: number;
  y: number;
  state: 'armed' | 'triggered' | 'exploded';
  timer: number;
  beepTick: number;
}

interface Collectible {
  x: number;
  y: number;
  bobPhase: number;
  collected: boolean;
  value: number;
}

type EnemyKind = 'ronin' | 'dragon' | 'boar' | 'armored' | 'boss';

interface Enemy {
  id: number;
  kind: EnemyKind;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  facing: number;
  hp: number;
  maxHp: number;
  patrolMin: number;
  patrolMax: number;
  baseY: number;
  state: 'patrol' | 'windup' | 'attack' | 'recover';
  stateTimer: number;
  hitFlash: number;
  attackPattern: number;
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  fromPlayer: boolean;
  damage: number;
  color: string;
  life: number;
  isFire?: boolean;
  piercing?: boolean;
  hitIds?: Set<number>;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  gravity: number;
  kind?: 'square' | 'spark';
}

interface ClashFlash {
  x: number;
  y: number;
  angle: number;
  scale: number;
  color: string;
  life: number;
  maxLife: number;
}

interface SlashArc {
  x: number;
  y: number;
  facing: number;
  range: number;
  angleOffset: number;
  color: string;
  accent: string;
  life: number;
  maxLife: number;
  is360?: boolean;
  comboStyle?: number;
}

interface ExplosionRing {
  x: number;
  y: number;
  maxR: number;
  life: number;
  maxLife: number;
}

interface ShadowGhost {
  x: number;
  y: number;
  facing: number;
  color: string;
  alpha: number;
}

interface ScarfNode {
  x: number;
  y: number;
  oldX: number;
  oldY: number;
}

export interface CombatImpactEvent {
  kind: 'slash' | 'clash' | 'deflect' | 'special';
  screenX: number;
  screenY: number;
  facing: number;
  color: string;
  accent: string;
  intensity: number;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onGameOver: (result: MatchResult) => void;
  onVictory: (result: MatchResult) => void;
  onTrialGateReached?: () => void;
  onWeaponChanged?: (weaponId: WeaponId) => void;
  onCombatImpact?: (event: CombatImpactEvent) => void;
  onLocalStateSync?: (payload: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    facing: number;
    action: string;
    hp: number;
    maxHp: number;
    score: number;
    progress: number;
  }) => void;
  onBossDamageSync?: (damage: number) => void;
  onPvpSlashSync?: (targetId: string, damage: number) => void;
}

const GRAVITY = 1520;

export class NinjaEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private profile: PlayerProfile;
  private stage: StageConfig;
  private seasonalEvent: SeasonalEvent;
  private isSeasonal: boolean;
  private multiplayerMode: 'solo' | 'coop' | 'competitive';
  private callbacks: EngineCallbacks;

  private weapon: WeaponDefinition;
  private skin: SkinDefinition;

  private rafId: number | null = null;
  private lastFrameMs = 0;
  private paused = false;
  private finished = false;
  private elapsedSec = 0;
  private trialLimitSec: number | null;
  private trialTriggered = false;
  private hitstopTimer = 0;
  private shakeIntensity = 0;
  private hudThrottle = 0;
  private netSyncThrottle = 0;

  // Player state
  private px = 120;
  private py = 300;
  private pw = 34;
  private ph = 50;
  private pvx = 0;
  private pvy = 0;
  private facing = 1;
  private grounded = false;
  private wallTouch = 0;
  private coyoteTimer = 0;
  private jumpBufferTimer = 0;
  private jumpsUsed = 0;

  private hp = 100;
  private maxHp = 100;
  private invulnTimer = 0;
  private playerHitFlash = 0;

  private dashTimer = 0;
  private dashCooldownTimer = 0;
  private dashMaxCooldown = 1.15;

  private attackTimer = 0;
  private attackDuration = 0.24;
  private attackStyle = 0;
  private attackCooldownTimer = 0;
  private comboStep = 0;
  private comboResetTimer = 0;
  private specialCooldownTimer = 0;
  private specialMaxCooldown = 4.5;

  private comboCount = 0;
  private comboDecayTimer = 0;
  private gemsCollected = 0;
  private xpCollected = 0;
  private score = 0;

  private scarf: ScarfNode[] = [];
  private ghosts: ShadowGhost[] = [];
  private ghostTimer = 0;

  // World entities
  private platforms: Platform[] = [];
  private hazards: Hazard[] = [];
  private mines: Landmine[] = [];
  private collectibles: Collectible[] = [];
  private enemies: Enemy[] = [];
  private projectiles: Projectile[] = [];
  private particles: Particle[] = [];
  private slashArcs: SlashArc[] = [];
  private clashFlashes: ClashFlash[] = [];
  private explosions: ExplosionRing[] = [];
  private peers: RoomPlayer[] = [];

  private bossActive = false;
  private bossDefeated = false;
  private arenaMinX = 0;
  private cameraX = 0;
  private cameraY = 0;
  private bgScroll = 0;
  private bgImage: HTMLImageElement | null = null;
  private bgImageLoaded = false;

  private inputs: InputState = {
    left: false,
    right: false,
    jumpHeld: false,
    jumpPressed: false,
    dashPressed: false,
    attackPressed: false,
    specialPressed: false,
  };

  constructor(
    canvas: HTMLCanvasElement,
    profile: PlayerProfile,
    stageId: string,
    callbacks: EngineCallbacks,
    options?: {
      seasonalEvent?: SeasonalEvent;
      multiplayerMode?: 'solo' | 'coop' | 'competitive';
      externalBossMaxHp?: number;
      trialLimitSec?: number | null;
    }
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Could not acquire 2D context');
    this.ctx = context;

    this.profile = profile;
    this.isSeasonal = stageId === 'seasonal';
    this.stage = getStageById(stageId);
    this.seasonalEvent = options?.seasonalEvent || DEFAULT_SEASONAL_EVENT;
    this.multiplayerMode = options?.multiplayerMode || 'solo';
    this.trialLimitSec = options?.trialLimitSec ?? null;
    this.callbacks = callbacks;

    this.weapon = WEAPONS.find((w) => w.id === profile.equippedWeapon) || WEAPONS[0];
    this.skin = SKINS.find((s) => s.id === profile.equippedSkin) || SKINS[0];

    this.maxHp = 100 + profile.skillHealth * 15;
    this.hp = this.maxHp;

    const cdFactor = Math.max(0.45, 1 - profile.skillDash * 0.06);
    const seasonalDashBoost =
      this.isSeasonal && this.seasonalEvent.modifier === 'shadow_rush' ? 0.65 : 1;
    this.dashMaxCooldown = 1.1 * cdFactor * seasonalDashBoost;
    this.specialMaxCooldown = this.weapon.specialCooldown * cdFactor;

    this.buildLevel(options?.externalBossMaxHp);
    this.initScarf();
    this.emitHud();

    if (typeof Image !== 'undefined') {
      const img = new Image();
      img.onload = () => {
        this.bgImageLoaded = true;
      };
      img.src = this.isSeasonal ? bloodMoonBgUrl : moonlitBgUrl;
      this.bgImage = img;
    }
  }

  public setWeapon(weaponId: WeaponId) {
    const found = WEAPONS.find((w) => w.id === weaponId);
    if (!found || found.id === this.weapon.id) return;
    this.weapon = found;
    const cdFactor = Math.max(0.45, 1 - this.profile.skillDash * 0.06);
    this.specialMaxCooldown = this.weapon.specialCooldown * cdFactor;
    this.specialCooldownTimer = Math.min(this.specialCooldownTimer, this.specialMaxCooldown);
    soundEngine.playWeaponSwap();
    this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, found.accentColor, 10, 150);
    this.callbacks.onWeaponChanged?.(found.id);
    this.emitHud();
  }

  public cycleWeapon() {
    const unlocked = this.profile.unlockedWeapons;
    if (unlocked.length <= 1) return;
    const idx = unlocked.indexOf(this.weapon.id);
    const next = unlocked[(idx + 1) % unlocked.length];
    this.setWeapon(next);
  }

  public clearTrialLimit() {
    this.trialLimitSec = null;
    this.trialTriggered = false;
  }

  private initScarf() {
    this.scarf = [];
    for (let i = 0; i < 9; i++) {
      this.scarf.push({
        x: this.px - i * 6,
        y: this.py + 12,
        oldX: this.px - i * 6,
        oldY: this.py + 12,
      });
    }
  }

  private seededRandom(seed: number): () => number {
    let s = seed % 2147483647;
    if (s <= 0) s += 2147483646;
    return () => {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };
  }

  private buildLevel(externalBossMaxHp?: number) {
    const seed = this.isSeasonal ? 9917 : this.stage.order * 1337;
    const rand = this.seededRandom(seed);

    this.platforms = [];
    this.hazards = [];
    this.mines = [];
    this.collectibles = [];
    this.enemies = [];

    let pid = 1;
    let eid = 1;
    let mid = 1;

    // Starting sanctuary rooftop
    this.platforms.push({
      id: pid++,
      x: -100,
      y: 420,
      w: 560,
      h: 220,
      kind: 'roof',
      originX: -100,
      originY: 420,
      vx: 0,
      vy: 0,
    });

    // Introductory well-spaced blue gem & early landmine
    this.collectibles.push(
      { x: 265, y: 376, bobPhase: 0.4, collected: false, value: 2 }
    );
    this.mines.push({ id: mid++, x: 380, y: 420, state: 'armed', timer: 0, beepTick: 0 });

    this.px = 90;
    this.py = 360;

    let cursorX = 500;
    let currentY = 410;
    const arenaStart = this.stage.lengthPx - 760;

    while (cursorX < arenaStart - 160) {
      const gap = 82 + rand() * (65 + this.stage.difficulty * 14);
      cursorX += gap;

      const roll = rand();
      const deltaY = (rand() - 0.48) * 115;
      currentY = Math.max(210, Math.min(470, currentY + deltaY));

      if (roll < 0.18 && this.stage.difficulty >= 2) {
        const w = 145 + rand() * 50;
        const axis: 'x' | 'y' = rand() > 0.45 ? 'x' : 'y';
        this.platforms.push({
          id: pid++,
          x: cursorX,
          y: currentY,
          w,
          h: 24,
          kind: 'moving',
          originX: cursorX,
          originY: currentY,
          moveAxis: axis,
          moveRange: axis === 'x' ? 75 : 55,
          moveSpeed: 1.4 + this.stage.difficulty * 0.22,
          phase: rand() * Math.PI * 2,
          vx: 0,
          vy: 0,
        });
        if (rand() < 0.55) {
          this.collectibles.push({
            x: cursorX + w / 2,
            y: currentY - 38,
            bobPhase: rand() * 6,
            collected: false,
            value: 2,
          });
        }
        cursorX += w + (axis === 'x' ? 60 : 10);
      } else if (roll < 0.32 && this.stage.difficulty >= 2) {
        const segCount = 2 + Math.floor(rand() * 2);
        for (let s = 0; s < segCount; s++) {
          const sx = cursorX + s * 104;
          this.platforms.push({
            id: pid++,
            x: sx,
            y: currentY,
            w: 84,
            h: 22,
            kind: 'crumbling',
            originX: sx,
            originY: currentY,
            crumbleState: 'solid',
            crumbleTimer: 0,
            vx: 0,
            vy: 0,
          });
          if (s === 0) {
            this.collectibles.push({
              x: sx + 42,
              y: currentY - 36,
              bobPhase: rand() * 6,
              collected: false,
              value: 3,
            });
          }
        }
        cursorX += segCount * 104;
      } else if (roll < 0.43 && this.stage.difficulty >= 3) {
        const towerX = cursorX + 30;
        this.platforms.push({
          id: pid++,
          x: towerX,
          y: currentY - 190,
          w: 36,
          h: 250,
          kind: 'wall',
          originX: towerX,
          originY: currentY - 190,
          vx: 0,
          vy: 0,
        });
        const highY = Math.max(190, currentY - 110);
        const w = 280;
        this.platforms.push({
          id: pid++,
          x: towerX + 110,
          y: highY,
          w,
          h: 220,
          kind: 'roof',
          originX: towerX + 110,
          originY: highY,
          vx: 0,
          vy: 0,
        });
        this.collectibles.push({
          x: towerX + 18,
          y: currentY - 215,
          bobPhase: rand() * 6,
          collected: false,
          value: 4,
        });
        this.enemies.push(
          this.createEnemy(eid++, 'dragon', towerX + 210, highY, towerX + 120, towerX + w + 80)
        );
        currentY = highY;
        cursorX = towerX + 110 + w;
      } else {
        const w = 290 + rand() * 210;
        this.platforms.push({
          id: pid++,
          x: cursorX,
          y: currentY,
          w,
          h: 260,
          kind: 'roof',
          originX: cursorX,
          originY: currentY,
          vx: 0,
          vy: 0,
        });

        // Well-spaced blue gems (reduced density so gems aren't clustered)
        if (rand() > 0.32) {
          this.collectibles.push({
            x: cursorX + w * 0.38,
            y: currentY - 40,
            bobPhase: rand() * 6,
            collected: false,
            value: 2,
          });
          if (w > 410 && rand() > 0.65) {
            this.collectibles.push({
              x: cursorX + w * 0.78,
              y: currentY - 58,
              bobPhase: rand() * 6,
              collected: false,
              value: 2,
            });
          }
        }

        // Ground landmines on rooftops!
        if (rand() > 0.35) {
          this.mines.push({
            id: mid++,
            x: cursorX + w * (0.28 + rand() * 0.45),
            y: currentY,
            state: 'armed',
            timer: 0,
            beepTick: 0,
          });
        }

        // Monsters: Charging Boar, Fire-Breathing Dragon, Shadow Ronin, Armored Oni
        const enemyRoll = rand();
        let kind: EnemyKind = 'boar';
        if (enemyRoll > 0.72) kind = 'dragon';
        else if (enemyRoll > 0.42) kind = 'boar';
        else if (this.stage.difficulty >= 3 && enemyRoll > 0.22) kind = 'armored';
        else kind = 'ronin';

        this.enemies.push(
          this.createEnemy(eid++, kind, cursorX + w * 0.65, currentY, cursorX + 20, cursorX + w - 20)
        );

        if (w > 360 && rand() > 0.55) {
          this.hazards.push({
            x: cursorX + w * 0.5,
            y: currentY - 14,
            r: 17,
            angle: 0,
            originX: cursorX + w * 0.5,
            moveRange: 65,
            speed: 1.8 + this.stage.difficulty * 0.25,
          });
        }

        cursorX += w;
      }
    }

    // Final Boss Arena rooftop
    this.arenaMinX = Math.max(cursorX + 90, arenaStart);
    this.platforms.push({
      id: pid++,
      x: this.arenaMinX,
      y: 410,
      w: 880,
      h: 280,
      kind: 'arena',
      originX: this.arenaMinX,
      originY: 410,
      vx: 0,
      vy: 0,
    });

    if (this.arenaMinX - cursorX > 150) {
      this.platforms.push({
        id: pid++,
        x: cursorX + 75,
        y: 395,
        w: 90,
        h: 24,
        kind: 'moving',
        originX: cursorX + 75,
        originY: 395,
        moveAxis: 'y',
        moveRange: 25,
        moveSpeed: 1.5,
        phase: 0,
        vx: 0,
        vy: 0,
      });
    }

    const boss = this.createEnemy(
      eid++,
      'boss',
      this.arenaMinX + 640,
      410,
      this.arenaMinX + 60,
      this.arenaMinX + 820
    );
    if (externalBossMaxHp && externalBossMaxHp > 0) {
      boss.hp = externalBossMaxHp;
      boss.maxHp = externalBossMaxHp;
    }
    this.enemies.push(boss);
  }

  private createEnemy(
    id: number,
    kind: EnemyKind,
    x: number,
    floorY: number,
    patrolMin: number,
    patrolMax: number
  ): Enemy {
    const diffScale = 1 + (this.stage.difficulty - 1) * 0.22;
    const seasonalHpScale =
      this.isSeasonal && this.seasonalEvent.modifier === 'blood_moon' ? 1.2 : 1;

    if (kind === 'boss') {
      const baseHp = 420 + this.stage.difficulty * 140;
      const maxHp = Math.round(baseHp * seasonalHpScale);
      const y = floorY - 84;
      return {
        id,
        kind,
        x,
        y,
        w: 58,
        h: 84,
        vx: 0,
        vy: 0,
        facing: -1,
        hp: maxHp,
        maxHp,
        patrolMin,
        patrolMax,
        baseY: y,
        state: 'patrol',
        stateTimer: 1.1,
        hitFlash: 0,
        attackPattern: 0,
      };
    }

    const sizes: Record<Exclude<EnemyKind, 'boss'>, { w: number; h: number; hp: number }> = {
      ronin: { w: 34, h: 48, hp: 52 },
      dragon: { w: 52, h: 44, hp: 62 },
      boar: { w: 48, h: 36, hp: 68 },
      armored: { w: 40, h: 54, hp: 96 },
    };
    const spec = sizes[kind];
    const hp = Math.round(spec.hp * diffScale * seasonalHpScale);
    const y = kind === 'dragon' ? floorY - 108 : floorY - spec.h;
    return {
      id,
      kind,
      x,
      y,
      w: spec.w,
      h: spec.h,
      vx: 0,
      vy: 0,
      facing: -1,
      hp,
      maxHp: hp,
      patrolMin,
      patrolMax,
      baseY: y,
      state: 'patrol',
      stateTimer: 0.7 + Math.random() * 0.7,
      hitFlash: 0,
      attackPattern: 0,
    };
  }

  public start() {
    if (this.rafId !== null) return;
    this.lastFrameMs = performance.now();
    const tick = (now: number) => {
      const rawDt = (now - this.lastFrameMs) / 1000;
      this.lastFrameMs = now;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

      if (!this.paused && !this.finished) {
        this.update(dt);
      }
      this.render();
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  public stop() {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public setPaused(paused: boolean) {
    this.paused = paused;
    if (!paused) {
      this.lastFrameMs = performance.now();
    }
  }

  public setInput(partial: Partial<InputState>) {
    Object.assign(this.inputs, partial);
  }

  public triggerJump() {
    this.inputs.jumpPressed = true;
    this.inputs.jumpHeld = true;
  }

  public releaseJump() {
    this.inputs.jumpHeld = false;
  }

  public triggerDash() {
    this.inputs.dashPressed = true;
  }

  public triggerAttack() {
    this.inputs.attackPressed = true;
  }

  public triggerSpecial() {
    this.inputs.specialPressed = true;
  }

  public setPeers(peers: RoomPlayer[]) {
    this.peers = peers;
  }

  public setExternalBossHp(hp: number) {
    const boss = this.enemies.find((e) => e.kind === 'boss');
    if (boss && !this.bossDefeated) {
      boss.hp = Math.max(0, hp);
      if (boss.hp <= 0) {
        this.handleBossDefeated(boss);
      }
    }
  }

  public applyExternalDamage(amount: number) {
    this.damagePlayer(amount, -this.facing);
  }

  private update(dt: number) {
    this.elapsedSec += dt;

    // Guest Play-then-Sign-In Trial Gate
    if (
      this.trialLimitSec !== null &&
      !this.trialTriggered &&
      this.elapsedSec >= this.trialLimitSec
    ) {
      this.trialTriggered = true;
      this.paused = true;
      this.callbacks.onTrialGateReached?.();
      return;
    }

    if (this.shakeIntensity > 0) {
      this.shakeIntensity = Math.max(0, this.shakeIntensity - dt * 28);
    }

    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      this.updateParticles(dt * 0.3);
      return;
    }

    this.updatePlatforms(dt);
    this.updatePlayer(dt);
    this.updateScarf(dt);
    this.updateMines(dt);
    this.updateHazards(dt);
    this.updateCollectibles(dt);
    this.updateEnemies(dt);
    this.updateProjectiles(dt);
    this.updateParticles(dt);
    this.updateCamera(dt);

    this.inputs.jumpPressed = false;
    this.inputs.dashPressed = false;
    this.inputs.attackPressed = false;
    this.inputs.specialPressed = false;

    this.hudThrottle += dt;
    if (this.hudThrottle >= 0.065) {
      this.hudThrottle = 0;
      this.emitHud();
    }

    if (this.callbacks.onLocalStateSync) {
      this.netSyncThrottle += dt;
      if (this.netSyncThrottle >= 0.05) {
        this.netSyncThrottle = 0;
        const progress = Math.max(
          0,
          Math.min(100, Math.round((this.px / (this.arenaMinX + 600)) * 100))
        );
        const action =
          this.dashTimer > 0
            ? 'dash'
            : this.attackTimer > 0
            ? 'attack'
            : !this.grounded
            ? 'jump'
            : Math.abs(this.pvx) > 20
            ? 'run'
            : 'idle';
        this.callbacks.onLocalStateSync({
          x: Math.round(this.px),
          y: Math.round(this.py),
          vx: Math.round(this.pvx),
          vy: Math.round(this.pvy),
          facing: this.facing,
          action,
          hp: this.hp,
          maxHp: this.maxHp,
          score: this.score,
          progress,
        });
      }
    }
  }

  private updatePlatforms(dt: number) {
    for (const p of this.platforms) {
      p.vx = 0;
      p.vy = 0;
      if (p.kind === 'moving') {
        p.phase = (p.phase || 0) + dt * (p.moveSpeed || 1.5);
        const offset = Math.sin(p.phase) * (p.moveRange || 60);
        const prevX = p.x;
        const prevY = p.y;
        if (p.moveAxis === 'x') {
          p.x = p.originX + offset;
        } else {
          p.y = p.originY + offset;
        }
        p.vx = (p.x - prevX) / dt;
        p.vy = (p.y - prevY) / dt;
      } else if (p.kind === 'crumbling') {
        if (p.crumbleState === 'shaking') {
          p.crumbleTimer = (p.crumbleTimer || 0) - dt;
          if ((p.crumbleTimer || 0) <= 0) {
            p.crumbleState = 'fallen';
            p.crumbleTimer = 2.8;
            this.spawnBurst(p.x + p.w / 2, p.y + 10, '#64748B', 10, 140);
          }
        } else if (p.crumbleState === 'fallen') {
          p.crumbleTimer = (p.crumbleTimer || 0) - dt;
          if ((p.crumbleTimer || 0) <= 0) {
            p.crumbleState = 'solid';
          }
        }
      }
    }
  }

  private updatePlayer(dt: number) {
    const gravityScale =
      this.isSeasonal && this.seasonalEvent.modifier === 'low_gravity' ? 0.72 : 1.0;

    if (this.invulnTimer > 0) this.invulnTimer -= dt;
    if (this.playerHitFlash > 0) this.playerHitFlash -= dt;
    if (this.dashCooldownTimer > 0) this.dashCooldownTimer = Math.max(0, this.dashCooldownTimer - dt);
    if (this.specialCooldownTimer > 0)
      this.specialCooldownTimer = Math.max(0, this.specialCooldownTimer - dt);
    if (this.attackCooldownTimer > 0) this.attackCooldownTimer -= dt;
    if (this.attackTimer > 0) this.attackTimer -= dt;
    if (this.comboResetTimer > 0) {
      this.comboResetTimer -= dt;
      if (this.comboResetTimer <= 0) this.comboStep = 0;
    }
    if (this.comboDecayTimer > 0) {
      this.comboDecayTimer -= dt;
      if (this.comboDecayTimer <= 0) this.comboCount = 0;
    }

    if (this.inputs.jumpPressed) {
      this.jumpBufferTimer = 0.13;
    } else if (this.jumpBufferTimer > 0) {
      this.jumpBufferTimer -= dt;
    }

    if (this.grounded) {
      this.coyoteTimer = 0.11;
      this.jumpsUsed = 0;
    } else if (this.coyoteTimer > 0) {
      this.coyoteTimer -= dt;
    }

    if (this.inputs.dashPressed && this.dashCooldownTimer <= 0 && this.dashTimer <= 0) {
      this.dashTimer = 0.18;
      this.dashCooldownTimer = this.dashMaxCooldown;
      this.invulnTimer = Math.max(this.invulnTimer, 0.24);
      this.pvx = this.facing * 760;
      this.pvy = 0;
      soundEngine.playDash();
      this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, this.skin.scarfColor, 14, 240);
    }

    if (this.dashTimer > 0) {
      this.dashTimer -= dt;
      this.ghostTimer -= dt;
      if (this.ghostTimer <= 0) {
        this.ghostTimer = 0.032;
        this.ghosts.push({
          x: this.px,
          y: this.py,
          facing: this.facing,
          color: this.skin.trailColor,
          alpha: 0.72,
        });
      }
    } else {
      const moveSpeed = 335 * (this.weapon.id === 'kodachi' ? 1.08 : 1);
      let targetVx = 0;
      if (this.inputs.left) {
        targetVx -= moveSpeed;
        this.facing = -1;
      }
      if (this.inputs.right) {
        targetVx += moveSpeed;
        this.facing = 1;
      }
      const accel = this.grounded ? 24 : 15;
      this.pvx += (targetVx - this.pvx) * Math.min(1, accel * dt);

      this.pvy += GRAVITY * gravityScale * dt;
      if (this.wallTouch !== 0 && !this.grounded && this.pvy > 135) {
        this.pvy = 135;
      }
      this.pvy = Math.min(this.pvy, 920);
    }

    if (this.jumpBufferTimer > 0) {
      if (this.coyoteTimer > 0) {
        this.pvy = -590;
        this.grounded = false;
        this.coyoteTimer = 0;
        this.jumpBufferTimer = 0;
        this.jumpsUsed = 1;
        soundEngine.playJump(false);
        this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#E2E8F0', 7, 110);
      } else if (this.wallTouch !== 0) {
        this.pvy = -560;
        this.pvx = -this.wallTouch * 390;
        this.facing = -this.wallTouch;
        this.jumpBufferTimer = 0;
        this.jumpsUsed = 1;
        soundEngine.playJump(true);
        this.spawnBurst(
          this.px + (this.wallTouch > 0 ? this.pw : 0),
          this.py + this.ph / 2,
          '#94A3B8',
          8,
          130
        );
      } else if (this.jumpsUsed < 2) {
        this.pvy = -530;
        this.jumpsUsed = 2;
        this.jumpBufferTimer = 0;
        soundEngine.playJump(true);
        this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, this.skin.scarfColor, 10, 160);
      }
    }

    if (!this.inputs.jumpHeld && this.pvy < -220 && this.dashTimer <= 0) {
      this.pvy += GRAVITY * 1.4 * dt;
    }

    if (this.inputs.attackPressed && this.attackCooldownTimer <= 0) {
      this.performAttack();
    }
    if (this.inputs.specialPressed && this.specialCooldownTimer <= 0) {
      this.performSpecialArt();
    }

    this.px += this.pvx * dt;
    if (this.px < 0) {
      this.px = 0;
      this.pvx = 0;
    }
    if (this.bossActive && this.px < this.arenaMinX) {
      this.px = this.arenaMinX;
      this.pvx = 0;
    }
    if (this.px > this.arenaMinX + 830) {
      this.px = this.arenaMinX + 830;
      this.pvx = 0;
    }

    this.wallTouch = 0;
    for (const p of this.platforms) {
      if (p.kind === 'crumbling' && p.crumbleState === 'fallen') continue;
      if (this.rectsOverlap(this.px, this.py + 4, this.pw, this.ph - 8, p.x, p.y, p.w, p.h)) {
        if (this.pvx > 0) {
          this.px = p.x - this.pw;
          this.pvx = 0;
          if (p.kind === 'wall') this.wallTouch = 1;
        } else if (this.pvx < 0) {
          this.px = p.x + p.w;
          this.pvx = 0;
          if (p.kind === 'wall') this.wallTouch = -1;
        }
      }
    }

    const prevBottom = this.py + this.ph;
    this.py += this.pvy * dt;
    this.grounded = false;

    for (const p of this.platforms) {
      if (p.kind === 'crumbling' && p.crumbleState === 'fallen') continue;
      if (this.rectsOverlap(this.px + 2, this.py, this.pw - 4, this.ph, p.x, p.y, p.w, p.h)) {
        if (this.pvy >= 0 && prevBottom <= p.y + 18) {
          this.py = p.y - this.ph;
          this.pvy = 0;
          this.grounded = true;
          if (p.kind === 'moving') {
            this.px += p.vx * dt;
          }
          if (p.kind === 'crumbling' && p.crumbleState === 'solid') {
            p.crumbleState = 'shaking';
            p.crumbleTimer = 0.62;
          }
        } else if (this.pvy < 0 && p.kind === 'wall') {
          this.py = p.y + p.h;
          this.pvy = 0;
        }
      }
    }

    if (!this.bossActive && this.px >= this.arenaMinX + 90) {
      this.bossActive = true;
      soundEngine.playBossRoar();
      this.shakeIntensity = 8;
    }

    if (this.py > 760) {
      this.damagePlayer(28, -this.facing);
      if (!this.finished) {
        const safe =
          this.platforms.find(
            (p) =>
              p.kind !== 'crumbling' &&
              p.kind !== 'wall' &&
              p.x <= this.px + 60 &&
              p.x + p.w >= this.px - 260
          ) || this.platforms[0];
        this.px = Math.max(this.bossActive ? this.arenaMinX + 40 : 40, safe.x + safe.w * 0.35);
        this.py = safe.y - this.ph - 10;
        this.pvx = 0;
        this.pvy = 0;
      }
    }

    for (let i = this.ghosts.length - 1; i >= 0; i--) {
      this.ghosts[i].alpha -= dt * 3.2;
      if (this.ghosts[i].alpha <= 0) this.ghosts.splice(i, 1);
    }
  }

  private updateMines(dt: number) {
    const playerCx = this.px + this.pw / 2;
    const playerBottom = this.py + this.ph;

    for (const m of this.mines) {
      if (m.state === 'exploded') continue;

      if (m.state === 'armed') {
        const dist = Math.hypot(playerCx - m.x, playerBottom - m.y);
        if (dist < 46) {
          m.state = 'triggered';
          m.timer = 0.5;
          m.beepTick = 0;
          soundEngine.playMineBeep();
        }
      } else if (m.state === 'triggered') {
        m.timer -= dt;
        m.beepTick += dt;
        if (m.beepTick >= 0.16) {
          m.beepTick = 0;
          soundEngine.playMineBeep();
        }
        if (m.timer <= 0) {
          m.state = 'exploded';
          soundEngine.playExplosion();
          this.shakeIntensity = Math.max(this.shakeIntensity, 12);
          this.explosions.push({ x: m.x, y: m.y - 10, maxR: 88, life: 0.35, maxLife: 0.35 });
          this.spawnBurst(m.x, m.y - 8, '#F97316', 24, 300);
          this.spawnBurst(m.x, m.y - 8, '#EF4444', 16, 240);

          const blastDist = Math.hypot(playerCx - m.x, this.py + this.ph / 2 - m.y);
          if (blastDist < 84) {
            this.damagePlayer(24, playerCx >= m.x ? 1 : -1);
          }

          // Mines can also blast nearby monsters!
          for (const enemy of this.enemies) {
            if (enemy.hp <= 0) continue;
            const ed = Math.hypot(enemy.x + enemy.w / 2 - m.x, enemy.y + enemy.h / 2 - m.y);
            if (ed < 95) {
              this.damageEnemy(enemy, 45, enemy.x + enemy.w / 2 >= m.x ? 220 : -220);
            }
          }
        }
      }
    }
  }

  private performAttack() {
    const baseCd = 0.27 / this.weapon.speedMultiplier;
    this.attackCooldownTimer = baseCd;
    this.attackDuration = 0.24 / this.weapon.speedMultiplier;
    this.attackTimer = this.attackDuration;
    this.comboStep = (this.comboStep + 1) % 3;
    this.attackStyle = this.comboStep;
    this.comboResetTimer = 0.75;
    soundEngine.playSlash(this.weapon.id);

    if (this.grounded) {
      this.pvx += this.facing * (this.comboStep === 2 ? 190 : 120);
    } else {
      this.pvx += this.facing * 55;
    }

    const angleOffsets = [-0.48, 0.38, 0];
    const arcX = this.px + this.pw / 2 + this.facing * 18;
    const arcY = this.py + this.ph * 0.46;
    this.slashArcs.push({
      x: arcX,
      y: arcY,
      facing: this.facing,
      range: this.weapon.range,
      angleOffset: angleOffsets[this.comboStep],
      color: this.weapon.slashColor,
      accent: this.weapon.accentColor,
      life: 0.18,
      maxLife: 0.18,
      is360: this.weapon.id === 'kusarigama' && this.comboStep === 2,
      comboStyle: this.comboStep,
    });

    // Metallic blade spark trail along the strike arc
    for (let i = 0; i < 8; i++) {
      const a = -0.95 + (i / 7) * 1.9 + angleOffsets[this.comboStep];
      const rad = this.weapon.range * (0.62 + Math.random() * 0.32);
      this.particles.push({
        x: arcX + Math.cos(a) * rad * this.facing,
        y: arcY + Math.sin(a) * rad,
        vx: this.facing * (140 + Math.random() * 190),
        vy: Math.sin(a) * 140 - 40,
        size: 2.2 + Math.random() * 2.2,
        color: i % 2 === 0 ? '#FFFFFF' : this.weapon.accentColor,
        alpha: 0.95,
        life: 0.16 + Math.random() * 0.12,
        maxLife: 0.28,
        gravity: 260,
        kind: 'spark',
      });
    }

    this.callbacks.onCombatImpact?.({
      kind: 'slash',
      screenX: arcX + this.facing * this.weapon.range * 0.42 - this.cameraX,
      screenY: arcY - this.cameraY,
      facing: this.facing,
      color: this.weapon.slashColor,
      accent: this.weapon.accentColor,
      intensity: this.comboStep === 2 ? 0.95 : 0.72,
    });

    const dmgMultiplier = 1 + this.profile.skillAttack * 0.1 + (this.comboStep === 2 ? 0.25 : 0);
    const hitDamage = Math.round(this.weapon.damage * dmgMultiplier);

    const hitBoxX =
      this.weapon.id === 'kusarigama' && this.comboStep === 2
        ? this.px - this.weapon.range * 0.7
        : this.facing > 0
        ? this.px + this.pw * 0.4
        : this.px + this.pw * 0.6 - this.weapon.range;
    const hitBoxW =
      this.weapon.id === 'kusarigama' && this.comboStep === 2
        ? this.weapon.range * 1.6
        : this.weapon.range;
    const hitBoxY = this.py - 16;
    const hitBoxH = this.ph + 32;

    for (const proj of this.projectiles) {
      if (
        !proj.fromPlayer &&
        this.rectsOverlap(
          hitBoxX,
          hitBoxY,
          hitBoxW,
          hitBoxH,
          proj.x - proj.r,
          proj.y - proj.r,
          proj.r * 2,
          proj.r * 2
        )
      ) {
        proj.fromPlayer = true;
        proj.vx = -proj.vx * 1.4;
        proj.vy = -proj.vy * 1.4;
        proj.color = this.weapon.accentColor;
        proj.damage = hitDamage;
        this.spawnClashSparks(proj.x, proj.y, '#BAE6FD', 1.25, 'deflect');
        soundEngine.playHit(false);
      }
    }

    let landedHit = false;
    for (const enemy of this.enemies) {
      if (enemy.hp <= 0) continue;
      if (this.rectsOverlap(hitBoxX, hitBoxY, hitBoxW, hitBoxH, enemy.x, enemy.y, enemy.w, enemy.h)) {
        let finalDmg = hitDamage;
        let isArmoredParry = false;
        if (enemy.kind === 'armored' && this.weapon.id !== 'odachi') {
          const hitFromFront =
            (enemy.facing > 0 && this.px > enemy.x) || (enemy.facing < 0 && this.px < enemy.x);
          if (hitFromFront) {
            finalDmg = Math.max(4, Math.round(hitDamage * 0.45));
            isArmoredParry = true;
          }
        }
        const contactX = (this.px + this.pw / 2 + enemy.x + enemy.w / 2) * 0.5;
        const contactY = (this.py + this.ph * 0.45 + enemy.y + enemy.h * 0.45) * 0.5;
        this.spawnClashSparks(
          contactX,
          contactY,
          isArmoredParry ? '#FDE047' : this.weapon.accentColor,
          isArmoredParry || enemy.kind === 'boss' || this.weapon.id === 'odachi' ? 1.45 : 1.05,
          'clash'
        );
        this.damageEnemy(enemy, finalDmg, this.facing * (this.weapon.id === 'odachi' ? 240 : 120));
        landedHit = true;
      }
    }

    if (this.multiplayerMode === 'competitive' && this.callbacks.onPvpSlashSync) {
      for (const peer of this.peers) {
        if (this.rectsOverlap(hitBoxX, hitBoxY, hitBoxW, hitBoxH, peer.x, peer.y, this.pw, this.ph)) {
          this.callbacks.onPvpSlashSync(peer.id, Math.round(hitDamage * 0.55));
          const clashX = (this.px + this.pw / 2 + peer.x + this.pw / 2) * 0.5;
          const clashY = (this.py + this.ph / 2 + peer.y + this.ph / 2) * 0.5;
          this.spawnClashSparks(clashX, clashY, '#F43F5E', 1.35, 'clash');
          landedHit = true;
        }
      }
    }

    if (landedHit && this.weapon.id === 'odachi') {
      this.hitstopTimer = 0.055;
      this.shakeIntensity = Math.max(this.shakeIntensity, 6);
    }
  }

  private performSpecialArt() {
    this.specialCooldownTimer = this.specialMaxCooldown;
    this.attackDuration = 0.34;
    this.attackTimer = 0.34;
    this.attackStyle = 2;
    soundEngine.playSpecial(this.weapon.id);
    this.spawnClashSparks(
      this.px + this.pw / 2 + this.facing * 20,
      this.py + this.ph * 0.45,
      this.weapon.accentColor,
      1.55,
      'special'
    );
    const dmgMultiplier = 1 + this.profile.skillAttack * 0.1;
    const baseArtDmg = Math.round(this.weapon.damage * 1.85 * dmgMultiplier);

    if (this.weapon.id === 'katana') {
      this.projectiles.push({
        x: this.px + this.pw / 2 + this.facing * 24,
        y: this.py + this.ph * 0.45,
        vx: this.facing * 680,
        vy: 0,
        r: 24,
        fromPlayer: true,
        damage: baseArtDmg,
        color: this.weapon.accentColor,
        life: 1.1,
        piercing: true,
        hitIds: new Set(),
      });
      this.shakeIntensity = Math.max(this.shakeIntensity, 5);
    } else if (this.weapon.id === 'kodachi') {
      const startX = this.px;
      const targetX = Math.max(
        this.bossActive ? this.arenaMinX + 10 : 10,
        Math.min(this.arenaMinX + 820, this.px + this.facing * 220)
      );
      for (let i = 0; i < 4; i++) {
        this.ghosts.push({
          x: startX + ((targetX - startX) * i) / 4,
          y: this.py,
          facing: this.facing,
          color: '#E11D48',
          alpha: 0.85,
        });
      }
      this.px = targetX;
      this.invulnTimer = Math.max(this.invulnTimer, 0.35);
      const minX = Math.min(startX, targetX) - 20;
      const maxX = Math.max(startX, targetX) + this.pw + 20;
      for (const enemy of this.enemies) {
        if (
          enemy.hp > 0 &&
          this.rectsOverlap(minX, this.py - 20, maxX - minX, this.ph + 40, enemy.x, enemy.y, enemy.w, enemy.h)
        ) {
          this.damageEnemy(enemy, baseArtDmg, this.facing * 180);
        }
      }
      this.hitstopTimer = 0.05;
      this.shakeIntensity = Math.max(this.shakeIntensity, 7);
    } else if (this.weapon.id === 'kusarigama') {
      this.slashArcs.push({
        x: this.px + this.pw / 2,
        y: this.py + this.ph / 2,
        facing: this.facing,
        range: 145,
        angleOffset: 0,
        color: '#6EE7B7',
        accent: '#10B981',
        life: 0.34,
        maxLife: 0.34,
        is360: true,
      });
      this.projectiles = this.projectiles.filter((p) => {
        const dist = Math.hypot(p.x - (this.px + this.pw / 2), p.y - (this.py + this.ph / 2));
        return p.fromPlayer || dist > 155;
      });
      for (const enemy of this.enemies) {
        if (
          enemy.hp > 0 &&
          this.rectsOverlap(this.px - 125, this.py - 105, this.pw + 250, this.ph + 210, enemy.x, enemy.y, enemy.w, enemy.h)
        ) {
          this.damageEnemy(enemy, baseArtDmg, (enemy.x < this.px ? -1 : 1) * 260);
        }
      }
      this.shakeIntensity = Math.max(this.shakeIntensity, 7);
    } else {
      this.pvy = Math.max(this.pvy, 280);
      this.shakeIntensity = 11;
      this.hitstopTimer = 0.065;
      for (const dir of [-1, 1]) {
        this.projectiles.push({
          x: this.px + this.pw / 2 + dir * 20,
          y: this.py + this.ph - 18,
          vx: dir * 520,
          vy: 0,
          r: 22,
          fromPlayer: true,
          damage: baseArtDmg,
          color: '#F59E0B',
          life: 0.9,
          piercing: true,
          hitIds: new Set(),
        });
      }
      this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#F59E0B', 22, 310);
    }
  }

  private damageEnemy(enemy: Enemy, damage: number, knockVx: number) {
    enemy.hp = Math.max(0, enemy.hp - damage);
    enemy.hitFlash = 0.14;
    if (enemy.kind !== 'boss') {
      enemy.vx = knockVx;
    }

    this.comboCount += 1;
    this.comboDecayTimer = 3.2;
    this.score += damage * (1 + Math.min(4, Math.floor(this.comboCount / 3)) * 0.25);
    soundEngine.playHit(enemy.kind === 'boss' || this.weapon.id === 'odachi');
    this.spawnBurst(enemy.x + enemy.w / 2, enemy.y + enemy.h / 2, this.weapon.accentColor, 12, 200);

    if (enemy.kind === 'boss' && this.multiplayerMode === 'coop' && this.callbacks.onBossDamageSync) {
      this.callbacks.onBossDamageSync(damage);
    }

    if (enemy.hp <= 0) {
      if (enemy.kind === 'boss') {
        this.handleBossDefeated(enemy);
      } else {
        soundEngine.playEnemyDefeat();
        const xpGain = Math.round((28 + this.stage.difficulty * 8) * (1 + this.profile.skillXp * 0.12));
        this.xpCollected += xpGain;
        this.gemsCollected += 3 + Math.floor(this.stage.difficulty / 2);
        this.score += 180;
        this.spawnBurst(enemy.x + enemy.w / 2, enemy.y + enemy.h / 2, '#38BDF8', 20, 260);
        this.hitstopTimer = 0.04;
      }
    }
  }

  private handleBossDefeated(boss: Enemy) {
    if (this.bossDefeated) return;
    this.bossDefeated = true;
    boss.hp = 0;
    this.hitstopTimer = 0.08;
    this.shakeIntensity = 13;
    soundEngine.playVictory();
    this.spawnBurst(boss.x + boss.w / 2, boss.y + boss.h / 2, '#38BDF8', 42, 340);

    const xpMult = 1 + this.profile.skillXp * 0.12;
    const bonusGems = this.stage.rewardGems + (this.isSeasonal ? 40 : 0);
    const bonusXp = Math.round(this.stage.rewardXp * xpMult);
    this.gemsCollected += bonusGems;
    this.xpCollected += bonusXp;
    this.score += 1200 + Math.max(0, Math.round(600 - this.elapsedSec * 5));

    this.finished = true;
    this.emitHud();
    setTimeout(() => {
      this.callbacks.onVictory({
        victory: true,
        stageId: this.stage.id,
        score: Math.round(this.score),
        gemsEarned: this.gemsCollected,
        xpEarned: this.xpCollected,
        elapsedSec: Math.round(this.elapsedSec),
        bossDefeated: true,
        isSeasonal: this.isSeasonal,
      });
    }, 550);
  }

  private damagePlayer(amount: number, knockDir: number) {
    if (this.invulnTimer > 0 || this.finished) return;
    this.hp = Math.max(0, this.hp - amount);
    this.invulnTimer = 0.85;
    this.playerHitFlash = 0.25;
    this.pvx = knockDir * 240;
    this.pvy = -260;
    this.comboCount = 0;
    this.shakeIntensity = 9;
    this.hitstopTimer = 0.045;
    soundEngine.playDamage();
    this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, '#E11D48', 16, 220);

    if (this.hp <= 0) {
      this.finished = true;
      this.emitHud();
      setTimeout(() => {
        this.callbacks.onGameOver({
          victory: false,
          stageId: this.stage.id,
          score: Math.round(this.score),
          gemsEarned: Math.floor(this.gemsCollected * 0.5),
          xpEarned: Math.floor(this.xpCollected * 0.6),
          elapsedSec: Math.round(this.elapsedSec),
          bossDefeated: false,
          isSeasonal: this.isSeasonal,
        });
      }, 450);
    }
  }

  private updateScarf(dt: number) {
    if (this.scarf.length === 0) return;
    const anchorX = this.px + (this.facing > 0 ? 11 : this.pw - 11);
    const anchorY = this.py + 18;
    this.scarf[0].x = anchorX;
    this.scarf[0].y = anchorY;

    const windX = -this.facing * (45 + Math.abs(this.pvx) * 0.22) + Math.sin(this.elapsedSec * 7) * 35;
    const windY = -12 + Math.cos(this.elapsedSec * 5.5) * 28;

    for (let i = 1; i < this.scarf.length; i++) {
      const node = this.scarf[i];
      const vx = (node.x - node.oldX) * 0.86;
      const vy = (node.y - node.oldY) * 0.86;
      node.oldX = node.x;
      node.oldY = node.y;
      node.x += vx + windX * dt * 1.4;
      node.y += vy + (240 + windY) * dt * 0.35;
    }

    const segLen = 6.4;
    for (let iter = 0; iter < 4; iter++) {
      this.scarf[0].x = anchorX;
      this.scarf[0].y = anchorY;
      for (let i = 0; i < this.scarf.length - 1; i++) {
        const a = this.scarf[i];
        const b = this.scarf[i + 1];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy) || 0.001;
        const diff = (dist - segLen) / dist;
        if (i === 0) {
          b.x -= dx * diff;
          b.y -= dy * diff;
        } else {
          a.x += dx * diff * 0.45;
          a.y += dy * diff * 0.45;
          b.x -= dx * diff * 0.55;
          b.y -= dy * diff * 0.55;
        }
      }
    }
  }

  private updateHazards(dt: number) {
    for (const h of this.hazards) {
      h.angle += dt * 9.5;
      h.x = h.originX + Math.sin(this.elapsedSec * h.speed) * h.moveRange;
      const dist = Math.hypot(this.px + this.pw / 2 - h.x, this.py + this.ph / 2 - h.y);
      if (dist < h.r + 14) {
        this.damagePlayer(18, this.px + this.pw / 2 < h.x ? -1 : 1);
      }
    }
  }

  private updateCollectibles(dt: number) {
    for (const c of this.collectibles) {
      if (c.collected) continue;
      c.bobPhase += dt * 4.2;
      const cy = c.y + Math.sin(c.bobPhase) * 5;
      const dist = Math.hypot(this.px + this.pw / 2 - c.x, this.py + this.ph / 2 - cy);
      if (dist < 32) {
        c.collected = true;
        const mult = 1 + this.profile.skillXp * 0.12;
        const val = Math.max(1, Math.round(c.value * mult));
        this.gemsCollected += val;
        this.xpCollected += val * 12;
        this.score += val * 50;
        soundEngine.playGemPickup();
        // Blue diamond sparkle burst!
        this.spawnBurst(c.x, cy, '#38BDF8', 12, 175);
      }
    }
  }

  private updateEnemies(dt: number) {
    const playerCx = this.px + this.pw / 2;
    const playerCy = this.py + this.ph / 2;

    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      if (e.hitFlash > 0) e.hitFlash -= dt;

      const enemyCx = e.x + e.w / 2;
      const enemyCy = e.y + e.h / 2;
      const dx = playerCx - enemyCx;
      const dy = playerCy - enemyCy;
      const dist = Math.hypot(dx, dy);

      if (e.kind === 'boss') {
        if (!this.bossActive) continue;
        this.updateBossBehavior(e, dt, dx);
        continue;
      }

      e.vx *= Math.pow(0.05, dt);

      if (e.kind === 'dragon') {
        // Winged Dragon floats gently in a figure-8 hover
        e.y = e.baseY + Math.sin(this.elapsedSec * 3.2 + e.id) * 14;
      }

      if (e.state === 'patrol') {
        const patrolSpeed = e.kind === 'boar' ? 75 : e.kind === 'armored' ? 55 : 85;
        e.x += e.facing * patrolSpeed * dt;
        if (e.x < e.patrolMin) {
          e.x = e.patrolMin;
          e.facing = 1;
        } else if (e.x + e.w > e.patrolMax) {
          e.x = e.patrolMax - e.w;
          e.facing = -1;
        }

        const aggroRange = e.kind === 'dragon' ? 420 : e.kind === 'boar' ? 280 : 190;
        if (dist < aggroRange && Math.abs(dy) < 150) {
          e.facing = dx >= 0 ? 1 : -1;
          e.state = 'windup';
          e.stateTimer = e.kind === 'dragon' ? 0.58 : e.kind === 'boar' ? 0.52 : 0.44;
          soundEngine.playEnemyAlert(e.kind);
          if (e.kind === 'boar') {
            this.spawnBurst(enemyCx - e.facing * 18, e.y + e.h - 4, '#94A3B8', 6, 90);
          }
        }
      } else if (e.state === 'windup') {
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          e.state = 'attack';
          if (e.kind === 'dragon') {
            e.stateTimer = 0.35;
            soundEngine.playFireball();
            // Fire-breathing dragon launches blazing fireball toward player!
            const aimAngle = Math.atan2(dy, dx);
            for (const spread of this.stage.difficulty >= 3 ? [-0.12, 0.12] : [0]) {
              const ang = aimAngle + spread;
              this.projectiles.push({
                x: enemyCx + e.facing * 24,
                y: enemyCy - 4,
                vx: Math.cos(ang) * 355,
                vy: Math.sin(ang) * 355,
                r: 10,
                fromPlayer: false,
                damage: 18,
                color: '#F97316',
                life: 2.4,
                isFire: true,
              });
            }
            this.spawnBurst(enemyCx + e.facing * 24, enemyCy - 4, '#F59E0B', 10, 140);
          } else if (e.kind === 'boar') {
            e.stateTimer = 0.56;
            soundEngine.playBoarCharge();
            // Boar charges rapidly to gore/ram!
            e.vx = e.facing * 435;
          } else {
            e.stateTimer = 0.28;
            e.vx = e.facing * (e.kind === 'armored' ? 230 : 310);
          }
        }
      } else if (e.state === 'attack') {
        e.x += e.vx * dt;
        e.x = Math.max(e.patrolMin, Math.min(e.patrolMax - e.w, e.x));
        if (e.kind === 'boar' && Math.random() < 0.45) {
          this.spawnBurst(enemyCx, e.y + e.h - 3, '#64748B', 2, 70);
        }
        if (
          e.kind !== 'dragon' &&
          this.rectsOverlap(this.px, this.py, this.pw, this.ph, e.x - 6, e.y, e.w + 12, e.h)
        ) {
          this.damagePlayer(e.kind === 'boar' ? 22 : e.kind === 'armored' ? 22 : 16, dx >= 0 ? 1 : -1);
        }
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          e.state = 'recover';
          e.stateTimer = e.kind === 'boar' ? 0.85 : 0.72;
        }
      } else if (e.state === 'recover') {
        e.x += e.vx * dt;
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          e.state = 'patrol';
        }
      }
    }
  }

  private updateBossBehavior(boss: Enemy, dt: number, dx: number) {
    const speedScale = 1 + (this.stage.difficulty - 1) * 0.1;

    if (boss.state === 'patrol') {
      boss.facing = dx >= 0 ? 1 : -1;
      boss.x += boss.facing * 95 * speedScale * dt;
      boss.x = Math.max(boss.patrolMin, Math.min(boss.patrolMax - boss.w, boss.x));
      boss.stateTimer -= dt;
      if (boss.stateTimer <= 0) {
        boss.attackPattern = (boss.attackPattern + 1) % 3;
        boss.state = 'windup';
        boss.stateTimer = 0.58;
      }
    } else if (boss.state === 'windup') {
      boss.facing = dx >= 0 ? 1 : -1;
      boss.stateTimer -= dt;
      if (boss.stateTimer <= 0) {
        boss.state = 'attack';
        if (boss.attackPattern === 0) {
          boss.vx = boss.facing * 520 * speedScale;
          boss.stateTimer = 0.42;
          soundEngine.playBoarCharge();
        } else if (boss.attackPattern === 1) {
          boss.vx = 0;
          boss.stateTimer = 0.35;
          const baseAng = boss.facing > 0 ? 0 : Math.PI;
          for (const offset of [-0.3, -0.08, 0.08, 0.3]) {
            this.projectiles.push({
              x: boss.x + boss.w / 2,
              y: boss.y + boss.h * 0.4,
              vx: Math.cos(baseAng + offset) * 390,
              vy: Math.sin(offset) * 320,
              r: 10,
              fromPlayer: false,
              damage: 18,
              color: '#F97316',
              life: 2.4,
              isFire: true,
            });
          }
          soundEngine.playFireball();
        } else {
          boss.vx = boss.facing * 180;
          boss.stateTimer = 0.45;
          this.shakeIntensity = 7;
          for (const dir of [-1, 1]) {
            this.projectiles.push({
              x: boss.x + boss.w / 2 + dir * 24,
              y: 392,
              vx: dir * 360 * speedScale,
              vy: 0,
              r: 14,
              fromPlayer: false,
              damage: 22,
              color: '#F59E0B',
              life: 2.0,
              isFire: true,
            });
          }
          soundEngine.playBossRoar();
        }
      }
    } else if (boss.state === 'attack') {
      boss.x += boss.vx * dt;
      boss.x = Math.max(boss.patrolMin, Math.min(boss.patrolMax - boss.w, boss.x));
      if (this.rectsOverlap(this.px, this.py, this.pw, this.ph, boss.x, boss.y, boss.w, boss.h)) {
        this.damagePlayer(24, dx >= 0 ? 1 : -1);
      }
      boss.stateTimer -= dt;
      if (boss.stateTimer <= 0) {
        boss.state = 'recover';
        boss.stateTimer = Math.max(0.55, 0.95 - this.stage.difficulty * 0.06);
      }
    } else if (boss.state === 'recover') {
      boss.stateTimer -= dt;
      if (boss.stateTimer <= 0) {
        boss.state = 'patrol';
        boss.stateTimer = 0.85;
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;

      if (p.isFire && Math.random() < 0.55) {
        this.particles.push({
          x: p.x,
          y: p.y,
          vx: (Math.random() - 0.5) * 40,
          vy: -30 - Math.random() * 40,
          size: 3 + Math.random() * 3,
          color: Math.random() > 0.4 ? '#F97316' : '#FDE047',
          alpha: 0.9,
          life: 0.22,
          maxLife: 0.22,
          gravity: -40,
        });
      }

      if (p.life <= 0) {
        this.projectiles.splice(i, 1);
        continue;
      }

      if (p.fromPlayer) {
        let consumed = false;
        for (const e of this.enemies) {
          if (e.hp <= 0) continue;
          if (p.hitIds && p.hitIds.has(e.id)) continue;
          if (this.rectsOverlap(p.x - p.r, p.y - p.r, p.r * 2, p.r * 2, e.x, e.y, e.w, e.h)) {
            this.damageEnemy(e, p.damage, p.vx >= 0 ? 160 : -160);
            if (p.piercing && p.hitIds) {
              p.hitIds.add(e.id);
            } else {
              consumed = true;
              break;
            }
          }
        }
        if (consumed) {
          this.projectiles.splice(i, 1);
        }
      } else {
        if (this.rectsOverlap(p.x - p.r, p.y - p.r, p.r * 2, p.r * 2, this.px, this.py, this.pw, this.ph)) {
          this.damagePlayer(p.damage, p.vx >= 0 ? 1 : -1);
          this.projectiles.splice(i, 1);
        }
      }
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.vy += pt.gravity * dt;
      pt.life -= dt;
      pt.alpha = Math.max(0, pt.life / pt.maxLife);
      if (pt.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.slashArcs.length - 1; i >= 0; i--) {
      this.slashArcs[i].life -= dt;
      if (this.slashArcs[i].life <= 0) this.slashArcs.splice(i, 1);
    }
    for (let i = this.clashFlashes.length - 1; i >= 0; i--) {
      this.clashFlashes[i].life -= dt;
      if (this.clashFlashes[i].life <= 0) this.clashFlashes.splice(i, 1);
    }
    for (let i = this.explosions.length - 1; i >= 0; i--) {
      this.explosions[i].life -= dt;
      if (this.explosions[i].life <= 0) this.explosions.splice(i, 1);
    }
  }

  private updateCamera(dt: number) {
    const viewW = this.canvas.width;
    const viewH = this.canvas.height;
    const targetX = this.bossActive
      ? this.arenaMinX - Math.max(0, (viewW - 880) / 2)
      : Math.max(0, this.px - viewW * 0.36 + this.facing * 65);
    const targetY = Math.max(-60, Math.min(180, this.py - viewH * 0.56));

    this.cameraX += (targetX - this.cameraX) * Math.min(1, 7.5 * dt);
    this.cameraY += (targetY - this.cameraY) * Math.min(1, 6.0 * dt);
    this.bgScroll = this.cameraX;
  }

  private spawnClashSparks(
    x: number,
    y: number,
    accentColor: string,
    intensity = 1,
    kind: 'clash' | 'deflect' | 'special' = 'clash'
  ) {
    const maxLife = 0.15;
    this.clashFlashes.push({
      x,
      y,
      angle: (Math.random() - 0.5) * 0.65,
      scale: intensity,
      color: accentColor,
      life: maxLife,
      maxLife,
    });

    const count = Math.round(14 * intensity);
    const sparkPalette = ['#FFFFFF', '#FEF08A', '#F97316', accentColor];
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.45;
      const spd = (240 + Math.random() * 340) * Math.min(1.4, intensity);
      const life = 0.18 + Math.random() * 0.24;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd - 65,
        size: 2.4 + Math.random() * 2.6,
        color: sparkPalette[i % sparkPalette.length],
        alpha: 1,
        life,
        maxLife: life,
        gravity: 560,
        kind: 'spark',
      });
    }

    this.callbacks.onCombatImpact?.({
      kind,
      screenX: x - this.cameraX,
      screenY: y - this.cameraY,
      facing: this.facing,
      color: this.weapon.slashColor,
      accent: accentColor,
      intensity,
    });
  }

  private spawnBurst(x: number, y: number, color: string, count: number, speed: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = (0.3 + Math.random() * 0.7) * speed;
      const maxLife = 0.25 + Math.random() * 0.32;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd - 40,
        size: 2.2 + Math.random() * 3.5,
        color,
        alpha: 1,
        life: maxLife,
        maxLife,
        gravity: 340,
      });
    }
  }

  private rectsOverlap(
    ax: number,
    ay: number,
    aw: number,
    ah: number,
    bx: number,
    by: number,
    bw: number,
    bh: number
  ): boolean {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
  }

  private emitHud() {
    const boss = this.enemies.find((e) => e.kind === 'boss');
    const progress = Math.max(
      0,
      Math.min(100, Math.round((this.px / (this.arenaMinX + 600)) * 100))
    );
    this.callbacks.onHudUpdate({
      hp: this.hp,
      maxHp: this.maxHp,
      dashCharge: 1 - this.dashCooldownTimer / this.dashMaxCooldown,
      specialCharge: 1 - this.specialCooldownTimer / this.specialMaxCooldown,
      combo: this.comboCount,
      gemsCollected: this.gemsCollected,
      xpCollected: this.xpCollected,
      score: Math.round(this.score),
      progress,
      bossActive: this.bossActive && !this.bossDefeated,
      bossNameAr: this.stage.bossNameAr,
      bossNameEn: this.stage.bossNameEn,
      bossHp: boss ? boss.hp : 0,
      bossMaxHp: boss ? boss.maxHp : 1,
      elapsedSec: Math.round(this.elapsedSec),
      equippedWeapon: this.weapon.id,
    });
  }

  private render() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.save();
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
    skyGrad.addColorStop(0, this.stage.skyTop);
    skyGrad.addColorStop(1, this.stage.skyBottom);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h);

    if (this.bgImage && this.bgImageLoaded && this.bgImage.naturalWidth > 0) {
      // Photorealistic moon & night city/temple skyline with subtle parallax drift
      const imgW = this.bgImage.naturalWidth;
      const imgH = this.bgImage.naturalHeight;
      const scale = Math.max((w + 180) / imgW, h / imgH);
      const drawW = imgW * scale;
      const drawH = imgH * scale;
      const maxShift = Math.max(0, drawW - w);
      const drift = Math.min(maxShift, (this.bgScroll * 0.04) % (maxShift + 1));
      const drawX = -drift;
      const drawY = (h - drawH) * 0.45;
      ctx.drawImage(this.bgImage, drawX, drawY, drawW, drawH);

      // Atmospheric night depth scrim so rooftop platforms & combat stay ultra readable
      const scrim = ctx.createLinearGradient(0, 0, 0, h);
      scrim.addColorStop(0, 'rgba(6, 10, 20, 0.22)');
      scrim.addColorStop(0.55, 'rgba(6, 10, 20, 0.34)');
      scrim.addColorStop(1, 'rgba(6, 10, 20, 0.72)');
      ctx.fillStyle = scrim;
      ctx.fillRect(0, 0, w, h);
    } else {
      // Fallback moon while backdrop image finishes loading
      const moonX = w * 0.76 - this.bgScroll * 0.03;
      const moonY = h * 0.22;
      const moonR = Math.min(w, h) * 0.11;
      const glow = ctx.createRadialGradient(moonX, moonY, moonR * 0.4, moonX, moonY, moonR * 2.4);
      glow.addColorStop(0, this.isSeasonal ? 'rgba(225,29,72,0.35)' : 'rgba(226,232,240,0.28)');
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(moonX, moonY, moonR * 2.4, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = this.stage.moonColor;
      ctx.beginPath();
      ctx.arc(moonX, moonY, moonR, 0, Math.PI * 2);
      ctx.fill();
    }

    const sx = (Math.random() - 0.5) * this.shakeIntensity;
    const sy = (Math.random() - 0.5) * this.shakeIntensity;
    ctx.translate(-this.cameraX + sx, -this.cameraY + sy);

    for (const p of this.platforms) {
      if (p.x + p.w < this.cameraX - 80 || p.x > this.cameraX + w + 80) continue;
      if (p.kind === 'crumbling' && p.crumbleState === 'fallen') continue;
      this.drawPlatform(ctx, p);
    }

    // Ground Landmines
    for (const m of this.mines) {
      if (m.state === 'exploded') continue;
      this.drawLandmine(ctx, m);
    }

    // Faceted Blue Gemstones
    for (const c of this.collectibles) {
      if (c.collected) continue;
      const cy = c.y + Math.sin(c.bobPhase) * 5;
      this.drawBlueGem(ctx, c.x, cy, c.bobPhase);
    }

    // Hazards (Spinning Shurikens)
    for (const hz of this.hazards) {
      ctx.save();
      ctx.translate(hz.x, hz.y);
      ctx.rotate(hz.angle);
      ctx.fillStyle = '#E2E8F0';
      for (let i = 0; i < 4; i++) {
        ctx.rotate(Math.PI / 2);
        ctx.beginPath();
        ctx.moveTo(0, -4);
        ctx.lineTo(hz.r, 0);
        ctx.lineTo(0, 4);
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = '#E11D48';
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Monsters & Boss
    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      this.drawEnemy(ctx, e);
    }

    // Remote Multiplayer Friends
    for (const peer of this.peers) {
      const peerSkin = SKINS.find((s) => s.id === peer.skin) || SKINS[0];
      const peerAttacking = peer.action === 'attack';
      this.drawNinjaCharacter(
        ctx,
        peer.x,
        peer.y,
        this.pw,
        this.ph,
        peer.facing,
        peerSkin,
        peer.weapon,
        null,
        peerAttacking,
        0.88,
        peer.displayName,
        false,
        peer.vx,
        peerAttacking ? (this.elapsedSec * 5) % 1 : 0,
        2
      );
    }

    // Dash Ghost Afterimages
    for (const g of this.ghosts) {
      ctx.save();
      ctx.globalAlpha = g.alpha * 0.5;
      ctx.fillStyle = g.color;
      ctx.beginPath();
      ctx.roundRect(g.x + 4, g.y + 4, this.pw - 8, this.ph - 6, 8);
      ctx.fill();
      ctx.restore();
    }

    // Local Cartoon Semi-Realistic Shinobi + Verlet Flowing Scarf + Distinct Weapon
    const invulnFlicker = this.invulnTimer > 0 && Math.floor(this.elapsedSec * 20) % 2 === 0;
    const localAttackProgress =
      this.attackTimer > 0
        ? Math.min(1, Math.max(0, 1 - this.attackTimer / Math.max(0.01, this.attackDuration)))
        : 0;
    this.drawNinjaCharacter(
      ctx,
      this.px,
      this.py,
      this.pw,
      this.ph,
      this.facing,
      this.skin,
      this.weapon.id,
      this.scarf,
      this.attackTimer > 0,
      invulnFlicker ? 0.55 : 1,
      undefined,
      this.playerHitFlash > 0,
      this.pvx,
      localAttackProgress,
      this.attackStyle
    );

    // Explosion blast rings
    for (const ex of this.explosions) {
      const prog = 1 - ex.life / ex.maxLife;
      const r = ex.maxR * prog;
      ctx.save();
      ctx.globalAlpha = 1 - prog;
      ctx.strokeStyle = '#FB923C';
      ctx.lineWidth = 6 * (1 - prog);
      ctx.beginPath();
      ctx.arc(ex.x, ex.y, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
      ctx.beginPath();
      ctx.arc(ex.x, ex.y, r * 0.72, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Battle-Grade Tapered Razor Crescent Slash Smears
    for (const s of this.slashArcs) {
      const alpha = s.life / s.maxLife;
      const prog = 1 - alpha;
      ctx.save();
      ctx.globalAlpha = Math.min(1, alpha * 1.15);
      ctx.translate(s.x, s.y);
      ctx.scale(s.facing, 1);
      ctx.shadowColor = s.accent;
      ctx.shadowBlur = 14;

      if (s.is360) {
        const r = s.range * (0.68 + prog * 0.14);
        ctx.rotate(prog * Math.PI * 1.6);
        for (let ring = 0; ring < 2; ring++) {
          const rot = ring * Math.PI;
          ctx.beginPath();
          ctx.arc(0, 0, r, rot - 0.9, rot + 1.3);
          ctx.arc(Math.cos(rot) * -6, Math.sin(rot) * -6, r * 0.72, rot + 1.3, rot - 0.9, true);
          ctx.closePath();
          ctx.fillStyle = s.accent;
          ctx.fill();
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      } else {
        const style = s.comboStyle ?? 0;
        const outerR = s.range * (0.82 + prog * 0.12);
        const startA =
          style === 1 ? 1.25 + s.angleOffset : -1.35 + s.angleOffset;
        const endA =
          style === 1 ? -1.35 + s.angleOffset : 1.25 + s.angleOffset;
        const ccw = style === 1;
        const midA = (startA + endA) * 0.5;
        const innerOffset = outerR * 0.24;
        const ix = Math.cos(midA) * -innerOffset;
        const iy = Math.sin(midA) * -innerOffset;

        // Outer luminous blade energy crescent
        ctx.beginPath();
        ctx.arc(0, 0, outerR, startA, endA, ccw);
        ctx.arc(ix, iy, outerR * 0.86, endA, startA, !ccw);
        ctx.closePath();
        ctx.fillStyle = s.accent;
        ctx.fill();

        // Inner white-hot steel edge crescent
        ctx.beginPath();
        ctx.arc(0, 0, outerR * 0.97, startA + (ccw ? -0.18 : 0.18), endA - (ccw ? -0.1 : 0.1), ccw);
        ctx.arc(ix * 0.55, iy * 0.55, outerR * 0.9, endA - (ccw ? -0.1 : 0.1), startA + (ccw ? -0.18 : 0.18), !ccw);
        ctx.closePath();
        ctx.fillStyle = '#FFFFFF';
        ctx.fill();

        // Crisp directional speed-slash lines
        ctx.strokeStyle = s.color;
        ctx.lineWidth = 2.2 * alpha;
        ctx.beginPath();
        ctx.moveTo(Math.cos(endA - 0.25) * outerR * 0.55, Math.sin(endA - 0.25) * outerR * 0.55);
        ctx.lineTo(Math.cos(endA) * (outerR + 12), Math.sin(endA) * (outerR + 12));
        ctx.moveTo(Math.cos(midA) * outerR * 0.7, Math.sin(midA) * outerR * 0.7);
        ctx.lineTo(Math.cos(midA) * (outerR + 16), Math.sin(midA) * (outerR + 16));
        ctx.stroke();
      }
      ctx.restore();
    }

    // Projectiles (Fireballs & Crescent Waves)
    for (const p of this.projectiles) {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 12;
      if (p.isFire) {
        // Stylized cartoon fireball with bright core
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#FEF08A';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 0.55, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.fromPlayer && p.r > 15) {
        const dir = p.vx >= 0 ? 1 : -1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, dir > 0 ? -1.1 : Math.PI - 1.1, dir > 0 ? 1.1 : Math.PI + 1.1);
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#F8FAFC';
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // World-Space Sword Clash Star Flashes
    for (const cf of this.clashFlashes) {
      const alpha = cf.life / cf.maxLife;
      const prog = 1 - alpha;
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(cf.x, cf.y);
      ctx.rotate(cf.angle);
      ctx.shadowColor = cf.color;
      ctx.shadowBlur = 16;

      // Crisp shock ring
      ctx.strokeStyle = cf.color;
      ctx.lineWidth = 2.5 * alpha;
      ctx.beginPath();
      ctx.arc(0, 0, (10 + prog * 34) * cf.scale, 0, Math.PI * 2);
      ctx.stroke();

      // Anamorphic X-clash katana star flash
      const arm = (22 + prog * 18) * cf.scale;
      ctx.fillStyle = '#FFFFFF';
      for (const rot of [0.35, -0.35, 1.9, -1.2]) {
        ctx.save();
        ctx.rotate(rot);
        ctx.beginPath();
        ctx.moveTo(-arm, 0);
        ctx.lineTo(0, -2.5 * alpha * cf.scale);
        ctx.lineTo(arm, 0);
        ctx.lineTo(0, 2.5 * alpha * cf.scale);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();
    }

    for (const pt of this.particles) {
      ctx.save();
      ctx.globalAlpha = pt.alpha;
      if (pt.kind === 'spark') {
        const speed = Math.hypot(pt.vx, pt.vy);
        const angle = Math.atan2(pt.vy, pt.vx);
        const streakLen = Math.max(8, Math.min(26, speed * 0.048));
        ctx.translate(pt.x, pt.y);
        ctx.rotate(angle);
        ctx.shadowColor = pt.color;
        ctx.shadowBlur = 8;
        ctx.strokeStyle = pt.color;
        ctx.lineWidth = Math.max(1.5, pt.size * 0.72 * pt.alpha);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-streakLen, 0);
        ctx.lineTo(2, 0);
        ctx.stroke();

        // White-hot tip
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(1, 0, Math.max(1, pt.size * 0.38), 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = pt.color;
        ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
      }
      ctx.restore();
    }

    ctx.restore();

    const mist = ctx.createLinearGradient(0, h - 90, 0, h);
    mist.addColorStop(0, 'rgba(9,13,22,0)');
    mist.addColorStop(1, 'rgba(9,13,22,0.72)');
    ctx.fillStyle = mist;
    ctx.fillRect(0, h - 90, w, 90);
  }

  private drawBlueGem(ctx: CanvasRenderingContext2D, x: number, y: number, phase: number) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.sin(phase * 0.5) * 0.14);

    // Subtle azure aura
    ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
    ctx.beginPath();
    ctx.arc(0, 0, 14, 0, Math.PI * 2);
    ctx.fill();

    // Faceted Sapphire Gem body
    const grad = ctx.createLinearGradient(-8, -11, 8, 11);
    grad.addColorStop(0, '#7DD3FC');
    grad.addColorStop(0.5, '#0EA5E9');
    grad.addColorStop(1, '#1D4ED8');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(9, -3);
    ctx.lineTo(7, 7);
    ctx.lineTo(0, 12);
    ctx.lineTo(-7, 7);
    ctx.lineTo(-9, -3);
    ctx.closePath();
    ctx.fill();

    // Crisp cartoon outline + bright upper facet
    ctx.strokeStyle = '#BAE6FD';
    ctx.lineWidth = 1.6;
    ctx.stroke();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
    ctx.beginPath();
    ctx.moveTo(0, -10);
    ctx.lineTo(5, -3);
    ctx.lineTo(0, 0);
    ctx.lineTo(-5, -3);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  private drawLandmine(ctx: CanvasRenderingContext2D, m: Landmine) {
    ctx.save();
    ctx.translate(m.x, m.y);
    const blink =
      m.state === 'triggered'
        ? Math.floor(this.elapsedSec * 22) % 2 === 0
        : Math.floor(this.elapsedSec * 3) % 2 === 0;

    // Iron dome base
    ctx.fillStyle = '#1E293B';
    ctx.strokeStyle = '#020617';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 12, Math.PI, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Metallic spikes
    ctx.fillStyle = '#94A3B8';
    for (const ang of [-2.4, -1.57, -0.75]) {
      ctx.beginPath();
      ctx.moveTo(Math.cos(ang) * 10, Math.sin(ang) * 10);
      ctx.lineTo(Math.cos(ang) * 16, Math.sin(ang) * 16);
      ctx.lineTo(Math.cos(ang + 0.22) * 10, Math.sin(ang + 0.22) * 10);
      ctx.closePath();
      ctx.fill();
    }

    // Blinking crimson warning core
    ctx.fillStyle = blink ? '#EF4444' : '#7F1D1D';
    ctx.beginPath();
    ctx.arc(0, -4, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawParallaxLayer(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    speed: number,
    color: string,
    baseRatio: number,
    amp: number
  ) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, h);
    const step = 90;
    const offset = (this.bgScroll * speed) % (step * 4);
    for (let x = -step * 4; x <= w + step * 4; x += step) {
      const idx = Math.floor((x + this.bgScroll * speed) / step);
      const y = h * baseRatio - Math.abs(Math.sin(idx * 0.7)) * amp;
      ctx.lineTo(x - offset + (this.bgScroll * speed) % step, y);
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
  }

  private drawPagodaSilhouettes(ctx: CanvasRenderingContext2D, w: number, h: number, speed: number) {
    const spacing = 420;
    const startIdx = Math.floor((this.bgScroll * speed) / spacing) - 1;
    for (let i = startIdx; i < startIdx + Math.ceil(w / spacing) + 3; i++) {
      const px = i * spacing - this.bgScroll * speed;
      const py = h * 0.72;
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(px + 30, py - 120, 72, 160);
      for (let tier = 0; tier < 3; tier++) {
        const ty = py - 45 - tier * 42;
        const tw = 112 - tier * 14;
        const tx = px + 66 - tw / 2;
        ctx.beginPath();
        ctx.moveTo(tx - 10, ty + 14);
        ctx.lineTo(tx + tw / 2, ty - 8);
        ctx.lineTo(tx + tw + 10, ty + 14);
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = 'rgba(245, 158, 11, 0.45)';
      ctx.fillRect(px + 62, py - 70, 8, 12);
    }
  }

  private drawPlatform(ctx: CanvasRenderingContext2D, p: Platform) {
    const shakeX = p.kind === 'crumbling' && p.crumbleState === 'shaking' ? (Math.random() - 0.5) * 4 : 0;
    const x = p.x + shakeX;
    const y = p.y;

    if (p.kind === 'wall') {
      ctx.fillStyle = '#1E293B';
      ctx.fillRect(x, y, p.w, p.h);
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, p.w, p.h);
      return;
    }

    ctx.fillStyle = p.kind === 'crumbling' ? '#334155' : '#111827';
    ctx.fillRect(x, y, p.w, p.h);

    ctx.fillStyle = p.kind === 'moving' ? '#0F766E' : p.kind === 'arena' ? '#4C0519' : '#1E293B';
    ctx.beginPath();
    ctx.moveTo(x - 10, y + 6);
    ctx.lineTo(x + 6, y - 6);
    ctx.lineTo(x + p.w - 6, y - 6);
    ctx.lineTo(x + p.w + 10, y + 6);
    ctx.lineTo(x + p.w, y + 12);
    ctx.lineTo(x, y + 12);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = p.kind === 'moving' ? '#5EEAD4' : '#94A3B8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x - 8, y + 5);
    ctx.lineTo(x + 6, y - 6);
    ctx.lineTo(x + p.w - 6, y - 6);
    ctx.lineTo(x + p.w + 8, y + 5);
    ctx.stroke();

    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    for (let tx = x + 16; tx < x + p.w - 16; tx += 28) {
      ctx.fillRect(tx, y + 14, 2, Math.min(28, p.h - 14));
    }
  }

  private drawWeaponShape(
    ctx: CanvasRenderingContext2D,
    weaponId: string,
    isAttacking: boolean,
    attackProgress = 0,
    attackStyle = 0
  ) {
    ctx.save();

    // Fierce interpolated sword swing arc across the attack duration
    let swingAngle = -0.45 + Math.sin(this.elapsedSec * 4) * 0.05;
    if (isAttacking) {
      const eased = 1 - Math.pow(1 - Math.min(1, Math.max(0, attackProgress)), 2.4);
      if (attackStyle === 1) {
        // Reverse rising slash
        swingAngle = 1.65 - eased * 3.1;
      } else if (attackStyle === 2) {
        // Wide execution cleave
        swingAngle = -2.45 + eased * 4.2;
      } else {
        // Overhead downward cleave
        swingAngle = -2.15 + eased * 3.5;
      }
    }
    ctx.rotate(swingAngle);

    if (weaponId === 'kodachi') {
      // Twin Assassin Kodachi — primary diamond-hilt dagger + off-hand reverse blade
      ctx.fillStyle = '#1E293B';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.fillRect(-5, -2.5, 9, 5);
      ctx.strokeRect(-5, -2.5, 9, 5);

      // Ring pommel
      ctx.strokeStyle = '#FB7185';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(-7, 0, 2.6, 0, Math.PI * 2);
      ctx.stroke();

      // Angled crimson guard
      ctx.fillStyle = '#E11D48';
      ctx.fillRect(3, -5, 3, 10);

      // Primary sharp beveled dagger blade
      ctx.beginPath();
      ctx.moveTo(6, -3);
      ctx.lineTo(24, -1.5);
      ctx.lineTo(29, 0.5);
      ctx.lineTo(24, 2.6);
      ctx.lineTo(6, 2.5);
      ctx.closePath();
      ctx.fillStyle = '#F8FAFC';
      ctx.fill();
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // Glowing crimson fuller groove
      ctx.strokeStyle = '#FB7185';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(8, 0);
      ctx.lineTo(22, 0);
      ctx.stroke();

      // Secondary reverse-grip off-hand dagger
      ctx.save();
      ctx.rotate(isAttacking ? -2.25 : -2.6);
      ctx.fillStyle = '#9F1239';
      ctx.fillRect(0, -2, 6, 4);
      ctx.beginPath();
      ctx.moveTo(6, -2.4);
      ctx.lineTo(22, -0.5);
      ctx.lineTo(25, 1.5);
      ctx.lineTo(6, 2.2);
      ctx.closePath();
      ctx.fillStyle = '#FDA4AF';
      ctx.fill();
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.restore();
    } else if (weaponId === 'kusarigama') {
      // Kusarigama — iron-banded shaft, razor emerald kama sickle, & whipping spiked fundo chain
      ctx.fillStyle = '#451A03';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.roundRect(-6, -2.5, 23, 5, 2);
      ctx.fill();
      ctx.stroke();

      // Iron collar bands
      ctx.fillStyle = '#94A3B8';
      ctx.fillRect(-1, -3, 3, 6);
      ctx.fillRect(12, -3, 3, 6);

      // Razor hooked kama blade with steel spine + emerald edge
      ctx.beginPath();
      ctx.moveTo(15, -2.5);
      ctx.quadraticCurveTo(28, -4, 30, 12);
      ctx.quadraticCurveTo(23, 5, 14, 2.5);
      ctx.closePath();
      ctx.fillStyle = '#CBD5E1';
      ctx.fill();
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      ctx.strokeStyle = '#34D399';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(16, 2);
      ctx.quadraticCurveTo(23, 5, 29, 11);
      ctx.stroke();

      // Articulated chain + spiked iron fundo weight whipping out on attacks
      const chainLen = isAttacking ? 34 : 18;
      const chainDrop = isAttacking ? -4 : 16;
      ctx.strokeStyle = '#CBD5E1';
      ctx.lineWidth = 1.8;
      ctx.setLineDash([3, 2]);
      ctx.beginPath();
      ctx.moveTo(-6, 0);
      ctx.quadraticCurveTo(-6 - chainLen * 0.5, chainDrop * 0.6, -6 - chainLen, chainDrop);
      ctx.stroke();
      ctx.setLineDash([]);

      const wx = -6 - chainLen;
      const wy = chainDrop;
      ctx.fillStyle = '#334155';
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(wx, wy, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    } else if (weaponId === 'odachi') {
      // Lunar Odachi — long wrapped two-handed hilt, tassel, ornate gold tsuba, massive curved greatsword
      ctx.fillStyle = '#7F1D1D';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.fillRect(-11, -3, 14, 6);
      ctx.strokeRect(-11, -3, 14, 6);

      // Trailing crimson pommel tassel
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(-11, 1);
      ctx.quadraticCurveTo(-18, 5, -22, 10);
      ctx.stroke();

      // Ornate golden dragon tsuba guard
      ctx.fillStyle = '#F59E0B';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(2, -7.5, 4.5, 15, 2);
      ctx.fill();
      ctx.stroke();

      // Massive broad curved greatsword blade (steel spine + razor golden-silver edge)
      ctx.beginPath();
      ctx.moveTo(6.5, -4);
      ctx.quadraticCurveTo(28, -6, 48, -12);
      ctx.lineTo(54, -7);
      ctx.quadraticCurveTo(30, 1, 6.5, 3.2);
      ctx.closePath();
      ctx.fillStyle = '#1E293B';
      ctx.fill();
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Gleaming razor cutting edge + golden fuller
      ctx.strokeStyle = '#FEF3C7';
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.moveTo(7, 2.2);
      ctx.quadraticCurveTo(30, 0.2, 53, -7);
      ctx.stroke();

      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(10, -1.2);
      ctx.quadraticCurveTo(27, -2.8, 43, -7.5);
      ctx.stroke();
    } else {
      // Shadow Katana — diamond-wrapped tsuka hilt, gold tsuba, curved spine & gleaming hamon edge
      ctx.fillStyle = '#1E293B';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.fillRect(-8, -2.5, 10, 5);
      ctx.strokeRect(-8, -2.5, 10, 5);

      // Diamond tsuka-ito wrap ticks
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1.1;
      for (let tx = -6; tx <= 0; tx += 3) {
        ctx.beginPath();
        ctx.moveTo(tx, -2);
        ctx.lineTo(tx + 1.5, 2);
        ctx.stroke();
      }

      // Circular sculpted tsuba handguard
      ctx.fillStyle = '#F59E0B';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.roundRect(1.5, -6, 3.5, 12, 1.5);
      ctx.fill();
      ctx.stroke();

      // Curved forged steel katana blade + sharp kissaki tip
      ctx.beginPath();
      ctx.moveTo(5, -2.6);
      ctx.quadraticCurveTo(22, -4, 37, -8.5);
      ctx.lineTo(42, -5);
      ctx.quadraticCurveTo(23, 0.5, 5, 2.2);
      ctx.closePath();
      ctx.fillStyle = '#334155';
      ctx.fill();
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // Razor-bright hamon edge
      ctx.strokeStyle = '#E0F2FE';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(5.5, 1.5);
      ctx.quadraticCurveTo(23, 0, 41, -5);
      ctx.stroke();
    }

    ctx.restore();
  }

  private drawNinjaCharacter(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    facing: number,
    skin: SkinDefinition,
    weaponId: string,
    scarfNodes: ScarfNode[] | null,
    isAttacking: boolean,
    alpha: number,
    label?: string,
    hitFlash = false,
    vx = 0,
    attackProgress = 0,
    attackStyle = 0
  ) {
    ctx.save();
    ctx.globalAlpha = alpha;

    // 1. Dynamic Verlet flowing scarf behind character
    if (scarfNodes && scarfNodes.length > 1) {
      ctx.strokeStyle = '#020617';
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (let i = 0; i < scarfNodes.length - 1; i++) {
        ctx.lineWidth = Math.max(4, 9.5 - i * 0.65);
        ctx.beginPath();
        ctx.moveTo(scarfNodes[i].x, scarfNodes[i].y);
        ctx.lineTo(scarfNodes[i + 1].x, scarfNodes[i + 1].y);
        ctx.stroke();
      }
      ctx.strokeStyle = hitFlash ? '#FFFFFF' : skin.scarfColor;
      for (let i = 0; i < scarfNodes.length - 1; i++) {
        ctx.lineWidth = Math.max(2.2, 7.2 - i * 0.6);
        ctx.beginPath();
        ctx.moveTo(scarfNodes[i].x, scarfNodes[i].y);
        ctx.lineTo(scarfNodes[i + 1].x, scarfNodes[i + 1].y);
        ctx.stroke();
      }
    } else {
      ctx.strokeStyle = skin.scarfColor;
      ctx.lineWidth = 5.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x + w / 2, y + 16);
      ctx.quadraticCurveTo(x + w / 2 - facing * 18, y + 12, x + w / 2 - facing * 34, y + 22);
      ctx.stroke();
    }

    const cx = x + w / 2;
    const cy = y + h / 2 + (isAttacking ? 3 : 0);

    ctx.translate(cx, cy);
    ctx.scale(facing, 1);

    // Aggressive battle lean during sprinting & sword strikes
    const attackLean = isAttacking ? 0.24 + Math.sin(attackProgress * Math.PI) * 0.14 : 0;
    const lean = Math.max(attackLean, Math.min(0.2, Math.abs(vx) / 2000));
    ctx.rotate(lean);

    // Back scabbard (Saya)
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-12, -16);
    ctx.lineTo(6, 8);
    ctx.stroke();

    // Articulated cartoon/semi-realistic legs & shin guards (wider planted combat lunge on strikes)
    const stride = isAttacking ? 5.5 : Math.sin(this.elapsedSec * 15) * (Math.abs(vx) > 30 ? 6 : 0);
    ctx.lineWidth = 1.8;
    ctx.strokeStyle = '#020617';

    // Back leg
    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.beginPath();
    ctx.roundRect(-9 - stride * 0.7, 7, 7.5, 16, 3);
    ctx.fill();
    ctx.stroke();

    // Front leg + shin wrap + tabi boot
    ctx.beginPath();
    ctx.roundRect(2 + stride * 0.7, 7, 7.5, 16, 3);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = skin.trimColor;
    ctx.fillRect(2 + stride * 0.7, 14, 7.5, 4);

    // Stylized Kimono / Shinobi Torso with layered chest wrap & belt sash
    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.beginPath();
    ctx.roundRect(-11, -11, 22, 22, 5);
    ctx.fill();
    ctx.stroke();

    // Kimono V-lapel highlight
    ctx.strokeStyle = skin.trimColor;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-6, -10);
    ctx.lineTo(1, 2);
    ctx.lineTo(6, -10);
    ctx.stroke();

    // Shoulder guard & sash belt
    ctx.fillStyle = skin.trimColor;
    ctx.beginPath();
    ctx.roundRect(-12, -11, 8, 6, 2);
    ctx.fill();
    ctx.fillStyle = skin.scarfColor;
    ctx.fillRect(-11, 5, 22, 3.8);

    // Expressive Cartoon Semi-Realistic Head + Mask + Headband
    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.strokeStyle = '#020617';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -17, 11.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Subtle warm skin slit around eyes for semi-realistic look
    ctx.fillStyle = '#E2B49A';
    ctx.beginPath();
    ctx.roundRect(-2, -20, 11, 5.5, 2);
    ctx.fill();

    // Headband + metallic forehead plate
    ctx.fillStyle = skin.scarfColor;
    ctx.fillRect(-11.5, -24, 23, 3.8);
    ctx.fillStyle = '#94A3B8';
    ctx.fillRect(2, -24.5, 7, 4.5);

    // Focused angled anime eye + brow
    ctx.fillStyle = '#020617';
    ctx.fillRect(3, -18.5, 6, 3);
    ctx.fillStyle = skin.eyeColor;
    ctx.fillRect(4.5, -18, 3.5, 2);

    // Articulated sword shoulder + extended forearm + battle weapon
    ctx.save();
    ctx.translate(4, -3);
    const armAim = isAttacking
      ? (attackStyle === 1
          ? 0.55 - attackProgress * 1.15
          : -0.65 + attackProgress * 1.25)
      : -0.1;
    ctx.rotate(armAim);

    // Upper arm + forearm bracer
    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.strokeStyle = '#020617';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.roundRect(-2, -3, 12, 6, 2.5);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = skin.trimColor;
    ctx.beginPath();
    ctx.roundRect(4, -3.2, 7.5, 6.4, 2);
    ctx.fill();

    // Hand grip at wrist + Weapon sweep
    ctx.translate(11, 0);
    this.drawWeaponShape(ctx, weaponId, isAttacking, attackProgress, attackStyle);
    ctx.restore();

    ctx.restore();

    if (label) {
      ctx.save();
      ctx.font = '700 12px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#E2E8F0';
      ctx.fillText(label, x + w / 2, y - 12);
      ctx.restore();
    }
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy) {
    ctx.save();
    const cx = e.x + e.w / 2;
    const cy = e.y + e.h / 2;

    if (e.state === 'windup') {
      ctx.strokeStyle = e.kind === 'dragon' ? '#F97316' : '#F43F5E';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(cx, cy, Math.max(e.w, e.h) * 0.72, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.translate(cx, cy);
    ctx.scale(e.facing, 1);

    const flash = e.hitFlash > 0;

    if (e.kind === 'dragon') {
      // Stylized Winged Fire-Breathing Dragon!
      const wingFlap = Math.sin(this.elapsedSec * 12 + e.id) * 12;

      // Wings
      ctx.fillStyle = flash ? '#FFFFFF' : '#7F1D1D';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-4, -2);
      ctx.lineTo(-24, -22 + wingFlap);
      ctx.lineTo(-10, -4 + wingFlap * 0.4);
      ctx.lineTo(-22, 6);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Scaled serpentine body & tail
      ctx.fillStyle = flash ? '#FFFFFF' : '#991B1B';
      ctx.beginPath();
      ctx.ellipse(-2, 4, 18, 12, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Tail
      ctx.beginPath();
      ctx.moveTo(-16, 6);
      ctx.quadraticCurveTo(-28, 12, -32, 2);
      ctx.lineWidth = 5;
      ctx.strokeStyle = flash ? '#FFFFFF' : '#B91C1C';
      ctx.stroke();

      // Snout & horned head
      ctx.fillStyle = flash ? '#FFFFFF' : '#DC2626';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(6, -12, 20, 14, 4);
      ctx.fill();
      ctx.stroke();

      // Horns
      ctx.fillStyle = '#FDE68A';
      ctx.beginPath();
      ctx.moveTo(8, -12);
      ctx.lineTo(2, -22);
      ctx.lineTo(13, -12);
      ctx.closePath();
      ctx.fill();

      // Glowing amber eye + fire mouth glow
      ctx.fillStyle = '#FEF08A';
      ctx.fillRect(15, -9, 4, 3);
      if (e.state === 'windup') {
        ctx.fillStyle = '#F97316';
        ctx.beginPath();
        ctx.arc(25, -3, 5, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (e.kind === 'boar') {
      // Charging Wild Shadow Boar with tusks!
      ctx.fillStyle = flash ? '#FFFFFF' : '#292524';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 2;

      // Bristled back ridge
      ctx.fillStyle = flash ? '#FFFFFF' : '#44403C';
      ctx.beginPath();
      ctx.moveTo(-18, -8);
      ctx.lineTo(-10, -18);
      ctx.lineTo(-2, -14);
      ctx.lineTo(6, -18);
      ctx.lineTo(14, -10);
      ctx.closePath();
      ctx.fill();

      // Stocky body
      ctx.fillStyle = flash ? '#FFFFFF' : '#1C1917';
      ctx.beginPath();
      ctx.roundRect(-20, -11, 38, 24, 9);
      ctx.fill();
      ctx.stroke();

      // Legs
      const runLeg = e.state === 'attack' ? Math.sin(this.elapsedSec * 24) * 5 : 0;
      ctx.fillRect(-14 + runLeg, 10, 6, 8);
      ctx.fillRect(6 - runLeg, 10, 6, 8);

      // Curved sharp ivory tusks!
      ctx.fillStyle = '#FEF3C7';
      ctx.beginPath();
      ctx.moveTo(15, 2);
      ctx.quadraticCurveTo(26, 2, 24, -8);
      ctx.lineTo(18, -2);
      ctx.closePath();
      ctx.fill();

      // Fierce crimson eye
      ctx.fillStyle = '#EF4444';
      ctx.fillRect(9, -6, 5, 3);
    } else if (e.kind === 'boss') {
      // Imposing Shogun / Dragon-Horned Boss
      ctx.fillStyle = flash ? '#FFFFFF' : '#1E1B2E';
      ctx.fillRect(-e.w / 2, -e.h / 2 + 12, e.w, e.h - 12);
      ctx.strokeStyle = '#E11D48';
      ctx.lineWidth = 2;
      ctx.strokeRect(-e.w / 2, -e.h / 2 + 12, e.w, e.h - 12);

      ctx.fillStyle = flash ? '#FFFFFF' : '#0F172A';
      ctx.beginPath();
      ctx.arc(0, -e.h / 2 + 12, 17, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-12, -e.h / 2 + 4);
      ctx.lineTo(-22, -e.h / 2 - 14);
      ctx.moveTo(12, -e.h / 2 + 4);
      ctx.lineTo(22, -e.h / 2 - 14);
      ctx.stroke();

      ctx.fillStyle = '#F43F5E';
      ctx.fillRect(4, -e.h / 2 + 10, 7, 3);
    } else {
      ctx.fillStyle = flash ? '#FFFFFF' : e.kind === 'armored' ? '#334155' : '#1F2937';
      ctx.beginPath();
      ctx.roundRect(-e.w / 2, -e.h / 2 + 8, e.w, e.h - 8, 4);
      ctx.fill();
      ctx.strokeStyle = e.kind === 'armored' ? '#F59E0B' : '#E11D48';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = flash ? '#FFFFFF' : '#475569';
      ctx.beginPath();
      ctx.moveTo(-e.w * 0.72, -e.h / 2 + 10);
      ctx.lineTo(0, -e.h / 2 - 6);
      ctx.lineTo(e.w * 0.72, -e.h / 2 + 10);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#FB7185';
      ctx.fillRect(3, -e.h / 2 + 12, 5, 2.5);
    }

    ctx.restore();

    if (e.kind !== 'boss' && e.hp < e.maxHp) {
      const bw = e.w + 8;
      const bx = e.x + e.w / 2 - bw / 2;
      const by = e.y - 12;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.fillRect(bx, by, bw, 4);
      ctx.fillStyle = '#E11D48';
      ctx.fillRect(bx, by, bw * (e.hp / e.maxHp), 4);
    }
  }
}
