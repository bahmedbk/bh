import moonlitBgUrl from '../assets/images/arena_moonlit_night_1794531264735.jpg';
import { SKINS } from '../data/gameCatalog';
import type {
  ArenaGunId,
  ArenaHudSnapshot,
  ArenaKillEvent,
  ArenaStandingsEntry,
  ArenaWeaponSlotSnapshot,
  EffectsQuality,
  Language,
  MatchResult,
  PlayerProfile,
  RoomPlayer,
  SkinDefinition,
} from '../types/game';
import { soundEngine } from './audio';

export interface ArenaGunSpec {
  id: ArenaGunId;
  nameAr: string;
  nameEn: string;
  clipSize: number;
  fireInterval: number;
  reloadTime: number;
  projectileSpeed: number;
  damage: number;
  splashRadius: number;
  pellets: number;
  spreadRad: number;
  color: string;
  tier: number;
}

export const ARENA_GUNS: Record<ArenaGunId, ArenaGunSpec> = {
  shuriken_smg: {
    id: 'shuriken_smg',
    nameAr: 'قاذف الشوريكين',
    nameEn: 'Shuriken Repeater',
    clipSize: 24,
    fireInterval: 0.16,
    reloadTime: 1.1,
    projectileSpeed: 760,
    damage: 16,
    splashRadius: 0,
    pellets: 1,
    spreadRad: 0.04,
    color: '#38BDF8',
    tier: 1,
  },
  venom_kunai: {
    id: 'venom_kunai',
    nameAr: 'كوناي السم المزدوج',
    nameEn: 'Twin Venom Kunai',
    clipSize: 30,
    fireInterval: 0.13,
    reloadTime: 1.2,
    projectileSpeed: 830,
    damage: 12,
    splashRadius: 0,
    pellets: 2,
    spreadRad: 0.07,
    color: '#34D399',
    tier: 2,
  },
  fire_crossbow: {
    id: 'fire_crossbow',
    nameAr: 'النشاب الناري',
    nameEn: 'Explosive Crossbow',
    clipSize: 8,
    fireInterval: 0.48,
    reloadTime: 1.4,
    projectileSpeed: 710,
    damage: 38,
    splashRadius: 56,
    pellets: 1,
    spreadRad: 0.012,
    color: '#FB923C',
    tier: 3,
  },
  dragon_cannon: {
    id: 'dragon_cannon',
    nameAr: 'مدفع التنين',
    nameEn: 'Dragon Cannon',
    clipSize: 5,
    fireInterval: 0.72,
    reloadTime: 1.55,
    projectileSpeed: 620,
    damage: 56,
    splashRadius: 96,
    pellets: 1,
    spreadRad: 0.015,
    color: '#F43F5E',
    tier: 4,
  },
};

interface Vec2 {
  x: number;
  y: number;
}

interface WeaponSlotState {
  gunId: ArenaGunId;
  ammo: number;
  reloadTimer: number;
}

interface RockPolygon {
  points: Vec2[];
  kind: 'peak_wall' | 'cave_roof' | 'outcrop' | 'arch';
  hasGrass: boolean;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  cracks: { x1: number; y1: number; x2: number; y2: number }[];
  grassTufts: { x: number; y: number; h: number; phase: number }[];
}

interface MountainBridge {
  x1: number;
  x2: number;
  y: number;
  sag: number;
  kind: 'rope' | 'stone';
}

interface MountainLantern {
  x: number;
  y: number;
  phase: number;
}

interface MistRibbon {
  x: number;
  y: number;
  w: number;
  h: number;
  speed: number;
  alpha: number;
}

type PickupKind = 'medkit' | 'venom_kunai' | 'fire_crossbow' | 'dragon_cannon' | 'grenades' | 'fuel';

interface ArenaPickup {
  id: number;
  x: number;
  y: number;
  kind: PickupKind;
  active: boolean;
  respawnTimer: number;
  bobPhase: number;
}

interface WeaponDrop {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  gunId: ArenaGunId;
  ammo: number;
  life: number;
  pickupDelay: number;
  bobPhase: number;
}

interface ArenaProjectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  ownerId: string;
  ownerName: string;
  gunId: ArenaGunId;
  damage: number;
  splashRadius: number;
  color: string;
  life: number;
}

interface ArenaGrenade {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  ownerId: string;
  ownerName: string;
  fuse: number;
  bounces: number;
}

interface ArenaParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  gravity: number;
}

interface ArenaBlastRing {
  x: number;
  y: number;
  maxR: number;
  color: string;
  life: number;
  maxLife: number;
}

interface ArenaBot {
  id: string;
  name: string;
  skin: SkinDefinition;
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  fuel: number;
  aimAngle: number;
  gunId: ArenaGunId;
  ammo: number;
  fireCd: number;
  reloadTimer: number;
  grenades: number;
  grenadeCd: number;
  jetpackActive: boolean;
  grounded: boolean;
  alive: boolean;
  respawnTimer: number;
  spawnShield: number;
  kills: number;
  deaths: number;
  hitFlash: number;
  scarfPoints: Vec2[];
  aiDecisionTimer: number;
  aiTargetX: number;
  aiTargetY: number;
}

export interface ArenaCallbacks {
  onHudUpdate: (snap: ArenaHudSnapshot) => void;
  onMatchComplete: (result: MatchResult) => void;
  onLocalStateSync?: (payload: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    facing: number;
    action: string;
    hp: number;
    maxHp: number;
    score: number;
    progress: number;
    aimAngle: number;
    jetpackActive: boolean;
    arenaGun: ArenaGunId;
    alive: boolean;
  }) => void;
  onArenaShot?: (x: number, y: number, angle: number, gunId: ArenaGunId) => void;
  onArenaGrenade?: (x: number, y: number, vx: number, vy: number) => void;
  onArenaHit?: (targetId: string, damage: number, weaponLabel: string) => void;
  onLocalKilled?: (killerId: string, weaponLabel: string, droppedGun: ArenaGunId) => void;
  onArenaTimeExpired?: () => void;
}

const ARENA_W = 3600;
const ARENA_H = 1850;
export const ARENA_KILL_TARGET = 10;
export const ARENA_MATCH_DURATION_SEC = 120;

const SPAWN_POINTS: Vec2[] = [
  { x: 420, y: 1410 }, // Left mountain cave
  { x: 3140, y: 1410 }, // Right mountain cave
  { x: 780, y: 495 }, // Left alpine crag peak
  { x: 2780, y: 495 }, // Right alpine crag peak
  { x: 1780, y: 315 }, // Central summit sanctuary
  { x: 1780, y: 1465 }, // Central underground tunnel
];

export class ArenaEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private radarCanvas: HTMLCanvasElement | null = null;
  private profile: PlayerProfile;
  private lang: Language;
  private localPlayerId: string;
  private isOnline: boolean;
  private callbacks: ArenaCallbacks;
  private effectsQuality: EffectsQuality = 'high';

  private rafId: number | null = null;
  private lastTime = 0;
  private paused = false;
  private matchEnded = false;
  private winReason?: 'target_reached' | 'time_up';
  private winnerName?: string;
  private elapsedSec = 0;
  private syncTimer = 0;
  private hudTimer = 0;
  private shakeTimer = 0;
  private shakeIntensity = 0;
  private bgImg: HTMLImageElement | null = null;
  private nextDropId = 1;

  // Mountain Terrain & Atmosphere
  private terrainCurve: Vec2[] = [];
  private floorGrass: { x: number; y: number; h: number; phase: number }[] = [];
  private rockPolygons: RockPolygon[] = [];
  private bridges: MountainBridge[] = [];
  private lanterns: MountainLantern[] = [];
  private mistRibbons: MistRibbon[] = [];
  private stars: { x: number; y: number; r: number; alpha: number }[] = [];
  private parallaxRidges: { points: Vec2[]; factor: number; color: string }[] = [];

  private pickups: ArenaPickup[] = [];
  private weaponDrops: WeaponDrop[] = [];
  private projectiles: ArenaProjectile[] = [];
  private grenades: ArenaGrenade[] = [];
  private particles: ArenaParticle[] = [];
  private blastRings: ArenaBlastRing[] = [];
  private killFeed: ArenaKillEvent[] = [];

  // Camera
  private camX = 0;
  private camY = 0;

  // Input state
  private keyLeft = false;
  private keyRight = false;
  private keyJet = false;
  private touchMoveX = 0;
  private touchJet = false;
  private firing = false;
  private mouseClientX: number | null = null;
  private mouseClientY: number | null = null;

  // Local Fighter with Dual-Weapon Slots
  private player = {
    x: 420,
    y: 1410,
    vx: 0,
    vy: 0,
    w: 36,
    h: 54,
    hp: 120,
    maxHp: 120,
    fuel: 100,
    maxFuel: 100,
    aimAngle: 0,
    facing: 1,
    slots: [
      { gunId: 'shuriken_smg' as ArenaGunId, ammo: ARENA_GUNS.shuriken_smg.clipSize, reloadTimer: 0 },
      null,
    ] as [WeaponSlotState, WeaponSlotState | null],
    activeSlot: 0 as 0 | 1,
    fireCd: 0,
    meleeCd: 0,
    meleeFlash: 0,
    grenades: 3,
    jetpackActive: false,
    grounded: false,
    alive: true,
    respawnTimer: 0,
    spawnShield: 2.0,
    kills: 0,
    deaths: 0,
    hitFlash: 0,
    scarfPoints: Array.from({ length: 6 }, () => ({ x: 420, y: 1410 })),
  };

  private localSkin: SkinDefinition;
  private bots: ArenaBot[] = [];
  private peers: RoomPlayer[] = [];

  constructor(
    canvas: HTMLCanvasElement,
    profile: PlayerProfile,
    lang: Language,
    localPlayerId: string,
    isOnline: boolean,
    callbacks: ArenaCallbacks,
    effectsQuality: EffectsQuality = 'high'
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('2D context unavailable');
    this.ctx = context;
    this.profile = profile;
    this.lang = lang;
    this.localPlayerId = localPlayerId;
    this.isOnline = isOnline;
    this.callbacks = callbacks;
    this.effectsQuality = effectsQuality;

    this.localSkin = SKINS.find((s) => s.id === profile.equippedSkin) || SKINS[0];
    this.player.maxHp = 110 + profile.skillHealth * 12;
    this.player.hp = this.player.maxHp;

    const img = new Image();
    img.src = moonlitBgUrl;
    this.bgImg = img;

    this.buildMountainArena();
    this.spawnLocalFighter();
    if (!isOnline) {
      this.spawnBots();
    }
  }

  public setRadarCanvas(canvas: HTMLCanvasElement | null) {
    this.radarCanvas = canvas;
  }

  public setEffectsQuality(quality: EffectsQuality) {
    this.effectsQuality = quality;
  }

  public setPaused(paused: boolean) {
    this.paused = paused;
  }

  public setKeyMove(left: boolean, right: boolean, jet: boolean) {
    this.keyLeft = left;
    this.keyRight = right;
    this.keyJet = jet;
  }

  public setTouchMove(moveX: number, jet: boolean) {
    this.touchMoveX = Math.max(-1, Math.min(1, moveX));
    this.touchJet = jet;
  }

  public setAimAngle(angle: number) {
    this.player.aimAngle = angle;
    this.player.facing = Math.cos(angle) >= 0 ? 1 : -1;
  }

  public setMouseScreenPos(clientX: number, clientY: number) {
    this.mouseClientX = clientX;
    this.mouseClientY = clientY;
  }

  public setFiring(active: boolean) {
    this.firing = active;
  }

  private getActiveSlot(): WeaponSlotState {
    return this.player.slots[this.player.activeSlot] || this.player.slots[0];
  }

  public switchWeaponSlot(targetSlot?: 0 | 1) {
    if (!this.player.alive || this.paused || this.matchEnded) return;
    const nextSlot: 0 | 1 =
      targetSlot !== undefined ? targetSlot : this.player.activeSlot === 0 ? 1 : 0;
    if (!this.player.slots[nextSlot] || nextSlot === this.player.activeSlot) return;
    this.player.activeSlot = nextSlot;
    this.player.fireCd = 0.12;
    soundEngine.playWeaponSwap();
    this.emitHud();
  }

  public triggerReload() {
    if (!this.player.alive || this.paused || this.matchEnded) return;
    const slot = this.getActiveSlot();
    const spec = ARENA_GUNS[slot.gunId];
    if (slot.reloadTimer <= 0 && slot.ammo < spec.clipSize) {
      slot.reloadTimer = spec.reloadTime;
      soundEngine.playReload();
      this.emitHud();
    }
  }

  public triggerMelee() {
    if (!this.player.alive || this.paused || this.matchEnded || this.player.meleeCd > 0) return;
    this.player.meleeCd = 0.48;
    this.player.meleeFlash = 0.18;
    soundEngine.playSlash(this.profile.equippedWeapon);

    const cx = this.player.x + this.player.w / 2;
    const cy = this.player.y + this.player.h * 0.45;
    const hitX = cx + Math.cos(this.player.aimAngle) * 52;
    const hitY = cy + Math.sin(this.player.aimAngle) * 52;

    for (const bot of this.bots) {
      if (!bot.alive || bot.spawnShield > 0) continue;
      const bx = bot.x + bot.w / 2;
      const by = bot.y + bot.h / 2;
      if (Math.hypot(bx - hitX, by - hitY) <= 58) {
        this.damageBot(bot, 48, this.localPlayerId, this.profile.displayName, 'Katana');
      }
    }

    if (this.isOnline) {
      for (const peer of this.peers) {
        if (peer.alive === false) continue;
        const px = peer.x + 18;
        const py = peer.y + 27;
        if (Math.hypot(px - hitX, py - hitY) <= 58) {
          this.callbacks.onArenaHit?.(peer.id, 48, 'Katana');
          soundEngine.playSwordClash(true);
        }
      }
    }
  }

  public throwGrenade() {
    if (!this.player.alive || this.paused || this.matchEnded || this.player.grenades <= 0) return;
    this.player.grenades -= 1;
    const cx = this.player.x + this.player.w / 2;
    const cy = this.player.y + this.player.h * 0.35;
    const vx = Math.cos(this.player.aimAngle) * 540 + this.player.vx * 0.25;
    const vy = Math.sin(this.player.aimAngle) * 540 - 95;

    this.grenades.push({
      x: cx,
      y: cy,
      vx,
      vy,
      r: 8,
      ownerId: this.localPlayerId,
      ownerName: this.profile.displayName,
      fuse: 1.85,
      bounces: 0,
    });
    soundEngine.playDash();
    this.callbacks.onArenaGrenade?.(cx, cy, vx, vy);
  }

  public setPeers(peers: RoomPlayer[]) {
    this.peers = peers;
  }

  public addRemoteShot(x: number, y: number, angle: number, gunId: ArenaGunId, shooterId: string) {
    const spec = ARENA_GUNS[gunId] || ARENA_GUNS.shuriken_smg;
    const shooter = this.peers.find((p) => p.id === shooterId);
    const shooterName = shooter?.displayName || 'Shinobi';
    for (let i = 0; i < spec.pellets; i++) {
      const a = angle + (i === 0 ? 0 : (Math.random() - 0.5) * spec.spreadRad * 2);
      this.projectiles.push({
        x,
        y,
        vx: Math.cos(a) * spec.projectileSpeed,
        vy: Math.sin(a) * spec.projectileSpeed,
        r: gunId === 'dragon_cannon' ? 8 : 5,
        ownerId: shooterId,
        ownerName: shooterName,
        gunId,
        damage: spec.damage,
        splashRadius: spec.splashRadius,
        color: spec.color,
        life: 1.85,
      });
    }
  }

  public addRemoteGrenade(x: number, y: number, vx: number, vy: number, throwerId: string) {
    const thrower = this.peers.find((p) => p.id === throwerId);
    this.grenades.push({
      x,
      y,
      vx,
      vy,
      r: 8,
      ownerId: throwerId,
      ownerName: thrower?.displayName || 'Shinobi',
      fuse: 1.85,
      bounces: 0,
    });
  }

  public applyRemoteHit(damage: number, attackerId: string, weaponLabel: string) {
    if (!this.player.alive || this.player.spawnShield > 0 || this.matchEnded) return;
    this.player.hp = Math.max(0, this.player.hp - damage);
    this.player.hitFlash = 0.16;
    this.shakeTimer = 0.15;
    this.shakeIntensity = 6;
    soundEngine.playDamage();
    if (this.player.hp <= 0) {
      const attacker = this.peers.find((p) => p.id === attackerId);
      this.eliminateLocalPlayer(attackerId, attacker?.displayName || 'Shinobi', weaponLabel);
    }
  }

  public spawnWeaponDrop(x: number, y: number, gunId: ArenaGunId, ammo?: number) {
    const spec = ARENA_GUNS[gunId] || ARENA_GUNS.shuriken_smg;
    this.weaponDrops.push({
      id: this.nextDropId++,
      x,
      y,
      vx: (Math.random() - 0.5) * 120,
      vy: -210,
      gunId,
      ammo: ammo ?? spec.clipSize,
      life: 24,
      pickupDelay: 0.45,
      bobPhase: Math.random() * Math.PI * 2,
    });
  }

  public pushKillEvent(
    killerName: string,
    victimName: string,
    weaponLabel: string,
    killerId: string,
    droppedGun?: ArenaGunId,
    victimX?: number,
    victimY?: number
  ) {
    if (killerId === this.localPlayerId && victimName !== this.profile.displayName) {
      this.player.kills += 1;
      soundEngine.playKillConfirm();
    }
    if (this.isOnline && droppedGun && victimX !== undefined && victimY !== undefined) {
      this.spawnWeaponDrop(victimX + 18, victimY + 20, droppedGun);
    }
    this.killFeed.unshift({
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      killerName,
      victimName,
      weaponLabel,
      timestampMs: Date.now(),
    });
    if (this.killFeed.length > 4) this.killFeed.pop();
  }

  public finishOnlineMatch(
    roomPlayers: RoomPlayer[],
    winnerId?: string,
    winReason: 'target_reached' | 'time_up' = 'time_up'
  ) {
    if (this.matchEnded) return;
    this.matchEnded = true;
    const sorted = [...roomPlayers].sort(
      (a, b) => (b.kills || 0) - (a.kills || 0) || (a.deaths || 0) - (b.deaths || 0)
    );
    const resolvedWinnerId = winnerId || sorted[0]?.id || this.localPlayerId;
    const won = resolvedWinnerId === this.localPlayerId;
    const winnerEntry = sorted.find((p) => p.id === resolvedWinnerId) || sorted[0];
    this.winReason = winReason;
    this.winnerName = winnerEntry?.displayName || this.profile.displayName;
    this.emitHud();
    this.callbacks.onMatchComplete({
      victory: won,
      stageId: 'arena',
      score: this.player.kills * 150 + (won ? 350 : 80),
      gemsEarned: Math.max(15, this.player.kills * 12 + (won ? 50 : 15)),
      xpEarned: Math.max(40, this.player.kills * 35 + (won ? 140 : 40)),
      elapsedSec: Math.round(this.elapsedSec),
      bossDefeated: won,
      isSeasonal: false,
    });
  }

  public start() {
    this.lastTime = performance.now();
    this.emitHud();
    const loop = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
      this.lastTime = now;
      if (!this.paused && !this.matchEnded) {
        this.update(dt);
      }
      this.render();
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);
  }

  public stop() {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  private createRockPolygon(
    points: Vec2[],
    kind: RockPolygon['kind'],
    hasGrass: boolean,
    seed: number
  ): RockPolygon {
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for (const pt of points) {
      if (pt.x < minX) minX = pt.x;
      if (pt.x > maxX) maxX = pt.x;
      if (pt.y < minY) minY = pt.y;
      if (pt.y > maxY) maxY = pt.y;
    }

    const cracks: { x1: number; y1: number; x2: number; y2: number }[] = [];
    const crackCount = Math.max(3, Math.min(9, Math.floor((maxX - minX) / 95)));
    for (let i = 0; i < crackCount; i++) {
      const t = (i + 0.5) / crackCount;
      const cx = minX + (maxX - minX) * t;
      const cy = minY + (maxY - minY) * (0.28 + ((seed * 17 + i * 31) % 45) / 100);
      const dx = (((seed + i * 13) % 7) - 3) * 16;
      const dy = 28 + ((seed + i * 29) % 40);
      cracks.push({ x1: cx, y1: cy, x2: cx + dx, y2: cy + dy });
    }

    const grassTufts: { x: number; y: number; h: number; phase: number }[] = [];
    if (hasGrass) {
      for (let i = 0; i < points.length; i++) {
        const a = points[i];
        const b = points[(i + 1) % points.length];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const len = Math.hypot(dx, dy) || 1;
        const nx = dy / len;
        const ny = -dx / len;
        if (ny < -0.55 && Math.abs(nx) < 0.78 && b.x > a.x) {
          const steps = Math.max(2, Math.floor(len / 30));
          for (let s = 1; s < steps; s++) {
            const u = s / steps;
            grassTufts.push({
              x: a.x + dx * u,
              y: a.y + dy * u,
              h: 9 + ((Math.round(a.x) + s * 7) % 9),
              phase: (a.x + s * 19) * 0.03,
            });
          }
        }
      }
    }

    return { points, kind, hasGrass, minX, maxX, minY, maxY, cracks, grassTufts };
  }

  private buildMountainArena() {
    // 1. Massive 3600x1850 sloped mountain valley floor with flanking caverns & deep central gorge
    this.terrainCurve = [
      { x: 0, y: 950 },
      { x: 140, y: 1240 },
      { x: 280, y: 1485 },
      { x: 500, y: 1525 },
      { x: 760, y: 1510 },
      { x: 980, y: 1425 },
      { x: 1200, y: 1545 },
      { x: 1440, y: 1650 },
      { x: 1640, y: 1660 },
      { x: 1800, y: 1545 },
      { x: 1960, y: 1660 },
      { x: 2160, y: 1650 },
      { x: 2400, y: 1545 },
      { x: 2620, y: 1425 },
      { x: 2840, y: 1510 },
      { x: 3100, y: 1525 },
      { x: 3320, y: 1485 },
      { x: 3460, y: 1240 },
      { x: 3600, y: 950 },
    ];

    this.floorGrass = [];
    for (let x = 220; x <= 3380; x += 28) {
      this.floorGrass.push({
        x,
        y: this.getFloorYAt(x),
        h: 10 + ((x * 13) % 10),
        phase: x * 0.025,
      });
    }

    // 2. Rock-filled Mountain Cliffs, Tunnels, Caves, Boulders & Summit Peaks
    this.rockPolygons = [
      // Left Cliff Wall (Brown Mountain Mass)
      this.createRockPolygon(
        [
          { x: 0, y: 0 },
          { x: 340, y: 0 },
          { x: 280, y: 240 },
          { x: 210, y: 480 },
          { x: 245, y: 740 },
          { x: 170, y: 990 },
          { x: 185, y: 1140 },
          { x: 95, y: 1320 },
          { x: 0, y: 1400 },
        ],
        'peak_wall',
        false,
        11
      ),
      // Right Cliff Wall (Brown Mountain Mass)
      this.createRockPolygon(
        [
          { x: 3260, y: 0 },
          { x: 3600, y: 0 },
          { x: 3600, y: 1400 },
          { x: 3505, y: 1320 },
          { x: 3415, y: 1140 },
          { x: 3430, y: 990 },
          { x: 3355, y: 740 },
          { x: 3390, y: 480 },
          { x: 3320, y: 240 },
        ],
        'peak_wall',
        false,
        23
      ),
      // Upper-Left Mountain Canopy
      this.createRockPolygon(
        [
          { x: 320, y: 0 },
          { x: 860, y: 0 },
          { x: 740, y: 105 },
          { x: 540, y: 155 },
          { x: 340, y: 195 },
        ],
        'peak_wall',
        false,
        37
      ),
      // Upper-Right Mountain Canopy
      this.createRockPolygon(
        [
          { x: 2740, y: 0 },
          { x: 3280, y: 0 },
          { x: 3260, y: 195 },
          { x: 3060, y: 155 },
          { x: 2860, y: 105 },
        ],
        'peak_wall',
        false,
        41
      ),
      // Left Deep Cave & Tunnel Roof (Basalt Cave Rock)
      this.createRockPolygon(
        [
          { x: 180, y: 990 },
          { x: 420, y: 915 },
          { x: 660, y: 945 },
          { x: 870, y: 1040 },
          { x: 890, y: 1110 },
          { x: 795, y: 1175 },
          { x: 560, y: 1155 },
          { x: 330, y: 1185 },
          { x: 185, y: 1140 },
        ],
        'cave_roof',
        true,
        53
      ),
      // Right Deep Cave & Tunnel Roof (Basalt Cave Rock)
      this.createRockPolygon(
        [
          { x: 2730, y: 1040 },
          { x: 2940, y: 945 },
          { x: 3180, y: 915 },
          { x: 3420, y: 990 },
          { x: 3415, y: 1140 },
          { x: 3270, y: 1185 },
          { x: 3040, y: 1155 },
          { x: 2805, y: 1175 },
          { x: 2710, y: 1110 },
        ],
        'cave_roof',
        true,
        67
      ),
      // Central Underground Tunnel Roof (forms subterranean cavern in center!)
      this.createRockPolygon(
        [
          { x: 1460, y: 1215 },
          { x: 1660, y: 1165 },
          { x: 1800, y: 1150 },
          { x: 1940, y: 1165 },
          { x: 2140, y: 1215 },
          { x: 2175, y: 1275 },
          { x: 2010, y: 1320 },
          { x: 1800, y: 1300 },
          { x: 1590, y: 1320 },
          { x: 1425, y: 1275 },
        ],
        'cave_roof',
        true,
        71
      ),
      // Left Gorge Stone Pillar Outcrop (Sandstone/Granite)
      this.createRockPolygon(
        [
          { x: 1140, y: 1020 },
          { x: 1270, y: 990 },
          { x: 1345, y: 1060 },
          { x: 1310, y: 1310 },
          { x: 1165, y: 1340 },
          { x: 1105, y: 1180 },
        ],
        'outcrop',
        true,
        79
      ),
      // Right Gorge Stone Pillar Outcrop (Sandstone/Granite)
      this.createRockPolygon(
        [
          { x: 2330, y: 990 },
          { x: 2460, y: 1020 },
          { x: 2495, y: 1180 },
          { x: 2435, y: 1340 },
          { x: 2290, y: 1310 },
          { x: 2255, y: 1060 },
        ],
        'outcrop',
        true,
        83
      ),
      // Left Foothill Tactical Cover Boulder
      this.createRockPolygon(
        [
          { x: 910, y: 1335 },
          { x: 985, y: 1295 },
          { x: 1060, y: 1330 },
          { x: 1085, y: 1445 },
          { x: 895, y: 1455 },
        ],
        'outcrop',
        true,
        89
      ),
      // Right Foothill Tactical Cover Boulder
      this.createRockPolygon(
        [
          { x: 2540, y: 1330 },
          { x: 2615, y: 1295 },
          { x: 2690, y: 1335 },
          { x: 2705, y: 1455 },
          { x: 2515, y: 1445 },
        ],
        'outcrop',
        true,
        93
      ),
      // Left Upper Alpine Crag
      this.createRockPolygon(
        [
          { x: 610, y: 625 },
          { x: 825, y: 565 },
          { x: 1035, y: 600 },
          { x: 1080, y: 685 },
          { x: 935, y: 745 },
          { x: 705, y: 735 },
          { x: 575, y: 680 },
        ],
        'outcrop',
        true,
        101
      ),
      // Right Upper Alpine Crag
      this.createRockPolygon(
        [
          { x: 2565, y: 600 },
          { x: 2775, y: 565 },
          { x: 2990, y: 625 },
          { x: 3025, y: 680 },
          { x: 2895, y: 735 },
          { x: 2665, y: 745 },
          { x: 2520, y: 685 },
        ],
        'outcrop',
        true,
        107
      ),
      // High Sky Left Floating Rock Outcrop
      this.createRockPolygon(
        [
          { x: 1180, y: 740 },
          { x: 1315, y: 705 },
          { x: 1425, y: 745 },
          { x: 1405, y: 815 },
          { x: 1245, y: 825 },
          { x: 1145, y: 785 },
        ],
        'outcrop',
        true,
        113
      ),
      // High Sky Right Floating Rock Outcrop
      this.createRockPolygon(
        [
          { x: 2285, y: 705 },
          { x: 2420, y: 740 },
          { x: 2455, y: 785 },
          { x: 2355, y: 825 },
          { x: 2195, y: 815 },
          { x: 2175, y: 745 },
        ],
        'outcrop',
        true,
        121
      ),
      // Central Summit Quartz Mountain Sanctuary
      this.createRockPolygon(
        [
          { x: 1490, y: 480 },
          { x: 1680, y: 415 },
          { x: 1800, y: 390 },
          { x: 1920, y: 415 },
          { x: 2110, y: 480 },
          { x: 2155, y: 560 },
          { x: 1995, y: 635 },
          { x: 1800, y: 675 },
          { x: 1605, y: 635 },
          { x: 1445, y: 560 },
        ],
        'arch',
        true,
        131
      ),
    ];

    // 3. Suspended Rope Bridges & Carved Sandstone Bridges
    this.bridges = [
      { x1: 870, x2: 1145, y: 1030, sag: 20, kind: 'rope' },
      { x1: 2455, x2: 2730, y: 1030, sag: 20, kind: 'rope' },
      { x1: 1035, x2: 1185, y: 690, sag: 14, kind: 'rope' },
      { x1: 2415, x2: 2565, y: 690, sag: 14, kind: 'rope' },
      { x1: 1335, x2: 2265, y: 1045, sag: -22, kind: 'stone' },
    ];

    // 4. Warm Mountain Cave & Tunnel Lanterns
    this.lanterns = [
      { x: 310, y: 1200, phase: 0.4 },
      { x: 640, y: 1175, phase: 1.5 },
      { x: 1580, y: 1330, phase: 2.1 },
      { x: 1800, y: 1315, phase: 0.9 },
      { x: 2020, y: 1330, phase: 2.8 },
      { x: 2960, y: 1175, phase: 1.9 },
      { x: 3290, y: 1200, phase: 3.3 },
      { x: 1330, y: 995, phase: 0.6 },
      { x: 2270, y: 995, phase: 2.4 },
    ];

    // 5. Drifting Mountain Mist Ribbons
    this.mistRibbons = [
      { x: 240, y: 1410, w: 620, h: 86, speed: 14, alpha: 0.08 },
      { x: 1400, y: 1560, w: 740, h: 95, speed: -12, alpha: 0.09 },
      { x: 2700, y: 1410, w: 620, h: 86, speed: 15, alpha: 0.08 },
      { x: 780, y: 960, w: 540, h: 68, speed: 18, alpha: 0.06 },
      { x: 2240, y: 960, w: 540, h: 68, speed: -16, alpha: 0.06 },
      { x: 1520, y: 690, w: 560, h: 64, speed: 13, alpha: 0.05 },
    ];

    // 6. Night Stars & Brown Parallax Mountain Silhouettes
    this.stars = Array.from({ length: 90 }, (_, i) => ({
      x: ((i * 197 + 43) % 1000) / 1000,
      y: ((i * 313 + 17) % 520) / 1000,
      r: 0.8 + ((i * 7) % 3) * 0.55,
      alpha: 0.25 + ((i * 11) % 6) * 0.1,
    }));

    this.parallaxRidges = [
      {
        factor: 0.14,
        color: '#1F1510',
        points: [
          { x: -120, y: 1150 },
          { x: 260, y: 520 },
          { x: 640, y: 680 },
          { x: 1050, y: 380 },
          { x: 1480, y: 610 },
          { x: 1920, y: 340 },
          { x: 2380, y: 590 },
          { x: 2820, y: 400 },
          { x: 3250, y: 640 },
          { x: 3800, y: 1150 },
        ],
      },
      {
        factor: 0.3,
        color: '#2F1F16',
        points: [
          { x: -120, y: 1250 },
          { x: 180, y: 740 },
          { x: 540, y: 560 },
          { x: 920, y: 790 },
          { x: 1340, y: 540 },
          { x: 1780, y: 760 },
          { x: 2220, y: 510 },
          { x: 2660, y: 770 },
          { x: 3080, y: 570 },
          { x: 3750, y: 1250 },
        ],
      },
      {
        factor: 0.48,
        color: '#422C1F',
        points: [
          { x: -120, y: 1350 },
          { x: 340, y: 860 },
          { x: 760, y: 700 },
          { x: 1180, y: 920 },
          { x: 1620, y: 740 },
          { x: 2040, y: 900 },
          { x: 2480, y: 710 },
          { x: 2940, y: 910 },
          { x: 3700, y: 1350 },
        ],
      },
    ];

    // 7. 13 Tactical Pickups across caves, tunnels, bridges & peaks
    const pickupSpecs: { x: number; y: number; kind: PickupKind }[] = [
      { x: 1800, y: 355, kind: 'dragon_cannon' },
      { x: 1800, y: 988, kind: 'medkit' },
      { x: 1800, y: 1508, kind: 'fire_crossbow' },
      { x: 825, y: 530, kind: 'fire_crossbow' },
      { x: 2775, y: 530, kind: 'venom_kunai' },
      { x: 1310, y: 670, kind: 'fuel' },
      { x: 2290, y: 670, kind: 'fuel' },
      { x: 480, y: 1485, kind: 'medkit' },
      { x: 3120, y: 1485, kind: 'medkit' },
      { x: 660, y: 1475, kind: 'grenades' },
      { x: 2940, y: 1475, kind: 'grenades' },
      { x: 1005, y: 998, kind: 'venom_kunai' },
      { x: 2595, y: 998, kind: 'dragon_cannon' },
    ];

    this.pickups = pickupSpecs.map((p, idx) => ({
      id: idx + 1,
      x: p.x,
      y: p.y,
      kind: p.kind,
      active: true,
      respawnTimer: 0,
      bobPhase: idx * 0.9,
    }));
  }

  private getFloorYAt(x: number): number {
    const cx = Math.max(0, Math.min(ARENA_W, x));
    const pts = this.terrainCurve;
    for (let i = 0; i < pts.length - 1; i++) {
      if (cx >= pts[i].x && cx <= pts[i + 1].x) {
        const t = (cx - pts[i].x) / Math.max(1, pts[i + 1].x - pts[i].x);
        return pts[i].y + (pts[i + 1].y - pts[i].y) * t;
      }
    }
    return ARENA_H - 90;
  }

  private getFloorNormalAt(x: number): Vec2 {
    const cx = Math.max(0, Math.min(ARENA_W, x));
    const pts = this.terrainCurve;
    for (let i = 0; i < pts.length - 1; i++) {
      if (cx >= pts[i].x && cx <= pts[i + 1].x) {
        const dx = pts[i + 1].x - pts[i].x;
        const dy = pts[i + 1].y - pts[i].y;
        const len = Math.hypot(dx, dy) || 1;
        return { x: dy / len, y: -dx / len };
      }
    }
    return { x: 0, y: -1 };
  }

  private getBridgeYAt(br: MountainBridge, x: number): number {
    const t = Math.max(0, Math.min(1, (x - br.x1) / Math.max(1, br.x2 - br.x1)));
    return br.y + Math.sin(t * Math.PI) * br.sag;
  }

  private pointInPolygon(x: number, y: number, poly: RockPolygon): boolean {
    if (x < poly.minX || x > poly.maxX || y < poly.minY || y > poly.maxY) return false;
    const pts = poly.points;
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i].x;
      const yi = pts[i].y;
      const xj = pts[j].x;
      const yj = pts[j].y;
      const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi;
      if (intersect) inside = !inside;
    }
    return inside;
  }

  private closestPointOnPolygon(
    x: number,
    y: number,
    poly: RockPolygon
  ): { px: number; py: number; nx: number; ny: number; dist: number; inside: boolean } {
    const pts = poly.points;
    let bestDistSq = Infinity;
    let bestX = x;
    let bestY = y;
    let bestNx = 0;
    let bestNy = -1;

    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const abx = b.x - a.x;
      const aby = b.y - a.y;
      const abLenSq = abx * abx + aby * aby || 1;
      const t = Math.max(0, Math.min(1, ((x - a.x) * abx + (y - a.y) * aby) / abLenSq));
      const cx = a.x + abx * t;
      const cy = a.y + aby * t;
      const dSq = (x - cx) * (x - cx) + (y - cy) * (y - cy);
      if (dSq < bestDistSq) {
        bestDistSq = dSq;
        bestX = cx;
        bestY = cy;
        const abLen = Math.sqrt(abLenSq);
        bestNx = aby / abLen;
        bestNy = -abx / abLen;
      }
    }

    const inside = this.pointInPolygon(x, y, poly);
    return {
      px: bestX,
      py: bestY,
      nx: bestNx,
      ny: bestNy,
      dist: Math.sqrt(bestDistSq),
      inside,
    };
  }

  private spawnLocalFighter() {
    const sp = SPAWN_POINTS[Math.floor(Math.random() * SPAWN_POINTS.length)];
    this.player.x = sp.x;
    this.player.y = sp.y;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.hp = this.player.maxHp;
    this.player.fuel = this.player.maxFuel;
    this.player.slots = [
      { gunId: 'shuriken_smg', ammo: ARENA_GUNS.shuriken_smg.clipSize, reloadTimer: 0 },
      null,
    ];
    this.player.activeSlot = 0;
    this.player.grenades = Math.max(2, this.player.grenades);
    this.player.alive = true;
    this.player.spawnShield = 2.0;
    this.player.scarfPoints = Array.from({ length: 6 }, () => ({ x: sp.x + 18, y: sp.y + 18 }));
  }

  private spawnBots() {
    const botRoster: { id: string; name: string; skin: SkinDefinition; gun: ArenaGunId }[] = [
      { id: 'bot_kage', name: this.lang === 'ar' ? 'ظل الشهاب' : 'KageBot', skin: SKINS[1], gun: 'venom_kunai' },
      { id: 'bot_akuma', name: this.lang === 'ar' ? 'عاصفة النصل' : 'AkumaBot', skin: SKINS[2], gun: 'fire_crossbow' },
      { id: 'bot_raijin', name: this.lang === 'ar' ? 'برق القمر' : 'RaijinBot', skin: SKINS[3], gun: 'shuriken_smg' },
    ];
    this.bots = botRoster.map((b, idx) => {
      const sp = SPAWN_POINTS[(idx + 1) % SPAWN_POINTS.length];
      return {
        id: b.id,
        name: b.name,
        skin: b.skin,
        x: sp.x,
        y: sp.y,
        vx: 0,
        vy: 0,
        w: 36,
        h: 54,
        hp: 105,
        maxHp: 105,
        fuel: 100,
        aimAngle: idx % 2 === 0 ? 0 : Math.PI,
        gunId: b.gun,
        ammo: ARENA_GUNS[b.gun].clipSize,
        fireCd: 0.5,
        reloadTimer: 0,
        grenades: 2,
        grenadeCd: 5 + idx * 2,
        jetpackActive: false,
        grounded: false,
        alive: true,
        respawnTimer: 0,
        spawnShield: 1.5,
        kills: 0,
        deaths: 0,
        hitFlash: 0,
        scarfPoints: Array.from({ length: 6 }, () => ({ x: sp.x + 18, y: sp.y + 18 })),
        aiDecisionTimer: 0,
        aiTargetX: 1800,
        aiTargetY: 1100,
      };
    });
  }

  private update(dt: number) {
    this.elapsedSec += dt;
    if (this.shakeTimer > 0) this.shakeTimer = Math.max(0, this.shakeTimer - dt);

    for (const m of this.mistRibbons) {
      m.x += m.speed * dt;
      if (m.x > ARENA_W + 150) m.x = -m.w - 80;
      if (m.x + m.w < -150) m.x = ARENA_W + 80;
    }

    if (this.elapsedSec >= ARENA_MATCH_DURATION_SEC) {
      if (this.isOnline) {
        this.callbacks.onArenaTimeExpired?.();
        this.matchEnded = true;
      } else {
        this.finishOfflineMatch('time_up');
      }
      return;
    }

    if (this.mouseClientX !== null && this.mouseClientY !== null && this.player.alive) {
      const rect = this.canvas.getBoundingClientRect();
      const worldX = this.mouseClientX - rect.left + this.camX;
      const worldY = this.mouseClientY - rect.top + this.camY;
      const px = this.player.x + this.player.w / 2;
      const py = this.player.y + this.player.h * 0.42;
      this.player.aimAngle = Math.atan2(worldY - py, worldX - px);
      this.player.facing = Math.cos(this.player.aimAngle) >= 0 ? 1 : -1;
    }

    this.updateLocalPlayer(dt);
    this.updatePickups(dt);
    this.updateWeaponDrops(dt);
    if (!this.isOnline) {
      this.updateBots(dt);
    }
    this.updateProjectiles(dt);
    this.updateGrenades(dt);
    this.updateParticles(dt);
    this.updateCamera(dt);

    if (this.isOnline) {
      this.syncTimer += dt;
      if (this.syncTimer >= 0.05) {
        this.syncTimer = 0;
        const activeSlot = this.getActiveSlot();
        this.callbacks.onLocalStateSync?.({
          x: this.player.x,
          y: this.player.y,
          vx: this.player.vx,
          vy: this.player.vy,
          facing: this.player.facing,
          action: this.player.jetpackActive ? 'jet' : this.player.grounded ? 'run' : 'air',
          hp: Math.round(this.player.hp),
          maxHp: this.player.maxHp,
          score: this.player.kills * 150,
          progress: Math.round((this.player.kills / ARENA_KILL_TARGET) * 100),
          aimAngle: this.player.aimAngle,
          jetpackActive: this.player.jetpackActive,
          arenaGun: activeSlot.gunId,
          alive: this.player.alive,
        });
      }
    }

    this.hudTimer += dt;
    if (this.hudTimer >= 0.065) {
      this.hudTimer = 0;
      this.emitHud();
    }
  }

  private updateLocalPlayer(dt: number) {
    const p = this.player;
    if (!p.alive) {
      p.respawnTimer -= dt;
      if (p.respawnTimer <= 0) {
        this.spawnLocalFighter();
      }
      return;
    }

    if (p.spawnShield > 0) p.spawnShield = Math.max(0, p.spawnShield - dt);
    if (p.hitFlash > 0) p.hitFlash = Math.max(0, p.hitFlash - dt);
    if (p.fireCd > 0) p.fireCd = Math.max(0, p.fireCd - dt);
    if (p.meleeCd > 0) p.meleeCd = Math.max(0, p.meleeCd - dt);
    if (p.meleeFlash > 0) p.meleeFlash = Math.max(0, p.meleeFlash - dt);

    // Reload active slot timer
    for (const sl of p.slots) {
      if (sl && sl.reloadTimer > 0) {
        sl.reloadTimer -= dt;
        if (sl.reloadTimer <= 0) {
          sl.reloadTimer = 0;
          sl.ammo = ARENA_GUNS[sl.gunId].clipSize;
        }
      }
    }

    // Slower, tactical horizontal movement
    let moveX = this.touchMoveX;
    if (this.keyLeft) moveX -= 1;
    if (this.keyRight) moveX += 1;
    moveX = Math.max(-1, Math.min(1, moveX));

    const targetVx = moveX * 260;
    p.vx += (targetVx - p.vx) * Math.min(1, dt * 10);

    // Calm tactical Jetpack flight
    const wantsJet = this.keyJet || this.touchJet;
    if (wantsJet && p.fuel > 1.5) {
      p.jetpackActive = true;
      p.vy -= 1080 * dt;
      if (p.vy < -330) p.vy = -330;
      p.fuel = Math.max(0, p.fuel - 25 * dt);
      if (Math.random() < (this.effectsQuality === 'balanced' ? 0.3 : 0.65)) {
        this.spawnJetParticle(p.x + p.w / 2, p.y + p.h * 0.68, p.facing);
      }
    } else {
      p.jetpackActive = false;
      p.vy += 690 * dt;
      if (p.vy > 520) p.vy = 520;
      const regen = p.grounded ? 28 : 12;
      p.fuel = Math.min(p.maxFuel, p.fuel + regen * dt);
    }

    this.moveEntityWithTerrain(p, dt);
    this.updateScarf(p.scarfPoints, p.x + p.w / 2, p.y + 18, p.facing, dt);

    const activeSlot = this.getActiveSlot();
    if (this.firing && activeSlot.reloadTimer <= 0 && p.fireCd <= 0) {
      const spec = ARENA_GUNS[activeSlot.gunId];
      if (activeSlot.ammo <= 0) {
        this.triggerReload();
      } else {
        activeSlot.ammo -= 1;
        p.fireCd = spec.fireInterval;
        const mx = p.x + p.w / 2 + Math.cos(p.aimAngle) * 28;
        const my = p.y + p.h * 0.42 + Math.sin(p.aimAngle) * 28;
        this.fireGun(mx, my, p.aimAngle, spec, this.localPlayerId, this.profile.displayName);
        soundEngine.playRangedShot(spec.id);
        this.callbacks.onArenaShot?.(mx, my, p.aimAngle, spec.id);
        if (activeSlot.ammo <= 0) {
          this.triggerReload();
        }
      }
    }
  }

  private fireGun(
    x: number,
    y: number,
    angle: number,
    spec: ArenaGunSpec,
    ownerId: string,
    ownerName: string
  ) {
    for (let i = 0; i < spec.pellets; i++) {
      const a = angle + (Math.random() - 0.5) * spec.spreadRad * 2;
      this.projectiles.push({
        x,
        y,
        vx: Math.cos(a) * spec.projectileSpeed,
        vy: Math.sin(a) * spec.projectileSpeed,
        r: spec.id === 'dragon_cannon' ? 8 : 5,
        ownerId,
        ownerName,
        gunId: spec.id,
        damage: spec.damage,
        splashRadius: spec.splashRadius,
        color: spec.color,
        life: 1.85,
      });
    }
    this.spawnBurst(x, y, spec.color, this.effectsQuality === 'balanced' ? 2 : 5, 140);
  }

  private equipGunIntoPlayerSlots(gunId: ArenaGunId, ammo?: number, dropReplaced = false): boolean {
    const spec = ARENA_GUNS[gunId];
    const clip = ammo ?? spec.clipSize;

    // 1. Already carried in either slot -> refill ammo
    for (let i = 0; i < 2; i++) {
      const sl = this.player.slots[i as 0 | 1];
      if (sl && sl.gunId === gunId) {
        if (sl.ammo >= spec.clipSize && sl.reloadTimer <= 0) return false;
        sl.ammo = spec.clipSize;
        sl.reloadTimer = 0;
        return true;
      }
    }

    // 2. Empty second slot -> add to Slot 2 and switch to it
    if (!this.player.slots[1]) {
      this.player.slots[1] = { gunId, ammo: clip, reloadTimer: 0 };
      this.player.activeSlot = 1;
      soundEngine.playWeaponSwap();
      return true;
    }

    // 3. Both slots full: upgrade if active slot is weaker tier (or swap active slot on pickup crate)
    const active = this.getActiveSlot();
    const activeTier = ARENA_GUNS[active.gunId].tier;
    if (!dropReplaced || spec.tier > activeTier) {
      const oldGun = active.gunId;
      const oldAmmo = active.ammo;
      this.player.slots[this.player.activeSlot] = { gunId, ammo: clip, reloadTimer: 0 };
      if (dropReplaced) {
        this.weaponDrops.push({
          id: this.nextDropId++,
          x: this.player.x + 18,
          y: this.player.y + 18,
          vx: -this.player.facing * 90,
          vy: -180,
          gunId: oldGun,
          ammo: Math.max(1, oldAmmo),
          life: 20,
          pickupDelay: 1.3,
          bobPhase: 0,
        });
      }
      soundEngine.playWeaponSwap();
      return true;
    }

    return false;
  }

  private updatePickups(dt: number) {
    for (const pk of this.pickups) {
      pk.bobPhase += dt * 3;
      if (!pk.active) {
        pk.respawnTimer -= dt;
        if (pk.respawnTimer <= 0) {
          pk.active = true;
        }
        continue;
      }

      if (this.player.alive) {
        const px = this.player.x + this.player.w / 2;
        const py = this.player.y + this.player.h / 2;
        if (Math.hypot(px - pk.x, py - pk.y) <= 42) {
          if (this.applyPickupToPlayer(pk)) continue;
        }
      }

      for (const bot of this.bots) {
        if (!bot.alive) continue;
        const bx = bot.x + bot.w / 2;
        const by = bot.y + bot.h / 2;
        if (Math.hypot(bx - pk.x, by - pk.y) <= 42) {
          this.applyPickupToBot(pk, bot);
          break;
        }
      }
    }
  }

  private updateWeaponDrops(dt: number) {
    for (let i = this.weaponDrops.length - 1; i >= 0; i--) {
      const dr = this.weaponDrops[i];
      dr.bobPhase += dt * 3.5;
      dr.life -= dt;
      if (dr.pickupDelay > 0) dr.pickupDelay = Math.max(0, dr.pickupDelay - dt);
      if (dr.life <= 0) {
        this.weaponDrops.splice(i, 1);
        continue;
      }

      // Simple gravity & floor settle
      dr.vy += 650 * dt;
      dr.x = Math.max(130, Math.min(ARENA_W - 130, dr.x + dr.vx * dt));
      dr.y += dr.vy * dt;
      dr.vx *= Math.pow(0.2, dt);

      const floorY = this.getFloorYAt(dr.x) - 12;
      if (dr.y >= floorY) {
        dr.y = floorY;
        dr.vy = 0;
        dr.vx = 0;
      }
      for (const poly of this.rockPolygons) {
        if (dr.x >= poly.minX && dr.x <= poly.maxX && dr.y >= poly.minY && dr.y <= poly.maxY) {
          const hit = this.closestPointOnPolygon(dr.x, dr.y, poly);
          if (hit.inside || hit.dist < 12) {
            dr.y = hit.py - 12;
            dr.vy = 0;
            dr.vx = 0;
          }
        }
      }

      if (dr.pickupDelay > 0) continue;

      if (this.player.alive) {
        const px = this.player.x + this.player.w / 2;
        const py = this.player.y + this.player.h / 2;
        if (Math.hypot(px - dr.x, py - dr.y) <= 42) {
          if (this.equipGunIntoPlayerSlots(dr.gunId, dr.ammo, true)) {
            soundEngine.playPickup();
            this.spawnBurst(dr.x, dr.y, ARENA_GUNS[dr.gunId].color, 10, 170);
            this.weaponDrops.splice(i, 1);
            this.emitHud();
            continue;
          }
        }
      }
    }
  }

  private applyPickupToPlayer(pk: ArenaPickup): boolean {
    if (pk.kind === 'medkit') {
      if (this.player.hp >= this.player.maxHp) return false;
      this.player.hp = Math.min(this.player.maxHp, this.player.hp + 60);
    } else if (pk.kind === 'grenades') {
      if (this.player.grenades >= 5) return false;
      this.player.grenades = Math.min(5, this.player.grenades + 2);
    } else if (pk.kind === 'fuel') {
      if (this.player.fuel >= this.player.maxFuel - 2) return false;
      this.player.fuel = this.player.maxFuel;
    } else {
      const picked = this.equipGunIntoPlayerSlots(pk.kind, undefined, false);
      if (!picked) return false;
    }

    pk.active = false;
    pk.respawnTimer = 12;
    soundEngine.playPickup();
    this.spawnBurst(pk.x, pk.y, '#34D399', 8, 170);
    this.emitHud();
    return true;
  }

  private applyPickupToBot(pk: ArenaPickup, bot: ArenaBot) {
    pk.active = false;
    pk.respawnTimer = 12;
    if (pk.kind === 'medkit') {
      bot.hp = Math.min(bot.maxHp, bot.hp + 60);
    } else if (pk.kind === 'grenades') {
      bot.grenades = Math.min(4, bot.grenades + 2);
    } else if (pk.kind === 'fuel') {
      bot.fuel = 100;
    } else {
      bot.gunId = pk.kind;
      bot.ammo = ARENA_GUNS[pk.kind].clipSize;
      bot.reloadTimer = 0;
    }
  }

  private updateBots(dt: number) {
    for (const bot of this.bots) {
      if (!bot.alive) {
        bot.respawnTimer -= dt;
        if (bot.respawnTimer <= 0) {
          const sp = SPAWN_POINTS[Math.floor(Math.random() * SPAWN_POINTS.length)];
          const guns: ArenaGunId[] = ['shuriken_smg', 'venom_kunai', 'fire_crossbow'];
          const nextGun = guns[Math.floor(Math.random() * guns.length)];
          bot.x = sp.x;
          bot.y = sp.y;
          bot.vx = 0;
          bot.vy = 0;
          bot.hp = bot.maxHp;
          bot.fuel = 100;
          bot.gunId = nextGun;
          bot.ammo = ARENA_GUNS[nextGun].clipSize;
          bot.grenades = 2;
          bot.alive = true;
          bot.spawnShield = 1.6;
        }
        continue;
      }

      if (bot.spawnShield > 0) bot.spawnShield = Math.max(0, bot.spawnShield - dt);
      if (bot.hitFlash > 0) bot.hitFlash = Math.max(0, bot.hitFlash - dt);
      if (bot.fireCd > 0) bot.fireCd = Math.max(0, bot.fireCd - dt);
      if (bot.grenadeCd > 0) bot.grenadeCd = Math.max(0, bot.grenadeCd - dt);
      if (bot.reloadTimer > 0) {
        bot.reloadTimer -= dt;
        if (bot.reloadTimer <= 0) {
          bot.reloadTimer = 0;
          bot.ammo = ARENA_GUNS[bot.gunId].clipSize;
        }
      }

      let nearestX = this.player.x + this.player.w / 2;
      let nearestY = this.player.y + this.player.h / 2;
      let nearestDist = this.player.alive
        ? Math.hypot(nearestX - (bot.x + 18), nearestY - (bot.y + 27))
        : 99999;

      for (const other of this.bots) {
        if (other.id === bot.id || !other.alive) continue;
        const d = Math.hypot(other.x - bot.x, other.y - bot.y);
        if (d < nearestDist) {
          nearestDist = d;
          nearestX = other.x + other.w / 2;
          nearestY = other.y + other.h / 2;
        }
      }

      bot.aiDecisionTimer -= dt;
      if (bot.aiDecisionTimer <= 0) {
        bot.aiDecisionTimer = 0.65 + Math.random() * 0.45;
        const botCx = bot.x + bot.w / 2;
        const botCy = bot.y + bot.h / 2;
        const inLeftCave = botCx < 870 && botCy > 1160;
        const inRightCave = botCx > 2730 && botCy > 1160;
        const underCenterTunnel = botCx > 1425 && botCx < 2175 && botCy > 1300;
        let goalSet = false;

        if (bot.hp < 50) {
          const med = this.pickups.find((pk) => pk.active && pk.kind === 'medkit');
          if (med) {
            bot.aiTargetX = med.x;
            bot.aiTargetY = med.y;
            goalSet = true;
          }
        }
        if (!goalSet && bot.gunId === 'shuriken_smg') {
          const crate = this.pickups.find(
            (pk) =>
              pk.active &&
              (pk.kind === 'dragon_cannon' || pk.kind === 'fire_crossbow' || pk.kind === 'venom_kunai')
          );
          if (crate && Math.hypot(crate.x - bot.x, crate.y - bot.y) < 750) {
            bot.aiTargetX = crate.x;
            bot.aiTargetY = crate.y;
            goalSet = true;
          }
        }
        if (!goalSet) {
          if (inLeftCave && nearestY < 1100) {
            bot.aiTargetX = 990;
            bot.aiTargetY = 1280;
          } else if (inRightCave && nearestY < 1100) {
            bot.aiTargetX = 2610;
            bot.aiTargetY = 1280;
          } else if (underCenterTunnel && nearestY < 1200) {
            bot.aiTargetX = botCx < 1800 ? 1360 : 2240;
            bot.aiTargetY = 1360;
          } else {
            const offsetAngle = (Math.random() - 0.5) * 2.4;
            const desiredDist = 330;
            bot.aiTargetX = Math.max(240, Math.min(ARENA_W - 240, nearestX + Math.cos(offsetAngle) * desiredDist));
            bot.aiTargetY = Math.max(160, Math.min(ARENA_H - 220, nearestY - 80 + (Math.random() - 0.5) * 200));
          }
        }
      }

      const dx = bot.aiTargetX - (bot.x + bot.w / 2);
      const dy = bot.aiTargetY - (bot.y + bot.h / 2);
      const desiredVx = Math.abs(dx) > 25 ? Math.sign(dx) * 195 : 0;
      bot.vx += (desiredVx - bot.vx) * Math.min(1, dt * 7);

      const needLift = dy < -35 || (bot.y > this.getFloorYAt(bot.x + bot.w / 2) - 95 && Math.random() < 0.3);
      if (needLift && bot.fuel > 12) {
        bot.jetpackActive = true;
        bot.vy -= 960 * dt;
        if (bot.vy < -280) bot.vy = -280;
        bot.fuel = Math.max(0, bot.fuel - 24 * dt);
        if (Math.random() < 0.35) {
          this.spawnJetParticle(bot.x + bot.w / 2, bot.y + bot.h * 0.68, Math.cos(bot.aimAngle) >= 0 ? 1 : -1);
        }
      } else {
        bot.jetpackActive = false;
        bot.vy += 690 * dt;
        if (bot.vy > 500) bot.vy = 500;
        bot.fuel = Math.min(100, bot.fuel + (bot.grounded ? 26 : 12) * dt);
      }

      this.moveEntityWithTerrain(bot, dt);
      const aimToEnemy = Math.atan2(nearestY - (bot.y + bot.h * 0.42), nearestX - (bot.x + bot.w / 2));
      bot.aimAngle = aimToEnemy;
      this.updateScarf(bot.scarfPoints, bot.x + bot.w / 2, bot.y + 18, Math.cos(aimToEnemy) >= 0 ? 1 : -1, dt);

      if (nearestDist < 840 && bot.reloadTimer <= 0 && bot.fireCd <= 0) {
        const spec = ARENA_GUNS[bot.gunId];
        if (bot.ammo <= 0) {
          bot.reloadTimer = spec.reloadTime * 1.2;
        } else {
          bot.ammo -= 1;
          bot.fireCd = spec.fireInterval * 2.05;
          const bx = bot.x + bot.w / 2 + Math.cos(aimToEnemy) * 26;
          const by = bot.y + bot.h * 0.42 + Math.sin(aimToEnemy) * 26;
          const botSpread = aimToEnemy + (Math.random() - 0.5) * 0.17;
          this.fireGun(bx, by, botSpread, spec, bot.id, bot.name);
        }
      }

      if (nearestDist > 180 && nearestDist < 540 && bot.grenades > 0 && bot.grenadeCd <= 0) {
        bot.grenades -= 1;
        bot.grenadeCd = 9.5;
        this.grenades.push({
          x: bot.x + bot.w / 2,
          y: bot.y + bot.h * 0.35,
          vx: Math.cos(aimToEnemy) * 460,
          vy: Math.sin(aimToEnemy) * 460 - 115,
          r: 8,
          ownerId: bot.id,
          ownerName: bot.name,
          fuse: 1.85,
          bounces: 0,
        });
      }
    }
  }

  private moveEntityWithTerrain(
    ent: { x: number; y: number; vx: number; vy: number; w: number; h: number; grounded: boolean },
    dt: number
  ) {
    const prevBottom = ent.y + ent.h;
    ent.grounded = false;

    ent.x += ent.vx * dt;
    ent.y += ent.vy * dt;

    if (ent.x < 135) {
      ent.x = 135;
      if (ent.vx < 0) ent.vx = 0;
    } else if (ent.x + ent.w > ARENA_W - 135) {
      ent.x = ARENA_W - 135 - ent.w;
      if (ent.vx > 0) ent.vx = 0;
    }
    if (ent.y < 36) {
      ent.y = 36;
      if (ent.vy < 0) ent.vy = 0;
    }

    const r = 17;
    for (let pass = 0; pass < 2; pass++) {
      const circles = [
        { cx: ent.x + ent.w / 2, cy: ent.y + 18 },
        { cx: ent.x + ent.w / 2, cy: ent.y + ent.h - 17 },
      ];

      for (const poly of this.rockPolygons) {
        for (const c of circles) {
          if (
            c.cx + r < poly.minX ||
            c.cx - r > poly.maxX ||
            c.cy + r < poly.minY ||
            c.cy - r > poly.maxY
          ) {
            continue;
          }
          const hit = this.closestPointOnPolygon(c.cx, c.cy, poly);
          if (hit.inside || hit.dist < r) {
            let nx = hit.nx;
            let ny = hit.ny;
            let push = 0;
            if (hit.inside) {
              push = r + hit.dist;
            } else {
              const dx = c.cx - hit.px;
              const dy = c.cy - hit.py;
              const d = Math.hypot(dx, dy) || 1;
              nx = dx / d;
              ny = dy / d;
              push = r - d;
            }
            ent.x += nx * push;
            ent.y += ny * push;
            c.cx += nx * push;
            c.cy += ny * push;

            const vn = ent.vx * nx + ent.vy * ny;
            if (vn < 0) {
              ent.vx -= vn * nx;
              ent.vy -= vn * ny;
            }
            if (ny < -0.5) {
              ent.grounded = true;
            }
          }
        }
      }
    }

    const cx = ent.x + ent.w / 2;
    const floorY = this.getFloorYAt(cx);
    if (ent.y + ent.h >= floorY) {
      ent.y = floorY - ent.h;
      if (ent.vy > 0) ent.vy = 0;
      ent.grounded = true;
    }

    if (ent.vy >= 0) {
      for (const br of this.bridges) {
        if (cx >= br.x1 && cx <= br.x2) {
          const bridgeY = this.getBridgeYAt(br, cx);
          if (prevBottom <= bridgeY + 14 && ent.y + ent.h >= bridgeY) {
            ent.y = bridgeY - ent.h;
            ent.vy = 0;
            ent.grounded = true;
            break;
          }
        }
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.life -= dt;
      if (pr.life <= 0 || pr.x < 0 || pr.x > ARENA_W || pr.y < 0 || pr.y > ARENA_H) {
        this.projectiles.splice(i, 1);
        continue;
      }

      let hitWall = pr.y >= this.getFloorYAt(pr.x);
      if (!hitWall) {
        for (const poly of this.rockPolygons) {
          if (this.pointInPolygon(pr.x, pr.y, poly)) {
            hitWall = true;
            break;
          }
        }
      }
      if (!hitWall) {
        for (const br of this.bridges) {
          if (br.kind === 'stone' && pr.x >= br.x1 && pr.x <= br.x2) {
            const by = this.getBridgeYAt(br, pr.x);
            if (pr.y >= by && pr.y <= by + 16) {
              hitWall = true;
              break;
            }
          }
        }
      }

      if (hitWall) {
        if (pr.splashRadius > 0) {
          this.triggerSplashExplosion(
            pr.x,
            pr.y,
            pr.splashRadius,
            pr.damage,
            pr.ownerId,
            pr.ownerName,
            ARENA_GUNS[pr.gunId].nameEn,
            pr.color
          );
        } else {
          this.spawnBurst(pr.x, pr.y, pr.color, 4, 130);
        }
        this.projectiles.splice(i, 1);
        continue;
      }

      if (pr.ownerId !== this.localPlayerId && this.player.alive && this.player.spawnShield <= 0) {
        if (
          pr.x >= this.player.x &&
          pr.x <= this.player.x + this.player.w &&
          pr.y >= this.player.y &&
          pr.y <= this.player.y + this.player.h
        ) {
          if (pr.splashRadius > 0) {
            this.triggerSplashExplosion(
              pr.x,
              pr.y,
              pr.splashRadius,
              pr.damage,
              pr.ownerId,
              pr.ownerName,
              ARENA_GUNS[pr.gunId].nameEn,
              pr.color
            );
          } else if (!this.isOnline) {
            this.damageLocalPlayer(pr.damage, pr.ownerId, pr.ownerName, ARENA_GUNS[pr.gunId].nameEn);
          }
          this.spawnBurst(pr.x, pr.y, '#F43F5E', 6, 180);
          this.projectiles.splice(i, 1);
          continue;
        }
      }

      let consumed = false;
      for (const bot of this.bots) {
        if (!bot.alive || bot.id === pr.ownerId || bot.spawnShield > 0) continue;
        if (pr.x >= bot.x && pr.x <= bot.x + bot.w && pr.y >= bot.y && pr.y <= bot.y + bot.h) {
          if (pr.splashRadius > 0) {
            this.triggerSplashExplosion(
              pr.x,
              pr.y,
              pr.splashRadius,
              pr.damage,
              pr.ownerId,
              pr.ownerName,
              ARENA_GUNS[pr.gunId].nameEn,
              pr.color
            );
          } else {
            this.damageBot(bot, pr.damage, pr.ownerId, pr.ownerName, ARENA_GUNS[pr.gunId].nameEn);
          }
          consumed = true;
          break;
        }
      }
      if (consumed) {
        this.projectiles.splice(i, 1);
        continue;
      }

      if (this.isOnline && pr.ownerId === this.localPlayerId) {
        for (const peer of this.peers) {
          if (peer.alive === false) continue;
          if (pr.x >= peer.x && pr.x <= peer.x + 36 && pr.y >= peer.y && pr.y <= peer.y + 54) {
            const label = ARENA_GUNS[pr.gunId].nameEn;
            if (pr.splashRadius > 0) {
              this.triggerSplashExplosion(pr.x, pr.y, pr.splashRadius, pr.damage, pr.ownerId, pr.ownerName, label, pr.color);
            } else {
              this.callbacks.onArenaHit?.(peer.id, pr.damage, label);
            }
            this.spawnBurst(pr.x, pr.y, '#FDE047', 6, 200);
            consumed = true;
            break;
          }
        }
        if (consumed) {
          this.projectiles.splice(i, 1);
        }
      }
    }
  }

  private updateGrenades(dt: number) {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const gr = this.grenades[i];
      gr.vy += 740 * dt;
      gr.x += gr.vx * dt;
      gr.y += gr.vy * dt;

      const floorY = this.getFloorYAt(gr.x);
      if (gr.y + gr.r >= floorY) {
        const n = this.getFloorNormalAt(gr.x);
        gr.y = floorY - gr.r;
        const vn = gr.vx * n.x + gr.vy * n.y;
        if (vn < 0) {
          gr.vx = (gr.vx - 2 * vn * n.x) * 0.72;
          gr.vy = (gr.vy - 2 * vn * n.y) * 0.58;
          if (gr.bounces < 4) {
            gr.bounces += 1;
            soundEngine.playGrenadeBounce();
          }
        }
      }

      for (const poly of this.rockPolygons) {
        if (
          gr.x + gr.r < poly.minX ||
          gr.x - gr.r > poly.maxX ||
          gr.y + gr.r < poly.minY ||
          gr.y - gr.r > poly.maxY
        ) {
          continue;
        }
        const hit = this.closestPointOnPolygon(gr.x, gr.y, poly);
        if (hit.inside || hit.dist < gr.r) {
          let nx = hit.nx;
          let ny = hit.ny;
          let push = 0;
          if (hit.inside) {
            push = gr.r + hit.dist;
          } else {
            const dx = gr.x - hit.px;
            const dy = gr.y - hit.py;
            const d = Math.hypot(dx, dy) || 1;
            nx = dx / d;
            ny = dy / d;
            push = gr.r - d;
          }
          gr.x += nx * push;
          gr.y += ny * push;
          const vn = gr.vx * nx + gr.vy * ny;
          if (vn < 0) {
            gr.vx = (gr.vx - 2 * vn * nx) * 0.68;
            gr.vy = (gr.vy - 2 * vn * ny) * 0.62;
            if (gr.bounces < 4) {
              gr.bounces += 1;
              soundEngine.playGrenadeBounce();
            }
          }
        }
      }

      gr.fuse -= dt;
      if (gr.fuse <= 0) {
        this.triggerSplashExplosion(
          gr.x,
          gr.y,
          165,
          95,
          gr.ownerId,
          gr.ownerName,
          this.lang === 'ar' ? 'قنبلة' : 'Grenade',
          '#F59E0B'
        );
        this.grenades.splice(i, 1);
      }
    }
  }

  private triggerSplashExplosion(
    x: number,
    y: number,
    radius: number,
    maxDamage: number,
    ownerId: string,
    ownerName: string,
    weaponLabel: string,
    color: string
  ) {
    soundEngine.playExplosion();
    this.shakeTimer = 0.22;
    this.shakeIntensity = radius > 120 ? 10 : 5;
    this.blastRings.push({ x, y, maxR: radius, color, life: 0.28, maxLife: 0.28 });
    this.spawnBurst(x, y, color, this.effectsQuality === 'balanced' ? 10 : 22, 320);

    if (this.player.alive && this.player.spawnShield <= 0) {
      const dist = Math.hypot(this.player.x + 18 - x, this.player.y + 27 - y);
      if (dist < radius) {
        const dmg = Math.round(maxDamage * (1 - dist / (radius * 1.15)));
        if (!this.isOnline || ownerId === this.localPlayerId) {
          if (dmg > 4) this.damageLocalPlayer(dmg, ownerId, ownerName, weaponLabel);
        }
      }
    }

    for (const bot of this.bots) {
      if (!bot.alive || bot.spawnShield > 0) continue;
      const dist = Math.hypot(bot.x + 18 - x, bot.y + 27 - y);
      if (dist < radius) {
        const dmg = Math.round(maxDamage * (1 - dist / (radius * 1.15)));
        if (dmg > 4) this.damageBot(bot, dmg, ownerId, ownerName, weaponLabel);
      }
    }

    if (this.isOnline && ownerId === this.localPlayerId) {
      for (const peer of this.peers) {
        if (peer.alive === false) continue;
        const dist = Math.hypot(peer.x + 18 - x, peer.y + 27 - y);
        if (dist < radius) {
          const dmg = Math.round(maxDamage * (1 - dist / (radius * 1.15)));
          if (dmg > 4) this.callbacks.onArenaHit?.(peer.id, dmg, weaponLabel);
        }
      }
    }
  }

  private damageLocalPlayer(dmg: number, attackerId: string, attackerName: string, weaponLabel: string) {
    this.player.hp = Math.max(0, this.player.hp - dmg);
    this.player.hitFlash = 0.16;
    soundEngine.playDamage();
    if (this.player.hp <= 0) {
      this.eliminateLocalPlayer(attackerId, attackerName, weaponLabel);
    }
  }

  private eliminateLocalPlayer(killerId: string, killerName: string, weaponLabel: string) {
    if (!this.player.alive) return;
    const droppedGun = this.getActiveSlot().gunId;
    this.player.alive = false;
    this.player.deaths += 1;
    this.player.respawnTimer = 3.0;
    this.firing = false;
    this.spawnBurst(this.player.x + 18, this.player.y + 27, '#E11D48', 18, 250);

    if (killerId && killerId !== this.localPlayerId) {
      const killerBot = this.bots.find((b) => b.id === killerId);
      if (killerBot) killerBot.kills += 1;
    }

    if (this.isOnline) {
      this.callbacks.onLocalKilled?.(killerId, weaponLabel, droppedGun);
    } else {
      this.spawnWeaponDrop(this.player.x + 18, this.player.y + 20, droppedGun);
      this.pushKillEvent(
        killerId === this.localPlayerId ? this.profile.displayName : killerName,
        this.profile.displayName,
        weaponLabel,
        killerId
      );
      this.checkOfflineWinTarget();
    }
  }

  private damageBot(
    bot: ArenaBot,
    dmg: number,
    attackerId: string,
    attackerName: string,
    weaponLabel: string
  ) {
    bot.hp = Math.max(0, bot.hp - dmg);
    bot.hitFlash = 0.14;
    this.spawnBurst(bot.x + 18, bot.y + 27, '#FDE047', 6, 190);
    if (attackerId === this.localPlayerId) {
      soundEngine.playSwordClash(dmg >= 35);
    }
    if (bot.hp <= 0) {
      bot.alive = false;
      bot.deaths += 1;
      bot.respawnTimer = 3.0;
      this.spawnBurst(bot.x + 18, bot.y + 27, '#E11D48', 18, 250);
      // Drop the killed bot's active weapon on the battlefield!
      this.spawnWeaponDrop(bot.x + 18, bot.y + 20, bot.gunId);

      if (attackerId !== bot.id) {
        const attackerBot = this.bots.find((b) => b.id === attackerId);
        if (attackerBot) attackerBot.kills += 1;
      }
      this.pushKillEvent(attackerName, bot.name, weaponLabel, attackerId);
      this.checkOfflineWinTarget();
    }
  }

  private checkOfflineWinTarget() {
    if (this.matchEnded || this.isOnline) return;
    if (this.player.kills >= ARENA_KILL_TARGET || this.bots.some((b) => b.kills >= ARENA_KILL_TARGET)) {
      this.finishOfflineMatch('target_reached');
    }
  }

  private finishOfflineMatch(reason: 'target_reached' | 'time_up') {
    if (this.matchEnded) return;
    this.matchEnded = true;
    const standings = this.buildStandings();
    const won = standings[0]?.id === this.localPlayerId;
    this.winReason = reason;
    this.winnerName = standings[0]?.name || this.profile.displayName;
    this.emitHud();
    this.callbacks.onMatchComplete({
      victory: won,
      stageId: 'arena',
      score: this.player.kills * 150 + (won ? 350 : 60),
      gemsEarned: Math.max(12, this.player.kills * 10 + (won ? 45 : 10)),
      xpEarned: Math.max(35, this.player.kills * 30 + (won ? 120 : 35)),
      elapsedSec: Math.round(this.elapsedSec),
      bossDefeated: won,
      isSeasonal: false,
    });
  }

  private spawnJetParticle(x: number, y: number, facing: number) {
    this.particles.push({
      x: x - facing * 8 + (Math.random() - 0.5) * 6,
      y,
      vx: -facing * 35 + (Math.random() - 0.5) * 32,
      vy: 120 + Math.random() * 90,
      size: 3 + Math.random() * 2.5,
      color: Math.random() < 0.5 ? '#38BDF8' : '#F59E0B',
      life: 0.24,
      maxLife: 0.24,
      gravity: 40,
    });
  }

  private spawnBurst(x: number, y: number, color: string, count: number, speed: number) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.4 + Math.random() * 0.7);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        size: 2 + Math.random() * 3,
        color,
        life: 0.25 + Math.random() * 0.25,
        maxLife: 0.5,
        gravity: 260,
      });
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.vy += pt.gravity * dt;
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= dt;
      if (pt.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.blastRings.length - 1; i >= 0; i--) {
      const r = this.blastRings[i];
      r.life -= dt;
      if (r.life <= 0) this.blastRings.splice(i, 1);
    }
  }

  private updateScarf(pts: Vec2[], headX: number, headY: number, facing: number, dt: number) {
    pts[0].x = headX - facing * 6;
    pts[0].y = headY;
    for (let i = 1; i < pts.length; i++) {
      const prev = pts[i - 1];
      const cur = pts[i];
      cur.y += 42 * dt;
      cur.x -= facing * 48 * dt;
      const dx = cur.x - prev.x;
      const dy = cur.y - prev.y;
      const dist = Math.hypot(dx, dy) || 1;
      const maxLen = 7.5;
      if (dist > maxLen) {
        cur.x = prev.x + (dx / dist) * maxLen;
        cur.y = prev.y + (dy / dist) * maxLen;
      }
    }
  }

  private updateCamera(dt: number) {
    const viewW = this.canvas.width || 1280;
    const viewH = this.canvas.height || 720;
    const targetX = this.player.x + this.player.w / 2 - viewW / 2;
    const targetY = this.player.y + this.player.h / 2 - viewH / 2;
    const clampedX = Math.max(0, Math.min(Math.max(0, ARENA_W - viewW), targetX));
    const clampedY = Math.max(0, Math.min(Math.max(0, ARENA_H - viewH), targetY));
    this.camX += (clampedX - this.camX) * Math.min(1, dt * 7);
    this.camY += (clampedY - this.camY) * Math.min(1, dt * 7);
  }

  private buildStandings(): ArenaStandingsEntry[] {
    const entries: ArenaStandingsEntry[] = [
      {
        id: this.localPlayerId,
        name: this.profile.displayName,
        kills: this.player.kills,
        deaths: this.player.deaths,
        isLocal: true,
        isBot: false,
      },
    ];
    for (const bot of this.bots) {
      entries.push({
        id: bot.id,
        name: bot.name,
        kills: bot.kills,
        deaths: bot.deaths,
        isLocal: false,
        isBot: true,
      });
    }
    for (const peer of this.peers) {
      entries.push({
        id: peer.id,
        name: peer.displayName,
        kills: peer.kills || 0,
        deaths: peer.deaths || 0,
        isLocal: false,
        isBot: false,
      });
    }
    return entries.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths);
  }

  private toSlotSnapshot(sl: WeaponSlotState): ArenaWeaponSlotSnapshot {
    const spec = ARENA_GUNS[sl.gunId];
    return {
      gunId: sl.gunId,
      ammo: sl.ammo,
      maxAmmo: spec.clipSize,
      reloading: sl.reloadTimer > 0,
      reloadProgress: sl.reloadTimer > 0 ? 1 - sl.reloadTimer / spec.reloadTime : 1,
    };
  }

  private emitHud() {
    const active = this.getActiveSlot();
    const spec = ARENA_GUNS[active.gunId];
    this.callbacks.onHudUpdate({
      hp: Math.round(this.player.hp),
      maxHp: this.player.maxHp,
      fuel: Math.round(this.player.fuel),
      maxFuel: this.player.maxFuel,
      gunId: active.gunId,
      ammo: active.ammo,
      maxAmmo: spec.clipSize,
      reloading: active.reloadTimer > 0,
      reloadProgress: active.reloadTimer > 0 ? 1 - active.reloadTimer / spec.reloadTime : 1,
      weapons: [
        this.toSlotSnapshot(this.player.slots[0]),
        this.player.slots[1] ? this.toSlotSnapshot(this.player.slots[1]) : null,
      ],
      activeWeaponSlot: this.player.activeSlot,
      grenades: this.player.grenades,
      kills: this.player.kills,
      deaths: this.player.deaths,
      killTarget: ARENA_KILL_TARGET,
      winReason: this.winReason,
      winnerName: this.winnerName,
      timeRemainingSec: Math.max(0, Math.ceil(ARENA_MATCH_DURATION_SEC - this.elapsedSec)),
      respawnRemainingSec: this.player.alive ? 0 : Math.max(0, Math.ceil(this.player.respawnTimer)),
      killFeed: [...this.killFeed],
      standings: this.buildStandings(),
    });
  }

  private render() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    // 1. Deep Mountain Night Sky Gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
    skyGrad.addColorStop(0, '#040812');
    skyGrad.addColorStop(0.55, '#0A1527');
    skyGrad.addColorStop(1, '#141E2E');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h);

    if (this.bgImg && this.bgImg.complete && this.bgImg.naturalWidth > 0) {
      ctx.save();
      ctx.globalAlpha = 0.24;
      const scale = Math.max(w / this.bgImg.naturalWidth, h / this.bgImg.naturalHeight) * 1.15;
      const drawW = this.bgImg.naturalWidth * scale;
      const drawH = this.bgImg.naturalHeight * scale;
      const ox = -((this.camX / ARENA_W) * (drawW - w));
      const oy = -((this.camY / ARENA_H) * (drawH - h));
      ctx.drawImage(this.bgImg, ox, oy, drawW, drawH);
      ctx.restore();
    }

    for (const st of this.stars) {
      ctx.fillStyle = `rgba(226, 232, 240, ${st.alpha})`;
      ctx.beginPath();
      ctx.arc(st.x * w, st.y * h, st.r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Full Moon + Glow
    const moonX = w * 0.5 - (this.camX / ARENA_W - 0.5) * 90;
    const moonY = h * 0.2 - (this.camY / ARENA_H) * 45;
    const moonGlow = ctx.createRadialGradient(moonX, moonY, 18, moonX, moonY, 210);
    moonGlow.addColorStop(0, 'rgba(224, 242, 254, 0.34)');
    moonGlow.addColorStop(0.45, 'rgba(125, 211, 252, 0.1)');
    moonGlow.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = moonGlow;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 210, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#E2E8F0';
    ctx.beginPath();
    ctx.arc(moonX, moonY, 34, 0, Math.PI * 2);
    ctx.fill();

    // 2. Brown Parallax Mountain Ranges
    for (const ridge of this.parallaxRidges) {
      ctx.save();
      const shiftX = -this.camX * ridge.factor;
      const shiftY = -this.camY * (ridge.factor * 0.35);
      ctx.translate(shiftX, shiftY);
      ctx.fillStyle = ridge.color;
      ctx.beginPath();
      ctx.moveTo(ridge.points[0].x, ridge.points[0].y);
      for (let i = 1; i < ridge.points.length; i++) {
        ctx.lineTo(ridge.points[i].x, ridge.points[i].y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    const shakeX = this.shakeTimer > 0 ? (Math.random() - 0.5) * this.shakeIntensity * 2 : 0;
    const shakeY = this.shakeTimer > 0 ? (Math.random() - 0.5) * this.shakeIntensity * 2 : 0;

    ctx.save();
    ctx.translate(-this.camX + shakeX, -this.camY + shakeY);

    if (this.effectsQuality === 'high') {
      ctx.save();
      const beamGrad = ctx.createLinearGradient(1650, 80, 1950, 1700);
      beamGrad.addColorStop(0, 'rgba(186, 230, 253, 0.08)');
      beamGrad.addColorStop(1, 'rgba(186, 230, 253, 0)');
      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(1400, 40);
      ctx.lineTo(2200, 40);
      ctx.lineTo(2600, ARENA_H);
      ctx.lineTo(1000, ARENA_H);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // 3. Cave & Tunnel Lantern Light Pools
    for (const ln of this.lanterns) {
      const flicker = 0.88 + Math.sin(this.elapsedSec * 7 + ln.phase) * 0.12;
      const rad = 160 * flicker;
      const glow = ctx.createRadialGradient(ln.x, ln.y, 4, ln.x, ln.y, rad);
      glow.addColorStop(0, 'rgba(251, 146, 60, 0.34)');
      glow.addColorStop(0.5, 'rgba(245, 158, 11, 0.11)');
      glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(ln.x, ln.y, rad, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#1E293B';
      ctx.fillRect(ln.x - 5, ln.y - 8, 10, 14);
      ctx.fillStyle = '#FDBA74';
      ctx.beginPath();
      ctx.arc(ln.x, ln.y, 3.5 * flicker, 0, Math.PI * 2);
      ctx.fill();
    }

    // 4. Bridges
    for (const br of this.bridges) {
      this.drawBridge(ctx, br);
    }

    // 5. Brown Mountain Valley Floor
    this.drawMountainFloor(ctx);

    // 6. Rocks Colored By Type
    for (const poly of this.rockPolygons) {
      this.drawRockPolygon(ctx, poly);
    }

    // 7. Drifting Mountain Mist
    for (const m of this.mistRibbons) {
      const alpha = this.effectsQuality === 'balanced' ? m.alpha * 0.5 : m.alpha;
      const mg = ctx.createRadialGradient(
        m.x + m.w / 2,
        m.y + m.h / 2,
        12,
        m.x + m.w / 2,
        m.y + m.h / 2,
        m.w * 0.55
      );
      mg.addColorStop(0, `rgba(186, 230, 253, ${alpha})`);
      mg.addColorStop(1, 'rgba(186, 230, 253, 0)');
      ctx.fillStyle = mg;
      ctx.beginPath();
      ctx.ellipse(m.x + m.w / 2, m.y + m.h / 2, m.w / 2, m.h / 2, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // 8. Upgraded Recognizable Supply Crates
    for (const pk of this.pickups) {
      if (!pk.active) continue;
      this.drawSupplyCrate(ctx, pk);
    }

    // 9. Dropped Enemy Weapons (Mini-Militia Style Loot!)
    for (const dr of this.weaponDrops) {
      this.drawWeaponDrop(ctx, dr);
    }

    // 10. Blast shockwaves, Grenades, Projectiles, Particles
    for (const r of this.blastRings) {
      const prog = 1 - r.life / r.maxLife;
      ctx.save();
      ctx.strokeStyle = r.color;
      ctx.globalAlpha = 1 - prog;
      ctx.lineWidth = 4 * (1 - prog) + 1;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.maxR * prog, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    for (const gr of this.grenades) {
      ctx.save();
      ctx.fillStyle = gr.fuse < 0.45 && Math.floor(gr.fuse * 18) % 2 === 0 ? '#EF4444' : '#334155';
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(gr.x, gr.y, gr.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    for (const pr of this.projectiles) {
      const ang = Math.atan2(pr.vy, pr.vx);
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.rotate(ang);
      ctx.fillStyle = pr.color;
      ctx.fillRect(-10, -pr.r * 0.45, 20, pr.r * 0.9);
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(6, 0, pr.r * 0.55, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (const pt of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
      ctx.fillStyle = pt.color;
      ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
      ctx.restore();
    }

    // 11. Bots & Online Peers
    for (const bot of this.bots) {
      if (!bot.alive) continue;
      this.drawArenaFighter(
        ctx,
        bot.x,
        bot.y,
        bot.w,
        bot.h,
        bot.aimAngle,
        bot.skin,
        bot.scarfPoints,
        bot.name,
        bot.hp,
        bot.maxHp,
        bot.jetpackActive,
        bot.hitFlash > 0,
        bot.spawnShield > 0,
        false
      );
    }

    for (const peer of this.peers) {
      if (peer.alive === false) continue;
      const peerSkin = SKINS.find((s) => s.id === peer.skin) || SKINS[1];
      this.drawArenaFighter(
        ctx,
        peer.x,
        peer.y,
        36,
        54,
        peer.aimAngle ?? (peer.facing >= 0 ? 0 : Math.PI),
        peerSkin,
        null,
        peer.displayName,
        peer.hp,
        peer.maxHp,
        Boolean(peer.jetpackActive),
        false,
        false,
        false
      );
    }

    // 12. Local Player & Aim sightline
    if (this.player.alive) {
      const cx = this.player.x + this.player.w / 2;
      const cy = this.player.y + this.player.h * 0.42;
      ctx.save();
      ctx.setLineDash([6, 6]);
      ctx.strokeStyle = 'rgba(244, 63, 94, 0.42)';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(this.player.aimAngle) * 24, cy + Math.sin(this.player.aimAngle) * 24);
      ctx.lineTo(cx + Math.cos(this.player.aimAngle) * 195, cy + Math.sin(this.player.aimAngle) * 195);
      ctx.stroke();
      ctx.restore();

      const rx = cx + Math.cos(this.player.aimAngle) * 195;
      const ry = cy + Math.sin(this.player.aimAngle) * 195;
      ctx.save();
      ctx.strokeStyle = '#F43F5E';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(rx, ry, 9, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      if (this.player.meleeFlash > 0) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(this.player.aimAngle);
        ctx.strokeStyle = '#FDE047';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(10, 0, 48, -0.9, 0.9);
        ctx.stroke();
        ctx.restore();
      }

      this.drawArenaFighter(
        ctx,
        this.player.x,
        this.player.y,
        this.player.w,
        this.player.h,
        this.player.aimAngle,
        this.localSkin,
        this.player.scarfPoints,
        this.profile.displayName,
        this.player.hp,
        this.player.maxHp,
        this.player.jetpackActive,
        this.player.hitFlash > 0,
        this.player.spawnShield > 0,
        true
      );
    }

    ctx.restore();

    // 13. Render Mini-Radar exclusively inside Top Bar canvas (zero overlap on combat canvas!)
    if (this.radarCanvas) {
      this.renderRadarToCanvas(this.radarCanvas);
    }
  }

  private drawSupplyCrate(ctx: CanvasRenderingContext2D, pk: ArenaPickup) {
    const py = pk.y + Math.sin(pk.bobPhase) * 4.5;
    ctx.save();
    ctx.translate(pk.x, py);

    if (pk.kind === 'medkit') {
      // Crisp White Medical Case with Red + Cross in center
      ctx.fillStyle = '#CBD5E1';
      ctx.fillRect(-7, -20, 14, 5); // Top carry handle
      ctx.fillStyle = '#F8FAFC';
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-18, -15, 36, 30, 6);
      ctx.fill();
      ctx.stroke();

      // Bold Red '+' Medical Cross
      ctx.fillStyle = '#DC2626';
      ctx.fillRect(-3.5, -10, 7, 20);
      ctx.fillRect(-10, -3.5, 20, 7);
    } else if (pk.kind === 'fuel') {
      // Pressurized Blue Jetpack Fuel Canister
      ctx.fillStyle = '#94A3B8';
      ctx.fillRect(-5, -20, 10, 6); // Nozzle cap
      ctx.fillStyle = '#0284C7';
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-13, -15, 26, 31, 6);
      ctx.fill();
      ctx.stroke();

      // Fuel Gauge Stripe + Flame Drop
      ctx.fillStyle = '#E0F2FE';
      ctx.fillRect(-7, -7, 14, 5);
      ctx.fillStyle = '#38BDF8';
      ctx.fillRect(-7, 1, 14, 9);
    } else if (pk.kind === 'grenades') {
      // Tactical Olive/Amber Grenade Ammo Crate
      ctx.fillStyle = '#365314';
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-17, -14, 34, 28, 5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#65A30D';
      ctx.fillRect(-15, -12, 30, 5);
      // Grenade sphere icon inside
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(0, 4, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FEF3C7';
      ctx.fillRect(-3, -6, 6, 4);
    } else {
      // Weapon Armory Chest with Weapon Silhouette
      const spec = ARENA_GUNS[pk.kind];
      ctx.fillStyle = '#0F172A';
      ctx.strokeStyle = spec.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-20, -14, 40, 28, 6);
      ctx.fill();
      ctx.stroke();
      this.drawWeaponSilhouette(ctx, pk.kind, 0, 1, 1.05);
    }

    ctx.restore();
  }

  private drawWeaponDrop(ctx: CanvasRenderingContext2D, dr: WeaponDrop) {
    const spec = ARENA_GUNS[dr.gunId];
    const py = dr.y + Math.sin(dr.bobPhase) * 3;
    ctx.save();
    ctx.translate(dr.x, py);

    // Subtle ground aura so dropped enemy gun is immediately noticeable
    const aura = ctx.createRadialGradient(0, 0, 3, 0, 0, 24);
    aura.addColorStop(0, `${spec.color}55`);
    aura.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();

    this.drawWeaponSilhouette(ctx, dr.gunId, 0, 0, 1.25);

    ctx.font = 'bold 10px Cairo, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#F8FAFC';
    ctx.fillText(this.lang === 'ar' ? spec.nameAr : spec.nameEn, 0, -16);
    ctx.restore();
  }

  private drawWeaponSilhouette(
    ctx: CanvasRenderingContext2D,
    gunId: ArenaGunId,
    x: number,
    y: number,
    scale: number
  ) {
    const spec = ARENA_GUNS[gunId];
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    if (gunId === 'dragon_cannon') {
      ctx.fillStyle = '#334155';
      ctx.fillRect(-13, -5, 22, 9);
      ctx.fillStyle = spec.color;
      ctx.fillRect(6, -6, 8, 11);
      ctx.fillRect(-10, 4, 5, 5);
    } else if (gunId === 'fire_crossbow') {
      ctx.strokeStyle = spec.color;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(6, 0, 8, -Math.PI * 0.45, Math.PI * 0.45);
      ctx.stroke();
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(-12, -2, 23, 4);
    } else if (gunId === 'venom_kunai') {
      ctx.fillStyle = '#CBD5E1';
      ctx.fillRect(-11, -3.5, 19, 5);
      ctx.fillStyle = spec.color;
      ctx.fillRect(5, -4, 8, 4);
      ctx.fillRect(-7, 1.5, 5, 6);
    } else {
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(-11, -3, 18, 5);
      ctx.fillStyle = spec.color;
      ctx.fillRect(5, -2.5, 7, 4);
      ctx.fillRect(-6, 2, 4, 5);
    }
    ctx.restore();
  }

  private drawMountainFloor(ctx: CanvasRenderingContext2D) {
    const pts = this.terrainCurve;
    ctx.save();
    const grad = ctx.createLinearGradient(0, 1300, 0, ARENA_H);
    grad.addColorStop(0, '#61412D');
    grad.addColorStop(0.28, '#3F291C');
    grad.addColorStop(1, '#1C110B');
    ctx.fillStyle = grad;

    ctx.beginPath();
    ctx.moveTo(0, ARENA_H);
    for (const pt of pts) {
      ctx.lineTo(pt.x, pt.y);
    }
    ctx.lineTo(ARENA_W, ARENA_H);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#7E563D';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y + 2);
    for (let i = 1; i < pts.length; i++) {
      ctx.lineTo(pts[i].x, pts[i].y + 2);
    }
    ctx.stroke();

    ctx.strokeStyle = 'rgba(229, 195, 158, 0.36)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) {
      ctx.lineTo(pts[i].x, pts[i].y);
    }
    ctx.stroke();

    this.drawGrassTufts(ctx, this.floorGrass);
    ctx.restore();
  }

  private drawRockPolygon(ctx: CanvasRenderingContext2D, poly: RockPolygon) {
    const pts = poly.points;
    ctx.save();

    const grad = ctx.createLinearGradient(0, poly.minY, 0, poly.maxY);
    let outlineColor = '#1C120C';
    let rimColor = 'rgba(214, 179, 145, 0.35)';
    let crackDark = 'rgba(20, 12, 8, 0.55)';
    let crackLight = 'rgba(214, 179, 145, 0.14)';

    if (poly.kind === 'peak_wall') {
      grad.addColorStop(0, '#5A3C29');
      grad.addColorStop(0.5, '#382418');
      grad.addColorStop(1, '#1B100A');
      outlineColor = '#21130C';
      rimColor = 'rgba(214, 179, 145, 0.28)';
    } else if (poly.kind === 'cave_roof') {
      grad.addColorStop(0, '#4B4440');
      grad.addColorStop(0.35, '#2A2B30');
      grad.addColorStop(1, '#121418');
      outlineColor = '#0E1014';
      rimColor = 'rgba(186, 200, 218, 0.38)';
      crackDark = 'rgba(8, 10, 14, 0.62)';
      crackLight = 'rgba(148, 163, 184, 0.15)';
    } else if (poly.kind === 'outcrop') {
      grad.addColorStop(0, '#7C6449');
      grad.addColorStop(0.45, '#53412E');
      grad.addColorStop(1, '#2B2016');
      outlineColor = '#241A12';
      rimColor = 'rgba(253, 224, 172, 0.44)';
      crackDark = 'rgba(30, 20, 12, 0.55)';
      crackLight = 'rgba(253, 230, 196, 0.18)';
    } else {
      grad.addColorStop(0, '#6B7A8F');
      grad.addColorStop(0.42, '#445063');
      grad.addColorStop(1, '#1F2937');
      outlineColor = '#161F2C';
      rimColor = 'rgba(224, 242, 254, 0.58)';
      crackDark = 'rgba(15, 23, 42, 0.52)';
      crackLight = 'rgba(224, 242, 254, 0.2)';
    }

    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) {
      ctx.lineTo(pts[i].x, pts[i].y);
    }
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.save();
    ctx.clip();
    ctx.strokeStyle = crackDark;
    ctx.lineWidth = 2.5;
    for (const cr of poly.cracks) {
      ctx.beginPath();
      ctx.moveTo(cr.x1, cr.y1);
      ctx.lineTo(cr.x2, cr.y2);
      ctx.stroke();
    }
    ctx.strokeStyle = crackLight;
    ctx.lineWidth = 1.2;
    for (const cr of poly.cracks) {
      ctx.beginPath();
      ctx.moveTo(cr.x1 + 2, cr.y1 + 1);
      ctx.lineTo(cr.x2 + 2, cr.y2 + 1);
      ctx.stroke();
    }
    ctx.restore();

    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = 2.4;
    ctx.stroke();

    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const len = Math.hypot(dx, dy) || 1;
      const ny = -dx / len;
      if (ny < -0.35) {
        ctx.strokeStyle = rimColor;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }

    if (poly.grassTufts.length > 0) {
      this.drawGrassTufts(ctx, poly.grassTufts);
    }
    ctx.restore();
  }

  private drawGrassTufts(
    ctx: CanvasRenderingContext2D,
    tufts: { x: number; y: number; h: number; phase: number }[]
  ) {
    const animateWind = this.effectsQuality === 'high';
    ctx.save();
    ctx.lineWidth = 1.8;
    ctx.lineCap = 'round';
    for (const tf of tufts) {
      const sway = animateWind ? Math.sin(this.elapsedSec * 2.4 + tf.phase) * 4.2 : 1.5;
      ctx.strokeStyle = '#1E463B';
      ctx.beginPath();
      ctx.moveTo(tf.x - 3, tf.y);
      ctx.quadraticCurveTo(tf.x - 4 + sway * 0.5, tf.y - tf.h * 0.5, tf.x - 5 + sway, tf.y - tf.h);
      ctx.stroke();

      ctx.strokeStyle = '#2F6F5E';
      ctx.beginPath();
      ctx.moveTo(tf.x + 2, tf.y);
      ctx.quadraticCurveTo(tf.x + 3 + sway * 0.6, tf.y - tf.h * 0.55, tf.x + 4 + sway * 1.1, tf.y - tf.h * 1.05);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawBridge(ctx: CanvasRenderingContext2D, br: MountainBridge) {
    ctx.save();
    const steps = 16;
    if (br.kind === 'rope') {
      ctx.strokeStyle = '#92400E';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const x = br.x1 + (br.x2 - br.x1) * t;
        const y = this.getBridgeYAt(br, x) - 18;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      for (let i = 0; i < steps; i++) {
        const t1 = i / steps;
        const t2 = (i + 0.8) / steps;
        const x1 = br.x1 + (br.x2 - br.x1) * t1;
        const x2 = br.x1 + (br.x2 - br.x1) * t2;
        const y = this.getBridgeYAt(br, (x1 + x2) / 2);

        ctx.strokeStyle = 'rgba(180, 83, 9, 0.55)';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(x1, y - 18);
        ctx.lineTo(x1, y);
        ctx.stroke();

        ctx.fillStyle = '#451A03';
        ctx.strokeStyle = '#B45309';
        ctx.lineWidth = 1;
        ctx.fillRect(x1, y - 3, x2 - x1, 7);
        ctx.strokeRect(x1, y - 3, x2 - x1, 7);
      }
    } else {
      ctx.fillStyle = '#6B5A45';
      ctx.strokeStyle = '#A68E70';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const x = br.x1 + (br.x2 - br.x1) * t;
        const y = this.getBridgeYAt(br, x);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      for (let i = steps; i >= 0; i--) {
        const t = i / steps;
        const x = br.x1 + (br.x2 - br.x1) * t;
        const y = this.getBridgeYAt(br, x) + 18;
        ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawArenaFighter(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    aimAngle: number,
    skin: SkinDefinition,
    scarfPoints: Vec2[] | null,
    name: string,
    hp: number,
    maxHp: number,
    jetpackActive: boolean,
    hitFlash: boolean,
    shielded: boolean,
    isLocal: boolean
  ) {
    const facing = Math.cos(aimAngle) >= 0 ? 1 : -1;
    const cx = x + w / 2;
    const cy = y + h * 0.44;

    if (scarfPoints && scarfPoints.length > 1) {
      ctx.save();
      ctx.strokeStyle = skin.scarfColor;
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(scarfPoints[0].x, scarfPoints[0].y);
      for (let i = 1; i < scarfPoints.length; i++) {
        ctx.lineTo(scarfPoints[i].x, scarfPoints[i].y);
      }
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    if (shielded) {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, y + h / 2, 34, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = '#334155';
    ctx.fillRect(cx - facing * 15 - 4, y + 20, 8, 18);
    if (jetpackActive) {
      ctx.fillStyle = '#38BDF8';
      ctx.beginPath();
      ctx.moveTo(cx - facing * 15 - 3, y + 38);
      ctx.lineTo(cx - facing * 15 + 3, y + 38);
      ctx.lineTo(cx - facing * 15, y + 52 + Math.random() * 8);
      ctx.closePath();
      ctx.fill();
    }

    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.fillRect(x + 9, y + 34, 7, 18);
    ctx.fillRect(x + 20, y + 34, 7, 18);
    ctx.beginPath();
    ctx.roundRect(x + 6, y + 16, 24, 22, 6);
    ctx.fill();

    ctx.fillStyle = skin.trimColor;
    ctx.fillRect(x + 7, y + 31, 22, 4);

    ctx.fillStyle = hitFlash ? '#FFFFFF' : skin.suitColor;
    ctx.beginPath();
    ctx.arc(cx, y + 11, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = skin.scarfColor;
    ctx.fillRect(cx - 11, y + 5, 22, 4);
    ctx.fillStyle = skin.eyeColor;
    ctx.fillRect(cx + facing * 3 - 2, y + 10, 6, 3);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(aimAngle);
    ctx.fillStyle = skin.suitColor;
    ctx.fillRect(0, -3.5, 18, 7);
    ctx.fillStyle = '#E2E8F0';
    ctx.fillRect(14, -4, 15, 6);
    ctx.fillStyle = '#F43F5E';
    ctx.fillRect(25, -2.5, 5, 3);
    ctx.restore();

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(cx - 24, y - 16, 48, 5);
    ctx.fillStyle = isLocal ? '#38BDF8' : '#E11D48';
    ctx.fillRect(cx - 24, y - 16, 48 * Math.max(0, Math.min(1, hp / Math.max(1, maxHp))), 5);

    ctx.font = 'bold 11px Cairo, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = isLocal ? '#BAE6FD' : '#F8FAFC';
    ctx.fillText(name, cx, y - 22);
    ctx.restore();
  }

  private renderRadarToCanvas(radarCanvas: HTMLCanvasElement) {
    const rCtx = radarCanvas.getContext('2d');
    if (!rCtx) return;
    const rw = radarCanvas.width;
    const rh = radarCanvas.height;
    const sx = rw / ARENA_W;
    const sy = rh / ARENA_H;

    rCtx.clearRect(0, 0, rw, rh);
    rCtx.fillStyle = '#070B14';
    rCtx.fillRect(0, 0, rw, rh);

    // Brown mountain floor
    rCtx.fillStyle = 'rgba(128, 86, 60, 0.62)';
    rCtx.beginPath();
    rCtx.moveTo(0, rh);
    for (const pt of this.terrainCurve) {
      rCtx.lineTo(pt.x * sx, pt.y * sy);
    }
    rCtx.lineTo(rw, rh);
    rCtx.closePath();
    rCtx.fill();

    // Rock polygons colored by type
    for (const poly of this.rockPolygons) {
      rCtx.fillStyle =
        poly.kind === 'peak_wall'
          ? 'rgba(108, 72, 48, 0.68)'
          : poly.kind === 'cave_roof'
          ? 'rgba(72, 76, 84, 0.72)'
          : poly.kind === 'outcrop'
          ? 'rgba(138, 112, 82, 0.72)'
          : 'rgba(120, 138, 160, 0.75)';
      rCtx.beginPath();
      rCtx.moveTo(poly.points[0].x * sx, poly.points[0].y * sy);
      for (let i = 1; i < poly.points.length; i++) {
        rCtx.lineTo(poly.points[i].x * sx, poly.points[i].y * sy);
      }
      rCtx.closePath();
      rCtx.fill();
    }

    // Active pickups & weapon drops
    for (const pk of this.pickups) {
      if (!pk.active) continue;
      rCtx.fillStyle = pk.kind === 'medkit' ? '#FFFFFF' : '#F59E0B';
      rCtx.fillRect(pk.x * sx - 1, pk.y * sy - 1, 2, 2);
    }
    for (const dr of this.weaponDrops) {
      rCtx.fillStyle = ARENA_GUNS[dr.gunId].color;
      rCtx.fillRect(dr.x * sx - 1.5, dr.y * sy - 1.5, 3, 3);
    }

    // Bots & Online peers
    rCtx.fillStyle = '#F43F5E';
    for (const bot of this.bots) {
      if (!bot.alive) continue;
      rCtx.beginPath();
      rCtx.arc((bot.x + 18) * sx, (bot.y + 27) * sy, 2.2, 0, Math.PI * 2);
      rCtx.fill();
    }
    for (const peer of this.peers) {
      if (peer.alive === false) continue;
      rCtx.beginPath();
      rCtx.arc((peer.x + 18) * sx, (peer.y + 27) * sy, 2.4, 0, Math.PI * 2);
      rCtx.fill();
    }

    // Local Player
    if (this.player.alive) {
      rCtx.fillStyle = '#38BDF8';
      rCtx.beginPath();
      rCtx.arc((this.player.x + 18) * sx, (this.player.y + 27) * sy, 2.7, 0, Math.PI * 2);
      rCtx.fill();
    }
  }
}
