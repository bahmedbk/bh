import { useRef, useState } from 'react';
import { ArrowLeftRight, Flame, RotateCw, Sword } from 'lucide-react';
import type { ArenaEngine } from '../engine/ArenaEngine';
import { getText } from '../i18n/translations';
import type { Language } from '../types/game';

interface DualStickControlsProps {
  engineRef: React.RefObject<ArenaEngine | null>;
  lang: Language;
  grenades: number;
  fuel: number;
}

const STICK_RADIUS = 48;

export function DualStickControls({ engineRef, lang, grenades, fuel }: DualStickControlsProps) {
  const t = getText(lang);

  const leftPadRef = useRef<HTMLDivElement>(null);
  const rightPadRef = useRef<HTMLDivElement>(null);
  const leftPointerId = useRef<number | null>(null);
  const rightPointerId = useRef<number | null>(null);

  const [leftNub, setLeftNub] = useState({ x: 0, y: 0 });
  const [rightNub, setRightNub] = useState({ x: 0, y: 0 });

  const updateLeftStick = (clientX: number, clientY: number) => {
    const pad = leftPadRef.current;
    const engine = engineRef.current;
    if (!pad || !engine) return;
    const rect = pad.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > STICK_RADIUS) {
      dx = (dx / dist) * STICK_RADIUS;
      dy = (dy / dist) * STICK_RADIUS;
    }
    setLeftNub({ x: dx, y: dy });

    const nx = dx / STICK_RADIUS;
    const ny = dy / STICK_RADIUS;
    engine.setTouchMove(nx, ny < -0.25);
  };

  const resetLeftStick = () => {
    leftPointerId.current = null;
    setLeftNub({ x: 0, y: 0 });
    engineRef.current?.setTouchMove(0, false);
  };

  const updateRightStick = (clientX: number, clientY: number) => {
    const pad = rightPadRef.current;
    const engine = engineRef.current;
    if (!pad || !engine) return;
    const rect = pad.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > STICK_RADIUS) {
      dx = (dx / dist) * STICK_RADIUS;
      dy = (dy / dist) * STICK_RADIUS;
    }
    setRightNub({ x: dx, y: dy });

    if (dist > 10) {
      const angle = Math.atan2(dy, dx);
      engine.setAimAngle(angle);
      engine.setFiring(dist > STICK_RADIUS * 0.38);
    } else {
      engine.setFiring(false);
    }
  };

  const resetRightStick = () => {
    rightPointerId.current = null;
    setRightNub({ x: 0, y: 0 });
    engineRef.current?.setFiring(false);
  };

  return (
    <div className="touch-control-zone pointer-events-none fixed inset-x-0 bottom-0 z-20 flex items-end justify-between px-4 pb-5 sm:px-8 sm:pb-7">
      {/* Left Stick: Move Left/Right + Push Up for Jetpack */}
      <div className="pointer-events-auto flex flex-col items-center gap-2">
        <div
          ref={leftPadRef}
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            leftPointerId.current = e.pointerId;
            updateLeftStick(e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (leftPointerId.current !== e.pointerId) return;
            updateLeftStick(e.clientX, e.clientY);
          }}
          onPointerUp={(e) => {
            if (leftPointerId.current === e.pointerId) resetLeftStick();
          }}
          onPointerCancel={(e) => {
            if (leftPointerId.current === e.pointerId) resetLeftStick();
          }}
          className="relative flex h-28 w-28 items-center justify-center rounded-full border-2 border-slate-600/70 bg-slate-950/65 shadow-xl"
        >
          <div className="pointer-events-none absolute top-1.5 text-[10px] font-bold text-sky-400">
            JET {Math.round(fuel)}%
          </div>
          <div
            className="h-12 w-12 rounded-full border border-sky-400/70 bg-slate-800/95 shadow-lg transition-transform duration-75"
            style={{ transform: `translate(${leftNub.x}px, ${leftNub.y}px)` }}
          />
        </div>
      </div>

      {/* Right Stick + Swap / Grenade / Reload / Katana Melee */}
      <div className="pointer-events-auto flex items-end gap-3">
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.switchWeaponSlot();
            }}
            aria-label={t.swapGunLabel}
            className="flex h-12 w-12 items-center justify-center rounded-xl border border-sky-500/60 bg-slate-950/80 text-sky-300 active:scale-95"
          >
            <ArrowLeftRight className="h-4 w-4" />
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.throwGrenade();
            }}
            className="flex h-12 w-12 flex-col items-center justify-center rounded-xl border border-amber-500/60 bg-slate-950/80 text-[10px] font-bold text-amber-300 active:scale-95"
          >
            <Flame className="h-4 w-4" />
            <span>{grenades}</span>
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.triggerReload();
            }}
            aria-label={t.touchReloadLabel}
            className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-600/80 bg-slate-950/80 text-slate-200 active:scale-95"
          >
            <RotateCw className="h-4 w-4" />
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.triggerMelee();
            }}
            aria-label={t.touchMeleeLabel}
            className="flex h-12 w-12 items-center justify-center rounded-xl border border-rose-500/60 bg-rose-950/75 text-rose-200 active:scale-95"
          >
            <Sword className="h-4 w-4" />
          </button>
        </div>

        {/* 360° Aim & Fire Joystick */}
        <div
          ref={rightPadRef}
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            rightPointerId.current = e.pointerId;
            updateRightStick(e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (rightPointerId.current !== e.pointerId) return;
            updateRightStick(e.clientX, e.clientY);
          }}
          onPointerUp={(e) => {
            if (rightPointerId.current === e.pointerId) resetRightStick();
          }}
          onPointerCancel={(e) => {
            if (rightPointerId.current === e.pointerId) resetRightStick();
          }}
          className="relative flex h-28 w-28 items-center justify-center rounded-full border-2 border-rose-500/65 bg-slate-950/65 shadow-xl"
        >
          <div className="pointer-events-none h-16 w-16 rounded-full border border-dashed border-rose-500/35" />
          <div
            className="absolute h-12 w-12 rounded-full border border-rose-400 bg-rose-600/85 shadow-lg transition-transform duration-75"
            style={{ transform: `translate(${rightNub.x}px, ${rightNub.y}px)` }}
          />
        </div>
      </div>
    </div>
  );
}
