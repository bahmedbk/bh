import { useEffect, useState } from 'react';
import { Check, Copy, Link2, Play, Swords, Users, X } from 'lucide-react';
import { STAGES } from '../data/gameCatalog';
import { getText } from '../i18n/translations';
import { multiplayerClient } from '../lib/multiplayerSocket';
import type { Language, MultiplayerRoomState, PlayerProfile } from '../types/game';

interface MultiplayerModalProps {
  profile: PlayerProfile;
  localPlayerId: string;
  lang: Language;
  room: MultiplayerRoomState | null;
  initialJoinCode?: string | null;
  onConsumeInitialJoinCode?: () => void;
  onRoomChange: (room: MultiplayerRoomState | null) => void;
  onMatchStart: (room: MultiplayerRoomState) => void;
  onClose: () => void;
}

export function MultiplayerModal({
  profile,
  localPlayerId,
  lang,
  room,
  initialJoinCode,
  onConsumeInitialJoinCode,
  onRoomChange,
  onMatchStart,
  onClose,
}: MultiplayerModalProps) {
  const t = getText(lang);
  const [joinCode, setJoinCode] = useState(initialJoinCode || '');
  const [selectedMode, setSelectedMode] = useState<'coop' | 'competitive' | 'arena'>('arena');
  const [selectedStage, setSelectedStage] = useState('1');
  const [copied, setCopied] = useState(false);
  const [inviteCopied, setInviteCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    multiplayerClient.connect();
    multiplayerClient.setHandlers({
      onRoomJoined: (_pid, joinedRoom) => {
        setErrorMsg(null);
        onRoomChange(joinedRoom);
      },
      onRoomState: (updatedRoom) => {
        onRoomChange(updatedRoom);
      },
      onMatchStarted: (startedRoom) => {
        onRoomChange(startedRoom);
        onMatchStart(startedRoom);
      },
      onError: (code) => {
        if (code === 'NOT_FOUND') setErrorMsg(t.roomNotFound);
        else if (code === 'ROOM_FULL') setErrorMsg(t.roomFull);
        else setErrorMsg(code);
      },
    });

    if (initialJoinCode && !room) {
      const code = initialJoinCode.trim().toUpperCase();
      if (code) {
        setJoinCode(code);
        multiplayerClient.joinRoom({
          code,
          playerId: localPlayerId,
          displayName: profile.displayName,
          weapon: profile.equippedWeapon,
          skin: profile.equippedSkin,
        });
      }
      onConsumeInitialJoinCode?.();
    }
  }, [lang, initialJoinCode]);

  const handleCreate = () => {
    setErrorMsg(null);
    multiplayerClient.createRoom({
      playerId: localPlayerId,
      displayName: profile.displayName,
      mode: selectedMode,
      stageId: selectedStage,
      weapon: profile.equippedWeapon,
      skin: profile.equippedSkin,
    });
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCode.trim()) return;
    setErrorMsg(null);
    multiplayerClient.joinRoom({
      code: joinCode.trim().toUpperCase(),
      playerId: localPlayerId,
      displayName: profile.displayName,
      weapon: profile.equippedWeapon,
      skin: profile.equippedSkin,
    });
  };

  const handleCopy = async () => {
    if (!room) return;
    try {
      await navigator.clipboard.writeText(room.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handleCopyInviteLink = async () => {
    if (!room) return;
    const inviteUrl = `${window.location.origin}/?room=${encodeURIComponent(room.code)}`;
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setInviteCopied(true);
      setTimeout(() => setInviteCopied(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handleLeave = () => {
    multiplayerClient.leaveRoom();
    onRoomChange(null);
  };

  const isHost = room?.hostId === localPlayerId;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-rose-400" />
            <h2 className="text-xl font-bold text-white">{t.roomTitle}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 space-y-6">
          {errorMsg && (
            <div className="rounded-xl border border-rose-800/60 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">
              {errorMsg}
            </div>
          )}

          {!room ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Create Room */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4">
                <h3 className="text-base font-bold text-white">{t.createRoom}</h3>

                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => setSelectedMode('arena')}
                    className={`flex min-h-[44px] w-full items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-semibold transition-colors ${
                      selectedMode === 'arena'
                        ? 'border-sky-500 bg-sky-600/20 text-white'
                        : 'border-slate-800 bg-slate-950/60 text-slate-400'
                    }`}
                  >
                    <Swords className="h-4 w-4 text-sky-400" />
                    <span>{t.arenaOnlineMode}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMode('coop')}
                    className={`flex min-h-[44px] w-full items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-semibold transition-colors ${
                      selectedMode === 'coop'
                        ? 'border-rose-500 bg-rose-600/20 text-white'
                        : 'border-slate-800 bg-slate-950/60 text-slate-400'
                    }`}
                  >
                    <Users className="h-4 w-4 text-rose-400" />
                    <span>{t.coopMode}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMode('competitive')}
                    className={`flex min-h-[44px] w-full items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-semibold transition-colors ${
                      selectedMode === 'competitive'
                        ? 'border-amber-500 bg-amber-600/20 text-white'
                        : 'border-slate-800 bg-slate-950/60 text-slate-400'
                    }`}
                  >
                    <Swords className="h-4 w-4 text-amber-400" />
                    <span>{t.competitiveMode}</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">{t.selectStage}</label>
                  <select
                    value={selectedStage}
                    onChange={(e) => setSelectedStage(e.target.value)}
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-sm text-white"
                  >
                    {STAGES.map((st) => (
                      <option key={st.id} value={st.id}>
                        {lang === 'ar' ? st.titleAr : st.titleEn}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleCreate}
                  className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
                >
                  <span>{t.createRoom}</span>
                </button>
              </div>

              {/* Join Room */}
              <form
                onSubmit={handleJoin}
                className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4"
              >
                <div className="space-y-3">
                  <h3 className="text-base font-bold text-white">{t.joinRoom}</h3>
                  <input
                    type="text"
                    maxLength={8}
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    placeholder={t.enterCode}
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-950 px-3.5 text-center font-mono-num text-lg font-bold tracking-widest text-white placeholder:text-xs placeholder:tracking-normal placeholder:font-sans placeholder:text-slate-500"
                  />
                </div>
                <button
                  type="submit"
                  className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-700 transition-colors"
                >
                  <span>{t.joinBtn}</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Room Code & Direct Invite Link Banner */}
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950/70 p-4">
                <div>
                  <div className="text-xs text-slate-400">{t.roomCodeLabel}</div>
                  <div className="font-mono-num text-2xl font-bold tracking-widest text-amber-300">
                    {room.code}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="flex min-h-[42px] items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 transition-colors"
                  >
                    {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                    <span>{copied ? t.copied : t.copyCode}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyInviteLink}
                    className="flex min-h-[42px] items-center gap-2 rounded-xl border border-sky-500/60 bg-sky-950/50 px-3.5 py-2 text-xs font-semibold text-sky-200 hover:bg-sky-900/60 transition-colors"
                  >
                    {inviteCopied ? (
                      <Check className="h-4 w-4 text-emerald-400" />
                    ) : (
                      <Link2 className="h-4 w-4 text-sky-400" />
                    )}
                    <span>{inviteCopied ? t.inviteLinkCopied : t.copyInviteLink}</span>
                  </button>
                </div>
              </div>

              {/* Host Controls */}
              {isHost && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    value={room.mode}
                    onChange={(e) => {
                      const val = e.target.value;
                      const mode: 'coop' | 'competitive' | 'arena' =
                        val === 'arena' ? 'arena' : val === 'competitive' ? 'competitive' : 'coop';
                      multiplayerClient.updateRoomSettings(mode, room.stageId);
                    }}
                    className="min-h-[44px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-sm text-white"
                  >
                    <option value="arena">{t.arenaOnlineMode}</option>
                    <option value="coop">{t.coopMode}</option>
                    <option value="competitive">{t.competitiveMode}</option>
                  </select>
                  <select
                    value={room.stageId}
                    onChange={(e) =>
                      multiplayerClient.updateRoomSettings(room.mode, e.target.value)
                    }
                    className="min-h-[44px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-sm text-white"
                  >
                    {STAGES.map((st) => (
                      <option key={st.id} value={st.id}>
                        {lang === 'ar' ? st.titleAr : st.titleEn}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Connected Players */}
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-2">
                  {t.playersInRoom} ({room.players.length}/4)
                </div>
                <div className="space-y-2">
                  {room.players.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/50 px-4 py-3 text-sm"
                    >
                      <span className="font-semibold text-white">{p.displayName}</span>
                      <span className="text-xs text-slate-400">
                        {p.id === room.hostId ? t.hostTag : p.weapon}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3">
                {isHost ? (
                  <button
                    type="button"
                    onClick={() => multiplayerClient.startMatch()}
                    className="flex-1 flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-rose-600 px-5 py-3 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
                  >
                    <Play className="h-4 w-4" />
                    <span>{t.startMatch}</span>
                  </button>
                ) : (
                  <div className="flex-1 flex min-h-[48px] items-center justify-center rounded-xl border border-slate-800 bg-slate-900/60 px-4 text-sm text-slate-300">
                    {t.waitingHost}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleLeave}
                  className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-700 px-5 py-3 text-sm font-semibold text-slate-300 hover:text-white transition-colors"
                >
                  {t.leaveRoom}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
