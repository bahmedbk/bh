import { useState } from 'react';
import { LogIn, ShieldCheck, UserCheck, X } from 'lucide-react';
import { getText } from '../i18n/translations';
import type { Language } from '../types/game';

interface ProfileSetupModalProps {
  mode: 'login_gate' | 'profile_name';
  lang: Language;
  initialName: string;
  allowClose?: boolean;
  onGoogleSignIn: () => Promise<void>;
  onSaveProfileName: (name: string) => Promise<void>;
  onClose?: () => void;
}

export function ProfileSetupModal({
  mode,
  lang,
  initialName,
  allowClose = false,
  onGoogleSignIn,
  onSaveProfileName,
  onClose,
}: ProfileSetupModalProps) {
  const t = getText(lang);
  const [name, setName] = useState(initialName);
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGoogleClick = async () => {
    setBusy(true);
    setErrorMsg(null);
    try {
      await onGoogleSignIn();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Sign-in failed');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim().slice(0, 40);
    if (!trimmed) {
      setErrorMsg(lang === 'ar' ? 'يرجى كتابة اسم للملف الشخصي' : 'Please enter a warrior name');
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    try {
      await onSaveProfileName(trimmed);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save profile');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 p-4">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-[#0D1320] p-6 sm:p-8 shadow-2xl">
        {allowClose && onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="absolute top-4 end-4 flex h-10 w-10 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        )}

        {mode === 'login_gate' ? (
          <div className="space-y-5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-500/15 text-sky-400">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{t.trialGateTitle}</h2>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed">{t.trialGateDesc}</p>
            </div>

            {errorMsg && (
              <div className="rounded-xl border border-rose-800/60 bg-rose-950/30 px-3.5 py-2.5 text-xs text-rose-200">
                {errorMsg}
              </div>
            )}

            <div className="flex flex-col gap-3 pt-1">
              <button
                type="button"
                disabled={busy}
                onClick={handleGoogleClick}
                className="flex min-h-[48px] w-full items-center justify-center gap-2.5 rounded-xl bg-rose-600 px-5 py-3 text-sm font-bold text-white hover:bg-rose-500 disabled:opacity-60 transition-colors"
              >
                <LogIn className="h-4 w-4" />
                <span>{t.signInGoogle}</span>
              </button>

              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-slate-800 px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
                >
                  {t.returnTitle}
                </button>
              )}
            </div>
          </div>
        ) : (
          <form onSubmit={handleSaveName} className="space-y-5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <UserCheck className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{t.profileSetupTitle}</h2>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed">{t.profileSetupDesc}</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.profileNameLabel}
              </label>
              <input
                type="text"
                required
                maxLength={40}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.profileNamePlaceholder}
                className="w-full min-h-[46px] rounded-xl border border-slate-700 bg-slate-950 px-4 text-sm font-semibold text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
              />
            </div>

            {errorMsg && (
              <div className="rounded-xl border border-rose-800/60 bg-rose-950/30 px-3.5 py-2.5 text-xs text-rose-200">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-rose-600 px-5 py-3 text-sm font-bold text-white hover:bg-rose-500 disabled:opacity-60 transition-colors"
            >
              <span>{t.saveAndContinue}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
