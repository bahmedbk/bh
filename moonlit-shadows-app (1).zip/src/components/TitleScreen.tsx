import { useEffect, useState } from 'react';
import { Check, Gem, LogIn, LogOut, Share2, User } from 'lucide-react';
import titleBgUrl from '../assets/images/title_moonlit_ninja_1794529270140.jpg';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import type { ActiveModal, Language, PlayerProfile } from '../types/game';
import { getTodayUtcKey } from './DailyRewardsModal';
import {
  ArenaTargetIcon,
  ArmoryForgeIcon,
  BladeSlashIcon,
  CoopBladesIcon,
  EclipseMoonIcon,
  PagodaStagesIcon,
  RewardChestIcon,
  SettingsGearIcon,
  ShogunCrownIcon,
} from './GameIcons';

interface TitleScreenProps {
  profile: PlayerProfile;
  lang: Language;
  isSignedIn: boolean;
  onGoogleSignIn: () => void;
  onSignOut: () => void;
  onEditProfile: () => void;
  onStartQuickPlay: () => void;
  onStartArena: () => void;
  onOpenModal: (modal: ActiveModal) => void;
}

export function TitleScreen({
  profile,
  lang,
  isSignedIn,
  onGoogleSignIn,
  onSignOut,
  onEditProfile,
  onStartQuickPlay,
  onStartArena,
  onOpenModal,
}: TitleScreenProps) {
  const t = getText(lang);
  const [imgError, setImgError] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const handleShareGame = async () => {
    soundEngine.playUiClick();
    const publicOrigin = window.location.origin;
    if (navigator.share) {
      try {
        await navigator.share({
          title: t.gameTitle,
          url: publicOrigin,
        });
        return;
      } catch {
        // Fallback to clipboard copy
      }
    }
    try {
      await navigator.clipboard.writeText(publicOrigin);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
      // Clipboard blocked fallback
    }
  };

  const dailyAvailable = profile.lastDailyClaimDay !== getTodayUtcKey();

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        const activeTag = document.activeElement?.tagName;
        if (activeTag === 'INPUT' || activeTag === 'SELECT' || activeTag === 'BUTTON') return;
        e.preventDefault();
        onStartQuickPlay();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onStartQuickPlay]);

  return (
    <div className="relative flex h-full w-full flex-col justify-between overflow-y-auto overflow-x-hidden bg-[#090D16]">
      {/* Key-Art Backdrop */}
      <div className="pointer-events-none absolute inset-0 z-0">
        {!imgError ? (
          <img
            src={titleBgUrl}
            alt={t.gameTitle}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover object-center opacity-80"
          />
        ) : (
          <div className="h-full w-full bg-[radial-gradient(circle_at_65%_25%,rgba(226,232,240,0.16),transparent_45%),linear-gradient(180deg,#090D16_0%,#141E33_100%)]" />
        )}
        <div
          className={`absolute inset-0 ${
            lang === 'ar'
              ? 'bg-gradient-to-l from-[#090D16]/95 via-[#090D16]/70 to-[#090D16]/35'
              : 'bg-gradient-to-r from-[#090D16]/95 via-[#090D16]/70 to-[#090D16]/35'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090D16] via-transparent to-[#090D16]/70" />
      </div>

      {/* Top Bar: Player Info + Account + Dedicated Settings Icon */}
      <header className="relative z-10 flex items-center justify-between gap-4 px-5 py-4 sm:px-8 sm:py-5">
        <div className="flex items-center gap-3 text-xs sm:text-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/90 bg-slate-950/90 font-bold text-rose-400 font-mono-num">
            {profile.level}
          </div>
          <div className="flex items-center gap-2.5">
            <span className="font-bold text-white whitespace-nowrap">{profile.displayName}</span>
            <span className="text-slate-600" aria-hidden="true">·</span>
            <span className="flex items-center gap-1 font-bold text-sky-400 font-mono-num">
              <Gem className="h-3.5 w-3.5" />
              <span>{profile.gems}</span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isSignedIn ? (
            <>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playUiClick();
                  onEditProfile();
                }}
                aria-label={t.editProfile}
                className="flex min-h-[42px] items-center gap-1.5 rounded-xl border border-slate-700/80 bg-slate-950/80 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 transition-colors whitespace-nowrap"
              >
                <User className="h-3.5 w-3.5 text-slate-400" />
                <span>{t.editProfile}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playUiClick();
                  onSignOut();
                }}
                aria-label={t.signOut}
                className="flex h-[42px] w-[42px] items-center justify-center rounded-xl border border-slate-700/80 bg-slate-950/80 text-slate-300 hover:border-slate-500 hover:text-white transition-colors"
                title={t.signOut}
              >
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onGoogleSignIn();
              }}
              className="flex min-h-[42px] items-center gap-2 rounded-xl border border-slate-700 bg-slate-950/85 px-4 py-2 text-xs font-bold text-white hover:border-rose-500/60 transition-colors whitespace-nowrap"
            >
              <LogIn className="h-3.5 w-3.5 text-rose-400" />
              <span>{t.signInGoogle}</span>
            </button>
          )}

          {/* Share Public Link */}
          <button
            type="button"
            onClick={handleShareGame}
            aria-label={t.shareGameLink}
            title={t.shareGameLink}
            className="flex min-h-[42px] items-center gap-1.5 rounded-xl border border-slate-700/90 bg-slate-950/85 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-sky-500/70 hover:text-white transition-colors whitespace-nowrap"
          >
            {linkCopied ? (
              <Check className="h-4 w-4 text-emerald-400" />
            ) : (
              <Share2 className="h-4 w-4 text-sky-400" />
            )}
            <span className="hidden sm:inline">{linkCopied ? t.linkCopied : t.shareGameLink}</span>
          </button>

          {/* Dedicated Game Settings Icon (Replaces standalone audio icon) */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playUiClick();
              onOpenModal('settings');
            }}
            aria-label={t.settingsTitle}
            title={t.settingsTitle}
            className="flex h-[42px] w-[42px] items-center justify-center rounded-xl border border-slate-700/90 bg-slate-950/85 text-slate-200 hover:border-rose-500/70 hover:text-white transition-colors"
          >
            <SettingsGearIcon className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Main Title & Game Actions */}
      <main className="relative z-10 mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center px-5 py-6 sm:px-8">
        <div className="max-w-lg space-y-6">
          <div className="space-y-2.5">
            <div className="flex items-center gap-3">
              <svg
                width="44"
                height="44"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                className="shrink-0"
              >
                <circle cx="24" cy="24" r="21" stroke="#E2E8F0" strokeOpacity="0.25" strokeWidth="1.5" />
                <path
                  d="M28.5 9.5C21.2 10.6 15.5 16.9 15.5 24.5C15.5 32.1 21.2 38.4 28.5 39.5C22.4 39.9 12 34.4 12 24.5C12 14.6 22.4 9.1 28.5 9.5Z"
                  fill="#E2E8F0"
                />
                <path
                  d="M14 34L35 13M35 13L30 13.5M35 13L34.5 18"
                  stroke="#E11D48"
                  strokeWidth="2.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="font-display-en text-xs tracking-[0.22em] text-rose-400 uppercase font-semibold">
                {t.gameSubtitle}
              </span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight [text-wrap:balance]">
              {t.gameTitle}
            </h1>
          </div>

          {/* Primary Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onStartQuickPlay();
              }}
              className="flex min-h-[52px] items-center justify-center gap-3 rounded-xl bg-rose-600 px-8 py-3.5 text-base font-bold text-white shadow-lg shadow-rose-950/50 hover:bg-rose-500 active:scale-[0.98] transition-all whitespace-nowrap"
            >
              <BladeSlashIcon className="h-5 w-5" />
              <span>
                {profile.highestStage > 1
                  ? `${t.continueChapter} ${profile.highestStage}`
                  : t.startCampaign}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onStartArena();
              }}
              className="flex min-h-[52px] items-center justify-center gap-2.5 rounded-xl border border-sky-500/60 bg-sky-950/50 px-6 py-3.5 text-sm font-bold text-sky-100 hover:border-sky-400 hover:bg-sky-900/60 transition-colors whitespace-nowrap"
            >
              <ArenaTargetIcon className="h-5 w-5 text-sky-400" />
              <span>{t.arenaMode}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('multiplayer');
              }}
              className="flex min-h-[52px] items-center justify-center gap-2.5 rounded-xl border border-slate-700 bg-slate-900/90 px-6 py-3.5 text-sm font-bold text-white hover:border-slate-500 hover:bg-slate-800 transition-colors whitespace-nowrap"
            >
              <CoopBladesIcon className="h-5 w-5 text-amber-400" />
              <span>{t.multiplayer}</span>
            </button>
          </div>

          {/* Modern Game-Engine Icon Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('stages');
              }}
              className="flex min-h-[48px] items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-200 hover:border-slate-600 hover:text-white transition-colors whitespace-nowrap"
            >
              <PagodaStagesIcon className="h-5 w-5 text-slate-300 shrink-0" />
              <span className="truncate">{t.chapters}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('shop');
              }}
              className="flex min-h-[48px] items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-200 hover:border-amber-500/50 hover:text-white transition-colors whitespace-nowrap"
            >
              <ArmoryForgeIcon className="h-5 w-5 text-amber-400 shrink-0" />
              <span className="truncate">{t.dojoShop}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('leaderboard');
              }}
              className="flex min-h-[48px] items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-200 hover:border-amber-400/50 hover:text-white transition-colors whitespace-nowrap"
            >
              <ShogunCrownIcon className="h-5 w-5 text-amber-300 shrink-0" />
              <span className="truncate">{t.leaderboard}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('daily');
              }}
              className={`flex min-h-[48px] items-center gap-3 rounded-xl border px-4 py-2.5 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                dailyAvailable
                  ? 'border-amber-500/60 bg-amber-950/40 text-amber-200 hover:border-amber-400'
                  : 'border-slate-800 bg-slate-950/80 text-slate-200 hover:border-slate-600'
              }`}
            >
              <RewardChestIcon className="h-5 w-5 text-amber-400 shrink-0" />
              <span className="truncate">{t.dailyRewards}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playUiClick();
                onOpenModal('seasonal');
              }}
              className="flex min-h-[48px] items-center gap-3 rounded-xl border border-rose-900/50 bg-rose-950/30 px-4 py-2.5 text-xs sm:text-sm font-semibold text-rose-200 hover:border-rose-500/70 transition-colors whitespace-nowrap col-span-2 sm:col-span-2"
            >
              <EclipseMoonIcon className="h-5 w-5 text-rose-400 shrink-0" />
              <span className="truncate">{t.seasonalEvents}</span>
            </button>
          </div>
        </div>
      </main>

      {/* Compact Control Key Strip */}
      <footer className="relative z-10 px-5 py-3 sm:px-8 sm:py-4 text-center sm:text-start">
        <p className="text-[11px] sm:text-xs text-slate-500 font-medium">{t.controlHint}</p>
      </footer>
    </div>
  );
}
