import { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Gem,
  LogOut,
  Pause,
  Play,
  RotateCcw,
  Skull,
  Smartphone,
  Sparkles,
  Sword,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { getStageById, SEASONAL_STAGE_CONFIG, STAGES, WEAPONS } from '../data/gameCatalog';
import { soundEngine } from '../engine/audio';
import { type CombatImpactEvent, NinjaEngine } from '../engine/NinjaEngine';
import { getText } from '../i18n/translations';
import { multiplayerClient } from '../lib/multiplayerSocket';
import type {
  EffectsQuality,
  GameScreenState,
  HudSnapshot,
  Language,
  MatchResult,
  MultiplayerRoomState,
  PlayerProfile,
  RoomPlayer,
  SeasonalEvent,
  TouchDisplayMode,
  WeaponId,
} from '../types/game';
import { TouchControls } from './TouchControls';

interface GameCanvasProps {
  profile: PlayerProfile;
  stageId: string;
  lang: Language;
  seasonalEvent: SeasonalEvent;
  multiplayerRoom: MultiplayerRoomState | null;
  localPlayerId: string;
  isSignedIn: boolean;
  touchMode: TouchDisplayMode;
  effectsQuality: EffectsQuality;
  onWeaponChanged: (weaponId: WeaponId) => void;
  onTrialGateReached: () => void;
  onStageComplete: (result: MatchResult) => void;
  onExitToTitle: () => void;
  onSelectStage: (nextStageId: string) => void;
}

interface ScreenSpark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
}

interface ScreenClashFlare {
  x: number;
  y: number;
  angle: number;
  scale: number;
  color: string;
  accent: string;
  life: number;
  maxLife: number;
  isSlashOnly: boolean;
}

export function GameCanvas({
  profile,
  stageId,
  lang,
  seasonalEvent,
  multiplayerRoom,
  localPlayerId,
  isSignedIn,
  touchMode,
  effectsQuality,
  onWeaponChanged,
  onTrialGateReached,
  onStageComplete,
  onExitToTitle,
  onSelectStage,
}: GameCanvasProps) {
  const t = getText(lang);
  const stage = getStageById(stageId);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fxCanvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<NinjaEngine | null>(null);
  const peersMapRef = useRef<Map<string, RoomPlayer>>(new Map());
  const effectsQualityRef = useRef<EffectsQuality>(effectsQuality);
  effectsQualityRef.current = effectsQuality;
  const fxStateRef = useRef<{
    sparks: ScreenSpark[];
    flares: ScreenClashFlare[];
    rafId: number | null;
    lastMs: number;
    hasActiveFrame: boolean;
  }>({
    sparks: [],
    flares: [],
    rafId: null,
    lastMs: 0,
    hasActiveFrame: false,
  });

  const [showBriefing, setShowBriefing] = useState(!multiplayerRoom);
  const [gameState, setGameState] = useState<GameScreenState>('PLAYING');
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [mpWinnerName, setMpWinnerName] = useState<string | null>(null);
  const [clashPulse, setClashPulse] = useState(false);
  const [muted, setMuted] = useState(soundEngine.isMuted());
  const [touchVisible, setTouchVisible] = useState(() => {
    if (touchMode === 'on') return true;
    if (touchMode === 'off') return false;
    return typeof window !== 'undefined'
      ? window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 900
      : false;
  });
  const [runSeed, setRunSeed] = useState(0);

  const [hud, setHud] = useState<HudSnapshot>({
    hp: 100 + profile.skillHealth * 15,
    maxHp: 100 + profile.skillHealth * 15,
    dashCharge: 1,
    specialCharge: 1,
    combo: 0,
    gemsCollected: 0,
    xpCollected: 0,
    score: 0,
    progress: 0,
    bossActive: false,
    bossNameAr: stage.bossNameAr,
    bossNameEn: stage.bossNameEn,
    bossHp: 1,
    bossMaxHp: 1,
    elapsedSec: 0,
    equippedWeapon: profile.equippedWeapon,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    const fxCanvas = fxCanvasRef.current;
    const container = containerRef.current;
    if (!canvas || !fxCanvas || !container) return;

    const updateSize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      canvas.width = w;
      canvas.height = h;
      fxCanvas.width = w;
      fxCanvas.height = h;
    };
    updateSize();

    const resizeObserver = new ResizeObserver(updateSize);
    resizeObserver.observe(container);

    let pulseTimeout: ReturnType<typeof setTimeout> | null = null;
    const triggerCombatFx = (evt: CombatImpactEvent) => {
      const fx = fxStateRef.current;
      const isClash = evt.kind !== 'slash';
      const qualityScale = effectsQualityRef.current === 'balanced' ? 0.45 : 1;
      const sparkCount = isClash
        ? Math.max(4, Math.round(18 * evt.intensity * qualityScale))
        : Math.max(2, Math.round(7 * evt.intensity * qualityScale));
      const palette = isClash
        ? ['#FFFFFF', '#FEF08A', '#F97316', evt.accent]
        : ['#FFFFFF', evt.color, evt.accent];

      for (let i = 0; i < sparkCount; i++) {
        const baseAngle = isClash
          ? (Math.PI * 2 * i) / sparkCount + (Math.random() - 0.5) * 0.4
          : (evt.facing > 0 ? 0 : Math.PI) + (Math.random() - 0.5) * 1.4;
        const speed = (isClash ? 260 + Math.random() * 420 : 180 + Math.random() * 240) * evt.intensity;
        const maxLife = isClash ? 0.22 + Math.random() * 0.24 : 0.14 + Math.random() * 0.12;
        fx.sparks.push({
          x: evt.screenX,
          y: evt.screenY,
          vx: Math.cos(baseAngle) * speed,
          vy: Math.sin(baseAngle) * speed - (isClash ? 85 : 20),
          size: isClash ? 2.2 + Math.random() * 2.4 : 1.5 + Math.random() * 1.6,
          color: palette[i % palette.length],
          life: maxLife,
          maxLife,
        });
      }

      fx.flares.push({
        x: evt.screenX,
        y: evt.screenY,
        angle: (Math.random() - 0.5) * 0.8 + (evt.facing < 0 ? Math.PI : 0),
        scale: evt.intensity,
        color: evt.color,
        accent: evt.accent,
        life: isClash ? 0.18 : 0.11,
        maxLife: isClash ? 0.18 : 0.11,
        isSlashOnly: !isClash,
      });

      if (isClash) {
        setClashPulse(true);
        if (pulseTimeout) clearTimeout(pulseTimeout);
        pulseTimeout = setTimeout(() => setClashPulse(false), 160);
      }
    };

    const fxCtx = fxCanvas.getContext('2d');
    const renderFxFrame = (now: number) => {
      const fx = fxStateRef.current;
      const dt = fx.lastMs ? Math.min(0.05, (now - fx.lastMs) / 1000) : 0.016;
      fx.lastMs = now;

      if (fxCtx && (fx.sparks.length > 0 || fx.flares.length > 0 || fx.hasActiveFrame)) {
        fxCtx.clearRect(0, 0, fxCanvas.width, fxCanvas.height);
        fx.hasActiveFrame = fx.sparks.length > 0 || fx.flares.length > 0;

        if (fx.hasActiveFrame) {
          fxCtx.save();
          fxCtx.globalCompositeOperation = 'lighter';

          for (let i = fx.flares.length - 1; i >= 0; i--) {
            const fl = fx.flares[i];
            fl.life -= dt;
            if (fl.life <= 0) {
              fx.flares.splice(i, 1);
              continue;
            }
            const alpha = fl.life / fl.maxLife;
            const prog = 1 - alpha;
            fxCtx.save();
            fxCtx.globalAlpha = alpha;
            fxCtx.translate(fl.x, fl.y);
            fxCtx.rotate(fl.angle);

            if (!fl.isSlashOnly) {
              // Radial sword-clash glow & shock ring
              const grad = fxCtx.createRadialGradient(0, 0, 2, 0, 0, 46 * fl.scale);
              grad.addColorStop(0, 'rgba(255,255,255,0.9)');
              grad.addColorStop(0.35, fl.accent);
              grad.addColorStop(1, 'rgba(0,0,0,0)');
              fxCtx.fillStyle = grad;
              fxCtx.beginPath();
              fxCtx.arc(0, 0, 46 * fl.scale, 0, Math.PI * 2);
              fxCtx.fill();

              fxCtx.strokeStyle = fl.accent;
              fxCtx.lineWidth = 2.5 * alpha;
              fxCtx.beginPath();
              fxCtx.arc(0, 0, (12 + prog * 46) * fl.scale, 0, Math.PI * 2);
              fxCtx.stroke();

              // Sharp katana X-clash flare beams
              const arm = (34 + prog * 24) * fl.scale;
              fxCtx.fillStyle = '#FFFFFF';
              for (const rot of [0.42, -0.42, 1.98, -1.18]) {
                fxCtx.save();
                fxCtx.rotate(rot);
                fxCtx.beginPath();
                fxCtx.moveTo(-arm, 0);
                fxCtx.lineTo(0, -2.4 * alpha * fl.scale);
                fxCtx.lineTo(arm, 0);
                fxCtx.lineTo(0, 2.4 * alpha * fl.scale);
                fxCtx.closePath();
                fxCtx.fill();
                fxCtx.restore();
              }
            } else {
              // Fast kinetic wind-cut streak on sword swing
              const len = (24 + prog * 26) * fl.scale;
              fxCtx.strokeStyle = '#FFFFFF';
              fxCtx.lineWidth = 2 * alpha;
              fxCtx.beginPath();
              fxCtx.moveTo(-len * 0.4, -8);
              fxCtx.lineTo(len, 6);
              fxCtx.stroke();
            }
            fxCtx.restore();
          }

          for (let i = fx.sparks.length - 1; i >= 0; i--) {
            const sp = fx.sparks[i];
            sp.vx *= Math.pow(0.28, dt);
            sp.vy += 680 * dt;
            sp.x += sp.vx * dt;
            sp.y += sp.vy * dt;
            sp.life -= dt;
            if (sp.life <= 0) {
              fx.sparks.splice(i, 1);
              continue;
            }
            const alpha = sp.life / sp.maxLife;
            const speed = Math.hypot(sp.vx, sp.vy);
            const ang = Math.atan2(sp.vy, sp.vx);
            const tail = Math.max(7, Math.min(30, speed * 0.048));

            fxCtx.save();
            fxCtx.globalAlpha = alpha;
            fxCtx.translate(sp.x, sp.y);
            fxCtx.rotate(ang);
            fxCtx.strokeStyle = sp.color;
            fxCtx.lineWidth = Math.max(1.2, sp.size * alpha);
            fxCtx.lineCap = 'round';
            fxCtx.beginPath();
            fxCtx.moveTo(-tail, 0);
            fxCtx.lineTo(2, 0);
            fxCtx.stroke();

            fxCtx.fillStyle = '#FFFFFF';
            fxCtx.beginPath();
            fxCtx.arc(1.5, 0, Math.max(0.9, sp.size * 0.42), 0, Math.PI * 2);
            fxCtx.fill();
            fxCtx.restore();
          }

          fxCtx.restore();
        }
      }

      fx.rafId = requestAnimationFrame(renderFxFrame);
    };

    fxStateRef.current.rafId = requestAnimationFrame(renderFxFrame);

    const mpMode: 'solo' | 'coop' | 'competitive' =
      multiplayerRoom && multiplayerRoom.mode !== 'arena' ? multiplayerRoom.mode : 'solo';
    const engine = new NinjaEngine(
      canvas,
      profile,
      stageId,
      {
        onHudUpdate: (snap) => setHud(snap),
        onWeaponChanged: (wid) => onWeaponChanged(wid),
        onCombatImpact: triggerCombatFx,
        onTrialGateReached: () => {
          setGameState('PAUSED');
          onTrialGateReached();
        },
        onVictory: (res) => {
          setMatchResult(res);
          setGameState('VICTORY');
          if (multiplayerRoom && multiplayerRoom.mode === 'competitive') {
            multiplayerClient.sendStageFinished(res.score);
          }
          onStageComplete(res);
        },
        onGameOver: (res) => {
          setMatchResult(res);
          setGameState('GAME_OVER');
          if (res.gemsEarned > 0 || res.xpEarned > 0) {
            onStageComplete(res);
          }
        },
        onLocalStateSync: multiplayerRoom
          ? (sync) => {
              multiplayerClient.sendPlayerState({
                ...sync,
                weapon: hud.equippedWeapon,
                skin: profile.equippedSkin,
              });
            }
          : undefined,
        onBossDamageSync:
          multiplayerRoom && multiplayerRoom.mode === 'coop'
            ? (dmg) => multiplayerClient.sendBossDamage(dmg)
            : undefined,
        onPvpSlashSync:
          multiplayerRoom && multiplayerRoom.mode === 'competitive'
            ? (targetId, dmg) => multiplayerClient.sendPvpSlash(targetId, dmg)
            : undefined,
      },
      {
        seasonalEvent,
        multiplayerMode: mpMode,
        externalBossMaxHp: multiplayerRoom?.bossMaxHp,
        trialLimitSec: null,
      }
    );

    engineRef.current = engine;
    engine.setPaused(showBriefing);
    engine.start();

    if (multiplayerRoom) {
      multiplayerClient.setHandlers({
        onPeerState: (peer) => {
          if (peer.id !== localPlayerId) {
            peersMapRef.current.set(peer.id, peer);
            engine.setPeers(Array.from(peersMapRef.current.values()));
          }
        },
        onBossSync: (bossHp) => {
          engine.setExternalBossHp(bossHp);
        },
        onPvpHit: (targetId, damage) => {
          if (targetId === localPlayerId) {
            engine.applyExternalDamage(damage);
          }
        },
        onMatchVictory: (payload) => {
          const winner = payload.room.players.find((p) => p.id === payload.winnerId);
          setMpWinnerName(winner?.displayName || null);
        },
      });
    }

    return () => {
      resizeObserver.disconnect();
      if (pulseTimeout) clearTimeout(pulseTimeout);
      if (fxStateRef.current.rafId !== null) {
        cancelAnimationFrame(fxStateRef.current.rafId);
        fxStateRef.current.rafId = null;
      }
      fxStateRef.current.sparks = [];
      fxStateRef.current.flares = [];
      engine.stop();
      engineRef.current = null;
      peersMapRef.current.clear();
    };
  }, [stageId, runSeed, multiplayerRoom?.code]);

  // Clear guest trial limit immediately once user signs in!
  useEffect(() => {
    if (isSignedIn && engineRef.current) {
      engineRef.current.clearTrialLimit();
      if (gameState === 'PAUSED' && !showBriefing) {
        setGameState('PLAYING');
      }
    }
  }, [isSignedIn]);

  useEffect(() => {
    const isPlaying = !showBriefing && gameState === 'PLAYING';
    if (engineRef.current) {
      engineRef.current.setPaused(!isPlaying);
    }
    if (isPlaying) {
      soundEngine.startBattleMusic();
    } else {
      soundEngine.stopBattleMusic();
    }
  }, [showBriefing, gameState]);

  useEffect(() => {
    return () => {
      soundEngine.stopBattleMusic();
    };
  }, []);

  useEffect(() => {
    const held = { left: false, right: false };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showBriefing) return;
        setGameState((prev) =>
          prev === 'PLAYING' ? 'PAUSED' : prev === 'PAUSED' ? 'PLAYING' : prev
        );
        return;
      }

      const engine = engineRef.current;
      if (!engine || showBriefing || gameState !== 'PLAYING') return;

      const code = e.code;
      if (code === 'ArrowLeft' || code === 'KeyA') {
        held.left = true;
        engine.setInput({ left: true });
      } else if (code === 'ArrowRight' || code === 'KeyD') {
        held.right = true;
        engine.setInput({ right: true });
      } else if (code === 'Space' || code === 'ArrowUp' || code === 'KeyW') {
        if (!e.repeat) {
          e.preventDefault();
          engine.triggerJump();
        }
      } else if (code === 'ShiftLeft' || code === 'ShiftRight' || code === 'KeyK' || code === 'KeyL') {
        if (!e.repeat) engine.triggerDash();
      } else if (code === 'KeyJ' || code === 'KeyZ' || code === 'Enter') {
        if (!e.repeat) engine.triggerAttack();
      } else if (code === 'KeyQ' || code === 'KeyE' || code === 'KeyX') {
        if (!e.repeat) engine.triggerSpecial();
      } else if (code === 'KeyR' || code === 'Tab') {
        e.preventDefault();
        if (!e.repeat) engine.cycleWeapon();
      } else if (['Digit1', 'Digit2', 'Digit3', 'Digit4'].includes(code)) {
        const idx = Number(code.replace('Digit', '')) - 1;
        const targetWeapon = WEAPONS[idx];
        if (targetWeapon && profile.unlockedWeapons.includes(targetWeapon.id)) {
          engine.setWeapon(targetWeapon.id);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const engine = engineRef.current;
      if (!engine) return;
      const code = e.code;
      if (code === 'ArrowLeft' || code === 'KeyA') {
        held.left = false;
        engine.setInput({ left: false });
      } else if (code === 'ArrowRight' || code === 'KeyD') {
        held.right = false;
        engine.setInput({ right: false });
      } else if (code === 'Space' || code === 'ArrowUp' || code === 'KeyW') {
        engine.releaseJump();
      }
    };

    const handleBlur = () => {
      held.left = false;
      held.right = false;
      engineRef.current?.setInput({ left: false, right: false, jumpHeld: false });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
    };
  }, [showBriefing, gameState, profile.unlockedWeapons]);

  const toggleMute = () => {
    const next = !muted;
    soundEngine.setMuted(next);
    setMuted(next);
  };

  const handleRestart = () => {
    setMatchResult(null);
    setMpWinnerName(null);
    setGameState('PLAYING');
    setRunSeed((s) => s + 1);
  };

  const nextStageObj = STAGES.find((s) => s.order === stage.order + 1);
  const currentWeaponObj = WEAPONS.find((w) => w.id === hud.equippedWeapon) || WEAPONS[0];

  return (
    <div ref={containerRef} className="relative h-full w-full overflow-hidden bg-[#090D16]">
      <canvas ref={canvasRef} className="block h-full w-full" />
      <canvas
        ref={fxCanvasRef}
        className="pointer-events-none absolute inset-0 z-[5] block h-full w-full"
      />

      {/* Minimal Perimeter HUD */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-wrap items-start justify-between gap-3 p-3 sm:p-5">
        <div className="flex flex-col gap-2 bg-slate-950/75 border border-slate-800/80 rounded-xl px-3.5 py-2.5 min-w-[215px]">
          <div className="flex items-center justify-between gap-4 text-xs font-semibold">
            <span className="text-slate-200">{t.hp}</span>
            <span className="font-mono-num text-rose-300">
              {hud.hp}/{hud.maxHp}
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full bg-rose-600 transition-[width] duration-150"
              style={{ width: `${Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100))}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-0.5 text-[11px]">
            <div>
              <div className="flex justify-between text-slate-400">
                <span>{t.dash}</span>
                <span className="font-mono-num">{Math.round(hud.dashCharge * 100)}%</span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-sky-400"
                  style={{ width: `${Math.round(hud.dashCharge * 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-400">
                <span>{t.skill}</span>
                <span className="font-mono-num">{Math.round(hud.specialCharge * 100)}%</span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-amber-400"
                  style={{ width: `${Math.round(hud.specialCharge * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Center Boss HP Bar when active */}
        {hud.bossActive && (
          <div className="flex-1 max-w-md mx-auto bg-slate-950/80 border border-rose-900/60 rounded-xl px-4 py-2">
            <div className="flex items-center justify-between text-xs font-bold text-rose-200 mb-1.5">
              <span>{lang === 'ar' ? hud.bossNameAr : hud.bossNameEn}</span>
              <span className="font-mono-num">
                {hud.bossHp}/{hud.bossMaxHp}
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-900">
              <div
                className="h-full bg-gradient-to-r from-rose-700 to-amber-500 transition-[width] duration-150"
                style={{
                  width: `${Math.max(0, Math.min(100, (hud.bossHp / Math.max(1, hud.bossMaxHp)) * 100))}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* Right Metrics + Weapon Switcher + Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Weapon Switcher */}
          <button
            type="button"
            onClick={() => engineRef.current?.cycleWeapon()}
            title={`${t.switchWeapon} (R)`}
            className={`pointer-events-auto flex min-h-[40px] items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-bold text-white transition-all ${
              clashPulse
                ? 'border-amber-300 bg-amber-950/80 shadow-[0_0_16px_rgba(251,191,36,0.55)] scale-105'
                : 'border-slate-700/80 bg-slate-950/80 hover:border-sky-400/70'
            }`}
          >
            <Sword className="h-3.5 w-3.5" style={{ color: currentWeaponObj.accentColor }} />
            <span className="whitespace-nowrap">
              {lang === 'ar' ? currentWeaponObj.nameAr : currentWeaponObj.nameEn}
            </span>
          </button>

          <div className="hidden sm:flex items-center gap-4 bg-slate-950/75 border border-slate-800/80 rounded-xl px-3.5 py-2 text-xs">
            <div className="flex items-center gap-1.5 text-sky-400 font-semibold">
              <Gem className="h-3.5 w-3.5" />
              <span className="font-mono-num">{hud.gemsCollected}</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center gap-1.5 text-emerald-300 font-semibold">
              <Sparkles className="h-3.5 w-3.5" />
              <span className="font-mono-num">{hud.xpCollected}</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="text-slate-200 font-semibold">
              {t.score}: <span className="font-mono-num">{hud.score}</span>
            </div>
            {hud.combo > 1 && (
              <>
                <span className="text-slate-600">·</span>
                <span className="text-rose-400 font-bold font-mono-num">
                  {hud.combo}x {t.combo}
                </span>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={() => setTouchVisible((v) => !v)}
            title={touchVisible ? t.touchToggleOff : t.touchToggleOn}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/80 bg-slate-950/80 text-slate-200 hover:border-slate-500 transition-colors"
          >
            <Smartphone className={`h-4 w-4 ${touchVisible ? 'text-rose-400' : 'text-slate-400'}`} />
          </button>

          <button
            type="button"
            onClick={toggleMute}
            title={muted ? t.unmuteAudio : t.muteAudio}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/80 bg-slate-950/80 text-slate-200 hover:border-slate-500 transition-colors"
          >
            {muted ? <VolumeX className="h-4 w-4 text-slate-400" /> : <Volume2 className="h-4 w-4" />}
          </button>

          <button
            type="button"
            onClick={() => setGameState((s) => (s === 'PLAYING' ? 'PAUSED' : 'PLAYING'))}
            title={t.pause}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/80 bg-slate-950/80 text-slate-200 hover:border-rose-500/70 transition-colors"
          >
            <Pause className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Multi-Touch Overlay */}
      {touchVisible && gameState === 'PLAYING' && !showBriefing && (
        <TouchControls
          engineRef={engineRef}
          lang={lang}
          dashCharge={hud.dashCharge}
          specialCharge={hud.specialCharge}
        />
      )}

      {/* Chapter Story Briefing Overlay */}
      {showBriefing && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-[#0D1320] p-6 sm:p-8 shadow-2xl">
            <div className="text-xs font-semibold text-rose-400 mb-2">
              {t.storyIntroTitle} · {lang === 'ar' ? stage.challengeTagAr : stage.challengeTagEn}
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">
              {lang === 'ar' ? stage.titleAr : stage.titleEn}
            </h2>
            <p className="text-sm sm:text-base leading-relaxed text-slate-300 mb-6">
              {stageId === 'seasonal'
                ? lang === 'ar'
                  ? seasonalEvent.descriptionAr
                  : seasonalEvent.descriptionEn
                : lang === 'ar'
                ? stage.storyIntroAr
                : stage.storyIntroEn}
            </p>
            <div className="flex items-center justify-between gap-4 border-t border-slate-800 pt-4">
              <span className="text-xs text-slate-400">
                {t.bossLabel}:{' '}
                <strong className="text-slate-200">
                  {lang === 'ar' ? stage.bossNameAr : stage.bossNameEn}
                </strong>
              </span>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playUiClick();
                  setShowBriefing(false);
                }}
                className="flex items-center gap-2 rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-rose-500 transition-colors whitespace-nowrap"
              >
                <Play className="h-4 w-4" />
                <span>{t.enterBattle}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pause Modal */}
      {gameState === 'PAUSED' && !showBriefing && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-[#0D1320] p-6 text-center shadow-2xl">
            <h2 className="text-2xl font-bold text-white mb-2">{t.pause}</h2>
            <p className="text-xs text-slate-400 mb-6">{t.controlHint}</p>
            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={() => setGameState('PLAYING')}
                className="flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-5 py-3 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
              >
                <Play className="h-4 w-4" />
                <span>{t.resume}</span>
              </button>
              <button
                type="button"
                onClick={handleRestart}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-5 py-3 text-sm font-semibold text-slate-200 hover:bg-slate-800 transition-colors"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{t.restart}</span>
              </button>
              <button
                type="button"
                onClick={onExitToTitle}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-transparent px-5 py-3 text-sm font-semibold text-slate-400 hover:text-white transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>{t.returnTitle}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Victory / Game Over Modal */}
      {(gameState === 'VICTORY' || gameState === 'GAME_OVER') && matchResult && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/85 p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-[#0D1320] p-6 sm:p-7 shadow-2xl">
            <div className="flex items-center gap-3 mb-3">
              <div
                className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                  gameState === 'VICTORY'
                    ? 'bg-sky-500/15 text-sky-400'
                    : 'bg-rose-500/15 text-rose-400'
                }`}
              >
                {gameState === 'VICTORY' ? (
                  <Trophy className="h-6 w-6" />
                ) : (
                  <Skull className="h-6 w-6" />
                )}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {gameState === 'VICTORY' ? t.victory : t.defeat}
                </h2>
                <p className="text-xs text-slate-400">
                  {mpWinnerName
                    ? `${multiplayerRoom?.mode === 'coop' ? t.mpCoopVictory : t.mpCompVictory} — ${mpWinnerName}`
                    : gameState === 'VICTORY'
                    ? lang === 'ar'
                      ? stage.storyOutroAr
                      : stage.storyOutroEn
                    : lang === 'ar'
                    ? stage.titleAr
                    : stage.titleEn}
                </p>
              </div>
            </div>

            <div className="my-5 grid grid-cols-2 gap-3 rounded-xl border border-slate-800/80 bg-slate-950/60 p-4 text-sm">
              <div>
                <div className="text-xs text-slate-400">{t.score}</div>
                <div className="font-mono-num text-lg font-bold text-white">{matchResult.score}</div>
              </div>
              <div>
                <div className="text-xs text-slate-400">{t.timeElapsed}</div>
                <div className="font-mono-num text-lg font-bold text-slate-200">
                  {matchResult.elapsedSec}s
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">{t.gemsEarned}</div>
                <div className="font-mono-num text-lg font-bold text-sky-400">
                  +{matchResult.gemsEarned}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">{t.xpEarned}</div>
                <div className="font-mono-num text-lg font-bold text-emerald-400">
                  +{matchResult.xpEarned}
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              {gameState === 'VICTORY' &&
                nextStageObj &&
                !multiplayerRoom &&
                stageId !== SEASONAL_STAGE_CONFIG.id && (
                  <button
                    type="button"
                    onClick={() => {
                      setMatchResult(null);
                      setGameState('PLAYING');
                      setShowBriefing(true);
                      onSelectStage(nextStageObj.id);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-3 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
                  >
                    <span>{t.nextChapter}</span>
                    {lang === 'ar' ? (
                      <ArrowLeft className="h-4 w-4" />
                    ) : (
                      <ArrowRight className="h-4 w-4" />
                    )}
                  </button>
                )}

              <button
                type="button"
                onClick={handleRestart}
                className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-sm font-semibold text-white hover:bg-slate-800 transition-colors"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{t.playAgain}</span>
              </button>

              <button
                type="button"
                onClick={onExitToTitle}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 px-4 py-3 text-sm font-semibold text-slate-400 hover:text-white transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>{t.returnTitle}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
