import { Check, Gem, Gift, Sparkles, X } from 'lucide-react';
import { DAILY_REWARDS } from '../data/gameCatalog';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import type { Language, PlayerProfile } from '../types/game';

interface DailyRewardsModalProps {
  profile: PlayerProfile;
  lang: Language;
  onClaim: (gems: number, xp: number, newStreak: number, todayKey: string) => void;
  onClose: () => void;
}

export function getTodayUtcKey(): string {
  return new Date().toISOString().slice(0, 10);
}

export function DailyRewardsModal({
  profile,
  lang,
  onClaim,
  onClose,
}: DailyRewardsModalProps) {
  const t = getText(lang);
  const todayKey = getTodayUtcKey();
  const alreadyClaimed = profile.lastDailyClaimDay === todayKey;
  const activeDayIndex = profile.dailyStreak % DAILY_REWARDS.length;

  const handleClaim = () => {
    if (alreadyClaimed) return;
    const reward = DAILY_REWARDS[activeDayIndex];
    soundEngine.playVictory();
    onClaim(reward.gems, reward.xp, profile.dailyStreak + 1, todayKey);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-3">
            <Gift className="h-5 w-5 text-amber-400" />
            <div>
              <h2 className="text-xl font-bold text-white">{t.dailyTitle}</h2>
              <p className="text-xs text-slate-400">{t.dailySubtitle}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-5 flex items-center justify-between text-sm text-slate-300">
            <span>
              {t.streakLabel}:{' '}
              <strong className="font-mono-num text-amber-300">
                {profile.dailyStreak} {t.daysUnit}
              </strong>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            {DAILY_REWARDS.map((item, idx) => {
              const isPast = idx < activeDayIndex;
              const isToday = idx === activeDayIndex;
              return (
                <div
                  key={item.day}
                  className={`flex flex-col items-center justify-center rounded-xl border p-4 text-center ${
                    isToday && !alreadyClaimed
                      ? 'border-amber-400 bg-amber-500/10'
                      : isPast || (isToday && alreadyClaimed)
                      ? 'border-emerald-700/50 bg-emerald-950/20'
                      : 'border-slate-800 bg-slate-900/40'
                  }`}
                >
                  <div className="text-xs text-slate-400 mb-2">
                    {t.dayLabel} <span className="font-mono-num">{item.day}</span>
                  </div>
                  <div className="flex items-center gap-1 text-base font-bold text-sky-400 font-mono-num">
                    <Gem className="h-4 w-4" />
                    <span>+{item.gems}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-1 text-xs text-emerald-300 font-mono-num">
                    <Sparkles className="h-3 w-3" />
                    <span>+{item.xp}</span>
                  </div>
                  {(isPast || (isToday && alreadyClaimed)) && (
                    <div className="mt-2 text-emerald-400">
                      <Check className="h-4 w-4" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <button
            type="button"
            disabled={alreadyClaimed}
            onClick={handleClaim}
            className={`flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition-colors ${
              alreadyClaimed
                ? 'border border-slate-800 bg-slate-900 text-slate-400 cursor-not-allowed'
                : 'bg-sky-500 text-slate-950 hover:bg-sky-400'
            }`}
          >
            <Gift className="h-4 w-4" />
            <span>{alreadyClaimed ? t.alreadyClaimed : t.claimReward}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
