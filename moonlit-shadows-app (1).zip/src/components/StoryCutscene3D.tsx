import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { FastForward, Volume2, VolumeX } from 'lucide-react';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import type { Language } from '../types/game';

interface StoryCutscene3DProps {
  lang: Language;
  onFinish: () => void;
}

const CUTSCENE_DURATION = 20.0;

// Reusable module-scope math objects (zero GC inside render tick)
const _camPos = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _dummy = new THREE.Object3D();
const _color = new THREE.Color();
const _silverMoon = new THREE.Color(0xdbeafe);
const _bloodMoon = new THREE.Color(0xe11d48);
const _silverLight = new THREE.Color(0x93c5fd);
const _crimsonLight = new THREE.Color(0xf43f5e);

export function StoryCutscene3D({ lang, onFinish }: StoryCutscene3DProps) {
  const t = getText(lang);
  const mountRef = useRef<HTMLDivElement>(null);
  const onFinishRef = useRef(onFinish);
  onFinishRef.current = onFinish;

  const [elapsed, setElapsed] = useState(0);
  const [muted, setMuted] = useState(soundEngine.isMuted());
  const [audioBlocked, setAudioBlocked] = useState(false);
  const finishedRef = useRef(false);

  const handleComplete = () => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    soundEngine.stopCutsceneMusic();
    onFinishRef.current();
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    soundEngine.startCutsceneMusic();
    setAudioBlocked(soundEngine.isAudioSuspended());

    const tryUnlockAudio = () => {
      void soundEngine.unlockAudio().then((ok) => {
        if (ok) {
          setAudioBlocked(false);
        }
      });
    };
    window.addEventListener('pointerdown', tryUnlockAudio, { passive: true });
    window.addEventListener('keydown', tryUnlockAudio);

    // Detect Software WebGL cleanly per Three.js directives
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const handleContextLost = (e: Event) => {
      e.preventDefault();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060913);
    scene.fog = new THREE.FogExp2(0x070b15, 0.017);

    // Studio Environment Reflections for Metallic Katana & Armor
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(48, width / height, 0.1, 220);
    camera.position.set(0, 7, 24);

    // Lighting Rig: Cool Sky/Ground Hemisphere + Moonlight Key + Warm Shoji Lantern Accent
    const hemi = new THREE.HemisphereLight(0x3b82f6, 0x0f172a, 0.55);
    scene.add(hemi);

    const moonLight = new THREE.DirectionalLight(0x93c5fd, 2.1);
    moonLight.position.set(-14, 24, -22);
    moonLight.castShadow = !isSoftwareGl;
    moonLight.shadow.mapSize.width = 1024;
    moonLight.shadow.mapSize.height = 1024;
    moonLight.shadow.camera.left = -22;
    moonLight.shadow.camera.right = 22;
    moonLight.shadow.camera.top = 22;
    moonLight.shadow.camera.bottom = -22;
    moonLight.shadow.bias = -0.0005;
    moonLight.shadow.normalBias = 0.02;
    scene.add(moonLight);

    const lanternGlow = new THREE.PointLight(0xf59e0b, 14, 26, 1.8);
    lanternGlow.position.set(0, 5.2, 2.5);
    scene.add(lanternGlow);

    const rimCrimson = new THREE.PointLight(0xe11d48, 0.5, 38, 1.5);
    rimCrimson.position.set(10, 8, -16);
    scene.add(rimCrimson);

    // Materials Library
    const darkSlateMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.78,
      metalness: 0.18,
    });
    const timberMat = new THREE.MeshStandardMaterial({
      color: 0x281812,
      roughness: 0.85,
      metalness: 0.05,
    });
    const crimsonWoodMat = new THREE.MeshStandardMaterial({
      color: 0x881337,
      roughness: 0.52,
      metalness: 0.15,
    });
    const shojiMat = new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      emissive: 0xf59e0b,
      emissiveIntensity: 1.4,
      roughness: 0.6,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.9,
      metalness: 0.08,
    });
    const shinobiClothMat = new THREE.MeshStandardMaterial({
      color: 0x0b0f19,
      roughness: 0.78,
      metalness: 0.12,
    });
    const armorTrimMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.3,
      metalness: 0.82,
    });
    const scarfMat = new THREE.MeshStandardMaterial({
      color: 0xe11d48,
      emissive: 0x4c0519,
      emissiveIntensity: 0.35,
      roughness: 0.62,
      metalness: 0.08,
    });
    const bladeSteelMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.12,
      metalness: 0.96,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.2,
      metalness: 0.92,
    });
    const visorEyeMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 2.2,
      roughness: 0.2,
    });

    // 1. Ground Courtyard & Reflective Water Plane (Natural mountain perimeter, no indoor walls)
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(180, 180),
      new THREE.MeshStandardMaterial({ color: 0x080c16, roughness: 0.42, metalness: 0.45 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Distant Mountain Silhouettes Ring
    const mountainGeo = new THREE.ConeGeometry(16, 20, 6);
    for (let i = 0; i < 14; i++) {
      const ang = (i / 14) * Math.PI * 2;
      const dist = 52 + (i % 3) * 14;
      const m = new THREE.Mesh(mountainGeo, stoneMat);
      m.position.set(Math.cos(ang) * dist, 7, Math.sin(ang) * dist - 10);
      m.scale.set(1.2 + (i % 2) * 0.4, 0.85 + (i % 3) * 0.35, 1.1);
      m.rotation.y = ang;
      scene.add(m);
    }

    // 2. Hero Foreground Temple Rooftop (Composite 6-part Group)
    const heroRoofGroup = new THREE.Group();
    const roofBase = new THREE.Mesh(new THREE.BoxGeometry(10, 3.6, 8), stoneMat);
    roofBase.position.y = 1.8;
    roofBase.castShadow = true;
    roofBase.receiveShadow = true;
    heroRoofGroup.add(roofBase);

    const roofPitchL = new THREE.Mesh(new THREE.BoxGeometry(11.6, 0.38, 4.8), darkSlateMat);
    roofPitchL.position.set(0, 4.35, -1.85);
    roofPitchL.rotation.x = 0.36;
    roofPitchL.castShadow = true;
    roofPitchL.receiveShadow = true;
    heroRoofGroup.add(roofPitchL);

    const roofPitchR = new THREE.Mesh(new THREE.BoxGeometry(11.6, 0.38, 4.8), darkSlateMat);
    roofPitchR.position.set(0, 4.35, 1.85);
    roofPitchR.rotation.x = -0.36;
    roofPitchR.castShadow = true;
    roofPitchR.receiveShadow = true;
    heroRoofGroup.add(roofPitchR);

    const ridgeBeam = new THREE.Mesh(new THREE.BoxGeometry(12.2, 0.45, 0.58), timberMat);
    ridgeBeam.position.set(0, 5.2, 0);
    ridgeBeam.castShadow = true;
    heroRoofGroup.add(ridgeBeam);

    for (const side of [-1, 1]) {
      const finial = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.1, 6), goldMat);
      finial.position.set(side * 5.9, 5.65, 0);
      finial.rotation.z = side * -0.25;
      heroRoofGroup.add(finial);
    }
    heroRoofGroup.position.set(0, 0, 2);
    scene.add(heroRoofGroup);

    // 3. Multi-Tier 3D Japanese Pagoda (Composite 10-part Group)
    const buildPagoda = (px: number, pz: number, scale = 1) => {
      const pagoda = new THREE.Group();
      const basePlinth = new THREE.Mesh(new THREE.BoxGeometry(7.6, 1.4, 7.6), stoneMat);
      basePlinth.position.y = 0.7;
      basePlinth.receiveShadow = true;
      pagoda.add(basePlinth);

      for (let tier = 0; tier < 3; tier++) {
        const w = 5.4 - tier * 1.15;
        const yBase = 1.4 + tier * 3.8;
        const body = new THREE.Mesh(new THREE.BoxGeometry(w, 2.7, w), timberMat);
        body.position.y = yBase + 1.35;
        body.castShadow = true;
        pagoda.add(body);

        const glowWin = new THREE.Mesh(new THREE.BoxGeometry(w * 0.7, 1.2, w + 0.08), shojiMat);
        glowWin.position.y = yBase + 1.35;
        pagoda.add(glowWin);

        const glowWinSide = new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, 1.2, w * 0.7), shojiMat);
        glowWinSide.position.y = yBase + 1.35;
        pagoda.add(glowWinSide);

        const eave = new THREE.Mesh(new THREE.ConeGeometry(w * 1.05, 1.25, 4), darkSlateMat);
        eave.position.y = yBase + 3.05;
        eave.rotation.y = Math.PI / 4;
        eave.castShadow = true;
        pagoda.add(eave);
      }

      const spire = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.25, 3.2, 8), goldMat);
      spire.position.y = 13.8;
      pagoda.add(spire);

      pagoda.position.set(px, 0, pz);
      pagoda.scale.setScalar(scale);
      return pagoda;
    };

    scene.add(buildPagoda(-12, -16, 1.05));
    scene.add(buildPagoda(13, -22, 1.25));

    // 4. Torii Gate & Shadow Shogun Citadel (Composite Groups)
    const torii = new THREE.Group();
    for (const sx of [-2.4, 2.4]) {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.34, 6.2, 10), crimsonWoodMat);
      pillar.position.set(sx, 3.1, 0);
      pillar.castShadow = true;
      torii.add(pillar);
    }
    const kasagi = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.45, 0.65), darkSlateMat);
    kasagi.position.y = 6.2;
    torii.add(kasagi);
    const nuki = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.32, 0.4), crimsonWoodMat);
    nuki.position.y = 5.1;
    torii.add(nuki);
    torii.position.set(5.5, 0, -9);
    torii.rotation.y = -0.3;
    scene.add(torii);

    // 5. Composite 11-Part 3D Hero Ninja perched on the foreground roof ridge
    const ninja = new THREE.Group();
    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.95, 0.35), shinobiClothMat);
    legL.position.set(-0.26, 0.48, 0.14);
    legL.rotation.x = 0.25;
    ninja.add(legL);

    const legR = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.95, 0.35), shinobiClothMat);
    legR.position.set(0.28, 0.48, -0.14);
    legR.rotation.x = -0.22;
    ninja.add(legR);

    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.86, 1.08, 0.5), shinobiClothMat);
    torso.position.y = 1.32;
    torso.rotation.x = 0.14;
    torso.castShadow = true;
    ninja.add(torso);

    const sash = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.22, 0.56), scarfMat);
    sash.position.y = 0.95;
    ninja.add(sash);

    for (const side of [-1, 1]) {
      const pauldron = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.22, 0.54), armorTrimMat);
      pauldron.position.set(side * 0.54, 1.78, 0);
      pauldron.rotation.z = side * -0.25;
      ninja.add(pauldron);
    }

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.36, 16, 16), shinobiClothMat);
    head.position.set(0, 2.18, 0.08);
    head.castShadow = true;
    ninja.add(head);

    const headband = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.14, 16), scarfMat);
    headband.position.set(0, 2.26, 0.08);
    ninja.add(headband);

    const eyes = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.08, 0.15), visorEyeMat);
    eyes.position.set(0, 2.18, 0.36);
    ninja.add(eyes);

    // Multi-segment Animated Flowing Scarf
    const scarfSegs: THREE.Mesh[] = [];
    for (let i = 0; i < 6; i++) {
      const seg = new THREE.Mesh(
        new THREE.BoxGeometry(0.24 - i * 0.02, 0.12, 0.62),
        scarfMat
      );
      seg.position.set(-0.1, 1.85 - i * 0.06, -0.45 - i * 0.55);
      ninja.add(seg);
      scarfSegs.push(seg);
    }

    // Articulated Sword Arm + Curved Metallic Katana
    const swordArm = new THREE.Group();
    swordArm.position.set(0.55, 1.65, 0.12);
    const armMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.72, 0.24), shinobiClothMat);
    armMesh.position.set(0, -0.32, 0);
    swordArm.add(armMesh);

    const katanaGroup = new THREE.Group();
    katanaGroup.position.set(0, -0.65, 0.15);
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 8), scarfMat);
    hilt.rotation.x = Math.PI / 2;
    katanaGroup.add(hilt);

    const tsuba = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.04, 12), goldMat);
    tsuba.rotation.x = Math.PI / 2;
    tsuba.position.z = 0.24;
    katanaGroup.add(tsuba);

    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.1, 2.1), bladeSteelMat);
    blade.position.z = 1.3;
    katanaGroup.add(blade);

    swordArm.add(katanaGroup);
    ninja.add(swordArm);

    ninja.position.set(0, 5.42, 2);
    scene.add(ninja);

    // 6. Luminous 3D Full Moon -> Blood Eclipse Sphere
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xdbeafe });
    const moon = new THREE.Mesh(new THREE.SphereGeometry(7.5, 32, 32), moonMat);
    moon.position.set(-6, 19, -58);
    scene.add(moon);

    const eclipseOccluder = new THREE.Mesh(
      new THREE.SphereGeometry(7.1, 28, 28),
      new THREE.MeshBasicMaterial({ color: 0x060913 })
    );
    eclipseOccluder.position.set(-14, 21, -55);
    scene.add(eclipseOccluder);

    // 7. Instanced Floating Embers & Moonlight Mist (160 glowing particles)
    const emberCount = 160;
    const emberGeo = new THREE.OctahedronGeometry(0.11, 0);
    const emberMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const embers = new THREE.InstancedMesh(emberGeo, emberMat, emberCount);
    embers.frustumCulled = false;

    const emberData = Array.from({ length: emberCount }, () => ({
      x: (Math.random() - 0.5) * 46,
      y: Math.random() * 18,
      z: (Math.random() - 0.5) * 42 - 8,
      speed: 0.7 + Math.random() * 1.4,
      phase: Math.random() * Math.PI * 2,
      scale: 0.65 + Math.random() * 0.9,
    }));

    for (let i = 0; i < emberCount; i++) {
      _dummy.position.set(emberData[i].x, emberData[i].y, emberData[i].z);
      _dummy.scale.setScalar(emberData[i].scale);
      _dummy.updateMatrix();
      embers.setMatrixAt(i, _dummy.matrix);
      _color.setHex(i % 3 === 0 ? 0xfb7185 : i % 3 === 1 ? 0xfbbf24 : 0x7dd3fc);
      embers.setColorAt(i, _color);
    }
    embers.instanceMatrix.needsUpdate = true;
    if (embers.instanceColor) embers.instanceColor.needsUpdate = true;
    embers.computeBoundingSphere();
    scene.add(embers);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    let frameId = 0;
    let disposed = false;
    let swordSfxPlayed = false;
    const startMs = performance.now();
    let prevMs = startMs;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const dt = Math.min(0.05, (now - prevMs) / 1000);
      prevMs = now;
      const tSec = Math.min(CUTSCENE_DURATION, (now - startMs) / 1000);
      setElapsed(tSec);

      // 4-Act Camera Choreography across 20 seconds
      if (tSec < 5.0) {
        // Act 1: Sweeping crane over moonlit pagoda rooftops
        const p = tSec / 5.0;
        _camPos.set(-14 + p * 12, 12.5 - p * 3.5, 22 - p * 4);
        _camTarget.set(-2, 7.5, -14);
      } else if (tSec < 10.0) {
        // Act 2: Orbit toward Blood Eclipse & Torii / Citadel
        const p = (tSec - 5.0) / 5.0;
        _camPos.set(-2 + p * 11, 9.0 - p * 1.6, 18 - p * 8);
        _camTarget.set(1.5, 6.2 + p * 1.5, -8);
      } else if (tSec < 15.0) {
        // Act 3: Dramatic close-up push-in on Hero Ninja drawing Katana
        const p = (tSec - 10.0) / 5.0;
        _camPos.set(9 - p * 6.4, 7.4 - p * 0.4, 10 - p * 4.4);
        _camTarget.set(0.15, 7.05, 2.0);
        if (tSec >= 11.2 && !swordSfxPlayed) {
          swordSfxPlayed = true;
          soundEngine.playCutsceneSwordDraw();
        }
      } else {
        // Act 4: Heroic low-angle wide reveal under crimson moon
        const p = (tSec - 15.0) / 5.0;
        _camPos.set(2.6 - p * 4.2, 6.4 + p * 1.8, 5.6 + p * 8.2);
        _camTarget.set(0, 7.2, -3);
      }

      const dampAlpha = 1 - Math.exp(-3.5 * dt);
      camera.position.lerp(_camPos, dampAlpha);
      camera.lookAt(_camTarget);

      // Animate Blood Eclipse progression (Acts 2-4)
      const eclipseBlend = THREE.MathUtils.smoothstep(tSec, 5.5, 13.5);
      moonMat.color.copy(_silverMoon).lerp(_bloodMoon, eclipseBlend);
      moonLight.color.copy(_silverLight).lerp(_crimsonLight, eclipseBlend);
      rimCrimson.intensity = 0.5 + eclipseBlend * 18;
      eclipseOccluder.position.x = -14 + eclipseBlend * 6.8;
      eclipseOccluder.position.y = 21 - eclipseBlend * 1.6;

      // Animate Ninja Breathing, Scarf Wind Ripples & Katana Draw
      ninja.position.y = 5.42 + Math.sin(tSec * 2.2) * 0.04;
      const drawProgress = THREE.MathUtils.smoothstep(tSec, 10.6, 12.2);
      swordArm.rotation.x = THREE.MathUtils.lerp(0.55, -1.05, drawProgress);
      swordArm.rotation.z = THREE.MathUtils.lerp(0.1, 0.35, drawProgress);

      for (let i = 0; i < scarfSegs.length; i++) {
        scarfSegs[i].position.y = 1.85 - i * 0.05 + Math.sin(tSec * 6.5 - i * 0.8) * (0.05 + i * 0.025);
        scarfSegs[i].position.x = -0.1 + Math.cos(tSec * 5.2 - i * 0.7) * (0.04 + i * 0.03);
      }

      // Animate Floating Embers & Mist Sparks
      for (let i = 0; i < emberCount; i++) {
        const ed = emberData[i];
        const yLoop = (ed.y + tSec * ed.speed) % 18;
        _dummy.position.set(
          ed.x + Math.sin(tSec * 1.3 + ed.phase) * 0.9,
          yLoop,
          ed.z + Math.cos(tSec * 1.1 + ed.phase) * 0.9
        );
        _dummy.rotation.set(tSec + ed.phase, tSec * 0.8, 0);
        _dummy.scale.setScalar(ed.scale * (0.85 + eclipseBlend * 0.4));
        _dummy.updateMatrix();
        embers.setMatrixAt(i, _dummy.matrix);
      }
      embers.instanceMatrix.needsUpdate = true;

      renderer.render(scene, camera);

      if (tSec >= CUTSCENE_DURATION) {
        handleComplete();
        return;
      }

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      disposed = true;
      soundEngine.stopCutsceneMusic();
      window.removeEventListener('pointerdown', tryUnlockAudio);
      window.removeEventListener('keydown', tryUnlockAudio);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);

      scene.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const mesh = obj as THREE.Mesh;
          mesh.geometry.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      });
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const actIdx = Math.min(3, Math.floor(elapsed / 5.0));
  const subtitle =
    actIdx === 0
      ? t.storyAct1
      : actIdx === 1
      ? t.storyAct2
      : actIdx === 2
      ? t.storyAct3
      : t.storyAct4;

  const toggleMute = () => {
    const next = !muted;
    soundEngine.setMuted(next);
    setMuted(next);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#05070E]">
      {/* Isolated 3D WebGL Mount */}
      <div ref={mountRef} className="h-full w-full" />

      {/* Cinema Top Letterbox Bar (Solid, zero backdrop-blur over WebGL) */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between bg-[#05070E] px-5 py-3.5 sm:px-8">
        <div className="flex items-center gap-3">
          <span className="font-display-en text-[11px] font-bold tracking-[0.22em] text-rose-400 uppercase">
            {t.cutsceneBadge}
          </span>
          <span className="font-mono-num text-xs text-slate-400">
            {String(Math.floor(elapsed)).padStart(2, '0')}s / 20s
          </span>
        </div>

        <div className="pointer-events-auto flex items-center gap-2.5">
          {audioBlocked && !muted && (
            <button
              type="button"
              onClick={() => {
                void soundEngine.unlockAudio().then((ok) => {
                  if (ok) setAudioBlocked(false);
                });
              }}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl border border-amber-500/50 bg-slate-900 px-3 py-2 text-xs font-semibold text-amber-200 hover:border-amber-400 transition-colors whitespace-nowrap"
            >
              <Volume2 className="h-3.5 w-3.5 text-amber-400" />
              <span>{t.tapForSound}</span>
            </button>
          )}

          <button
            type="button"
            onClick={toggleMute}
            aria-label={muted ? t.unmuteAudio : t.muteAudio}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-200 hover:border-slate-600 transition-colors"
          >
            {muted ? <VolumeX className="h-4 w-4 text-slate-400" /> : <Volume2 className="h-4 w-4" />}
          </button>

          <button
            type="button"
            onClick={handleComplete}
            className="flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:border-rose-500/70 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <span>{t.skipCutscene}</span>
            <FastForward className="h-3.5 w-3.5 text-rose-400" />
          </button>
        </div>
      </div>

      {/* Cinema Bottom Letterbox Bar with Story Narration & Timeline */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex flex-col items-center bg-[#05070E] px-6 py-5 sm:py-6">
        <p className="max-w-2xl text-center text-base sm:text-xl font-bold leading-relaxed text-slate-100 min-h-[3.2rem] flex items-center justify-center">
          {subtitle}
        </p>

        <div className="mt-3 h-1 w-full max-w-xl overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full bg-gradient-to-r from-rose-600 to-amber-400 transition-[width] duration-100"
            style={{ width: `${Math.min(100, (elapsed / CUTSCENE_DURATION) * 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}
