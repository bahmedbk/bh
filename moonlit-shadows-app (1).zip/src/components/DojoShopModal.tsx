import { useState } from 'react';
import { Check, Flame, Gem, Shield, Sparkles, Sword, X } from 'lucide-react';
import { getSkillUpgradeCost, SKILLS, SKINS, WEAPONS } from '../data/gameCatalog';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import type { Language, PlayerProfile, SkinId, WeaponId } from '../types/game';

interface DojoShopModalProps {
  profile: PlayerProfile;
  lang: Language;
  onUpdateProfile: (next: PlayerProfile) => void;
  onClose: () => void;
}

type ShopTab = 'weapons' | 'skins' | 'skills';

export function DojoShopModal({
  profile,
  lang,
  onUpdateProfile,
  onClose,
}: DojoShopModalProps) {
  const t = getText(lang);
  const [tab, setTab] = useState<ShopTab>('weapons');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const buyOrEquipWeapon = (id: WeaponId, cost: number) => {
    const owned = profile.unlockedWeapons.includes(id);
    if (owned) {
      soundEngine.playUiClick();
      onUpdateProfile({ ...profile, equippedWeapon: id });
      return;
    }
    if (profile.gems < cost) return;
    soundEngine.playGemPickup();
    onUpdateProfile({
      ...profile,
      gems: profile.gems - cost,
      unlockedWeapons: [...profile.unlockedWeapons, id],
      equippedWeapon: id,
    });
  };

  const buyOrEquipSkin = (id: SkinId, cost: number) => {
    const owned = profile.unlockedSkins.includes(id);
    if (owned) {
      soundEngine.playUiClick();
      onUpdateProfile({ ...profile, equippedSkin: id });
      return;
    }
    if (profile.gems < cost) return;
    soundEngine.playGemPickup();
    onUpdateProfile({
      ...profile,
      gems: profile.gems - cost,
      unlockedSkins: [...profile.unlockedSkins, id],
      equippedSkin: id,
    });
  };

  const upgradeSkill = (
    key: 'skillHealth' | 'skillDash' | 'skillAttack' | 'skillXp',
    cost: number,
    maxRank: number
  ) => {
    const rank = profile[key];
    if (rank >= maxRank || profile.gems < cost) return;
    soundEngine.playGemPickup();
    onUpdateProfile({
      ...profile,
      gems: profile.gems - cost,
      [key]: rank + 1,
    });
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-bold text-white">{t.dojoShop}</h2>
            <div className="flex items-center gap-1.5 text-sm font-bold text-sky-400 font-mono-num">
              <Gem className="h-4 w-4" />
              <span>{profile.gems}</span>
              <span className="text-xs font-normal text-slate-400">{t.gems}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Segmented Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800/70 bg-slate-950/50 px-6 py-3 overflow-x-auto">
          <button
            type="button"
            onClick={() => setTab('weapons')}
            className={`flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === 'weapons'
                ? 'bg-rose-600 text-white'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Sword className="h-4 w-4" />
            <span>{t.weaponsTab}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('skins')}
            className={`flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === 'skins'
                ? 'bg-rose-600 text-white'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="h-4 w-4" />
            <span>{t.skinsTab}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('skills')}
            className={`flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === 'skills'
                ? 'bg-rose-600 text-white'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="h-4 w-4" />
            <span>{t.skillsTab}</span>
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6">
          {tab === 'weapons' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {WEAPONS.map((w) => {
                const owned = profile.unlockedWeapons.includes(w.id);
                const equipped = profile.equippedWeapon === w.id;
                const canAfford = profile.gems >= w.costGems;
                const imgFailed = failedImages[w.id];
                return (
                  <div
                    key={w.id}
                    className={`flex flex-col justify-between overflow-hidden rounded-xl border ${
                      equipped
                        ? 'border-rose-500/70 bg-slate-900/85'
                        : 'border-slate-800 bg-slate-900/45'
                    }`}
                  >
                    <div>
                      {/* Weapon Artwork Showcase */}
                      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-950">
                        {!imgFailed ? (
                          <img
                            src={w.imageUrl}
                            alt={lang === 'ar' ? w.nameAr : w.nameEn}
                            referrerPolicy="no-referrer"
                            onError={() =>
                              setFailedImages((prev) => ({ ...prev, [w.id]: true }))
                            }
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950 text-slate-400">
                            <Sword className="h-10 w-10 mb-2" style={{ color: w.accentColor }} />
                            <span className="text-xs font-semibold">
                              {lang === 'ar' ? w.nameAr : w.nameEn}
                            </span>
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-[#0D1320] via-transparent to-transparent" />
                      </div>

                      <div className="p-5 pt-3">
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <h3 className="text-lg font-bold text-white">
                            {lang === 'ar' ? w.nameAr : w.nameEn}
                          </h3>
                          <span
                            className="h-2.5 w-8 rounded-full"
                            style={{ backgroundColor: w.accentColor }}
                          />
                        </div>
                        <p className="text-xs text-slate-300 mb-3">
                          {lang === 'ar' ? w.styleAr : w.styleEn}
                        </p>

                        <div className="grid grid-cols-3 gap-2 rounded-lg bg-slate-950/60 p-3 text-xs mb-3">
                          <div>
                            <div className="text-slate-400">{t.damage}</div>
                            <div className="font-mono-num font-bold text-white">{w.damage}</div>
                          </div>
                          <div>
                            <div className="text-slate-400">{t.speed}</div>
                            <div className="font-mono-num font-bold text-sky-300">
                              {w.speedMultiplier.toFixed(1)}x
                            </div>
                          </div>
                          <div>
                            <div className="text-slate-400">{t.reach}</div>
                            <div className="font-mono-num font-bold text-emerald-300">{w.range}</div>
                          </div>
                        </div>

                        <div className="text-xs text-amber-300/90 flex items-start gap-1.5 mb-4">
                          <Flame className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                          <span>
                            <strong>{lang === 'ar' ? w.specialNameAr : w.specialNameEn}:</strong>{' '}
                            {lang === 'ar' ? w.specialDescAr : w.specialDescEn}
                          </span>
                        </div>

                        <button
                          type="button"
                          disabled={!owned && !canAfford}
                          onClick={() => buyOrEquipWeapon(w.id, w.costGems)}
                          className={`flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-colors ${
                            equipped
                              ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                              : owned
                              ? 'bg-slate-800 text-white hover:bg-slate-700'
                              : canAfford
                              ? 'bg-sky-500 text-slate-950 hover:bg-sky-400'
                              : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                          }`}
                        >
                          {equipped ? (
                            <>
                              <Check className="h-4 w-4" />
                              <span>{t.equipped}</span>
                            </>
                          ) : owned ? (
                            <span>{t.equip}</span>
                          ) : (
                            <>
                              <Gem className="h-4 w-4" />
                              <span className="font-mono-num">
                                {t.unlock} ({w.costGems})
                              </span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'skins' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SKINS.map((s) => {
                const owned = profile.unlockedSkins.includes(s.id);
                const equipped = profile.equippedSkin === s.id;
                const canAfford = profile.gems >= s.costGems;
                return (
                  <div
                    key={s.id}
                    className={`flex flex-col justify-between rounded-xl border p-5 ${
                      equipped
                        ? 'border-rose-500/70 bg-slate-900/80'
                        : 'border-slate-800 bg-slate-900/40'
                    }`}
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div
                        className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl border border-slate-700"
                        style={{ backgroundColor: s.suitColor }}
                      >
                        <div
                          className="h-2.5 w-10 rounded-full mb-1.5"
                          style={{ backgroundColor: s.scarfColor }}
                        />
                        <div className="flex gap-2">
                          <span
                            className="h-1.5 w-2.5 rounded-sm"
                            style={{ backgroundColor: s.eyeColor }}
                          />
                          <span
                            className="h-1.5 w-2.5 rounded-sm"
                            style={{ backgroundColor: s.eyeColor }}
                          />
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-bold text-white">
                          {lang === 'ar' ? s.nameAr : s.nameEn}
                        </h3>
                        <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                          {lang === 'ar' ? s.descAr : s.descEn}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={!owned && !canAfford}
                      onClick={() => buyOrEquipSkin(s.id, s.costGems)}
                      className={`flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-colors ${
                        equipped
                          ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                          : owned
                          ? 'bg-slate-800 text-white hover:bg-slate-700'
                          : canAfford
                          ? 'bg-sky-500 text-slate-950 hover:bg-sky-400'
                          : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                      }`}
                    >
                      {equipped ? (
                        <>
                          <Check className="h-4 w-4" />
                          <span>{t.equipped}</span>
                        </>
                      ) : owned ? (
                        <span>{t.equip}</span>
                      ) : (
                        <>
                          <Gem className="h-4 w-4" />
                          <span className="font-mono-num">
                            {t.unlock} ({s.costGems})
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'skills' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SKILLS.map((sk) => {
                const rank = profile[sk.key];
                const maxed = rank >= sk.maxRank;
                const cost = getSkillUpgradeCost(sk, rank);
                const canAfford = profile.gems >= cost;
                return (
                  <div
                    key={sk.key}
                    className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/50 p-5"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <h3 className="text-lg font-bold text-white">
                          {lang === 'ar' ? sk.nameAr : sk.nameEn}
                        </h3>
                        <span className="font-mono-num text-xs font-bold text-rose-400">
                          {rank}/{sk.maxRank}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mb-3">
                        {lang === 'ar' ? sk.descAr : sk.descEn}
                      </p>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-950 mb-4">
                        <div
                          className="h-full bg-rose-500 transition-[width] duration-200"
                          style={{ width: `${(rank / sk.maxRank) * 100}%` }}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={maxed || !canAfford}
                      onClick={() => upgradeSkill(sk.key, cost, sk.maxRank)}
                      className={`flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-colors ${
                        maxed
                          ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                          : canAfford
                          ? 'bg-rose-600 text-white hover:bg-rose-500'
                          : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                      }`}
                    >
                      {maxed ? (
                        <span>{t.maxed}</span>
                      ) : (
                        <>
                          <Gem className="h-4 w-4" />
                          <span className="font-mono-num">
                            {t.upgrade} ({cost})
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
