import { useEffect, useState } from 'react';
import { Calendar, Check, Flame, Gem, Play, PlusCircle, Sparkles, X } from 'lucide-react';
import seasonalBannerUrl from '../assets/images/seasonal_eclipse_banner_1794529269692.jpg';
import { getText } from '../i18n/translations';
import { publishSeasonalUpdate } from '../lib/firebase';
import type { Language, PlayerProfile, SeasonalEvent, SeasonalModifier } from '../types/game';

interface ReleaseNote {
  version: string;
  date: string;
  titleAr: string;
  titleEn: string;
  notesAr: string[];
  notesEn: string[];
}

interface SeasonalUpdatesModalProps {
  profile: PlayerProfile;
  lang: Language;
  activeSeason: SeasonalEvent;
  isAdmin: boolean;
  onLaunchSeasonal: () => void;
  onSeasonPublished: (next: SeasonalEvent) => void;
  onClose: () => void;
}

export function SeasonalUpdatesModal({
  profile,
  lang,
  activeSeason,
  isAdmin,
  onLaunchSeasonal,
  onSeasonPublished,
  onClose,
}: SeasonalUpdatesModalProps) {
  const t = getText(lang);
  const [releases, setReleases] = useState<ReleaseNote[]>([]);
  const [imgError, setImgError] = useState(false);

  // Admin seasonal publishing state
  const [titleAr, setTitleAr] = useState('');
  const [titleEn, setTitleEn] = useState('');
  const [descAr, setDescAr] = useState('');
  const [descEn, setDescEn] = useState('');
  const [modifier, setModifier] = useState<SeasonalModifier>('blood_moon');
  const [publishing, setPublishing] = useState(false);

  useEffect(() => {
    fetch('/api/updates')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data?.releases)) {
          setReleases(data.releases);
        }
      })
      .catch(() => {
        // Silent fallback
      });
  }, []);

  const isCompleted = profile.completedSeasons.includes(activeSeason.id);

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleAr.trim() || !titleEn.trim()) return;
    setPublishing(true);
    try {
      const nextEvent: SeasonalEvent = {
        id: `season_${Date.now()}`,
        titleAr: titleAr.trim(),
        titleEn: titleEn.trim(),
        descriptionAr: descAr.trim() || activeSeason.descriptionAr,
        descriptionEn: descEn.trim() || activeSeason.descriptionEn,
        modifier,
        rewardGems: 220,
        rewardXp: 800,
        isActive: true,
        versionTag: 'v1.5',
      };
      await publishSeasonalUpdate(nextEvent);
      onSeasonPublished(nextEvent);
      setTitleAr('');
      setTitleEn('');
      setDescAr('');
      setDescEn('');
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-3">
            <Flame className="h-5 w-5 text-rose-400" />
            <h2 className="text-xl font-bold text-white">{t.seasonalTitle}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 space-y-6">
          {/* Active Seasonal Banner Card */}
          <div className="relative overflow-hidden rounded-2xl border border-rose-900/50 bg-slate-950">
            <div className="relative h-48 sm:h-56 w-full overflow-hidden">
              {!imgError ? (
                <img
                  src={seasonalBannerUrl}
                  alt={lang === 'ar' ? activeSeason.titleAr : activeSeason.titleEn}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full bg-gradient-to-br from-rose-950 via-slate-950 to-slate-900" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D1320] via-[#0D1320]/60 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <div className="flex items-center gap-2 text-xs text-rose-300 font-semibold mb-1">
                  <span>{t.activeSeason}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">{activeSeason.versionTag}</span>
                  {isCompleted && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1 text-emerald-300">
                        <Check className="h-3.5 w-3.5" />
                        {t.completedBadge}
                      </span>
                    </>
                  )}
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white">
                  {lang === 'ar' ? activeSeason.titleAr : activeSeason.titleEn}
                </h3>
              </div>
            </div>

            <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-2">
                <p className="text-sm text-slate-300 leading-relaxed">
                  {lang === 'ar' ? activeSeason.descriptionAr : activeSeason.descriptionEn}
                </p>
                <div className="flex items-center gap-4 text-xs font-mono-num">
                  <span className="inline-flex items-center gap-1 text-sky-400 font-bold">
                    <Gem className="h-3.5 w-3.5" />+{activeSeason.rewardGems} {t.gems}
                  </span>
                  <span className="inline-flex items-center gap-1 text-emerald-300 font-bold">
                    <Sparkles className="h-3.5 w-3.5" />+{activeSeason.rewardXp} {t.xp}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={onLaunchSeasonal}
                className="flex min-h-[48px] shrink-0 items-center justify-center gap-2 rounded-xl bg-rose-600 px-5 py-3 text-sm font-bold text-white hover:bg-rose-500 transition-colors whitespace-nowrap"
              >
                <Play className="h-4 w-4" />
                <span>{t.startSeasonal}</span>
              </button>
            </div>
          </div>

          {/* Continuous Updates Feed */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Calendar className="h-4 w-4 text-slate-400" />
              <span>{t.patchNotes}</span>
            </h3>
            <div className="space-y-3">
              {releases.map((rel) => (
                <div
                  key={rel.version}
                  className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-bold text-white text-sm">
                      {lang === 'ar' ? rel.titleAr : rel.titleEn}
                    </span>
                    <span className="font-mono-num">
                      {rel.version} · {rel.date}
                    </span>
                  </div>
                  <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                    {(lang === 'ar' ? rel.notesAr : rel.notesEn).map((note, idx) => (
                      <li key={idx}>{note}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Admin Seasonal Publishing Form */}
          {isAdmin && (
            <form
              onSubmit={handlePublish}
              className="rounded-xl border border-amber-800/40 bg-slate-950/60 p-5 space-y-3"
            >
              <div className="flex items-center gap-2 text-sm font-bold text-amber-300">
                <PlusCircle className="h-4 w-4" />
                <span>{t.adminPublish}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  placeholder="عنوان الموسم بالعربية"
                  className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white"
                />
                <input
                  type="text"
                  required
                  value={titleEn}
                  onChange={(e) => setTitleEn(e.target.value)}
                  placeholder="Season Title (English)"
                  className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white"
                />
                <input
                  type="text"
                  value={descAr}
                  onChange={(e) => setDescAr(e.target.value)}
                  placeholder="وصف التحدي بالعربية"
                  className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white"
                />
                <select
                  value={modifier}
                  onChange={(e) => setModifier(e.target.value as SeasonalModifier)}
                  className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white"
                >
                  <option value="blood_moon">Blood Moon (+HP Foes / +Gems)</option>
                  <option value="low_gravity">Low Gravity Moon Leaps</option>
                  <option value="shadow_rush">Shadow Rush (Fast Dash)</option>
                </select>
              </div>
              <button
                type="submit"
                disabled={publishing}
                className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-amber-500 px-5 py-2 text-sm font-bold text-slate-950 hover:bg-amber-400 transition-colors"
              >
                <span>{t.publishBtn}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
