import { Lock, Play, Star, Swords, X } from 'lucide-react';
import { STAGES } from '../data/gameCatalog';
import { getText } from '../i18n/translations';
import type { Language, PlayerProfile } from '../types/game';

interface StoryStageModalProps {
  profile: PlayerProfile;
  lang: Language;
  onSelectStage: (stageId: string) => void;
  onClose: () => void;
}

export function StoryStageModal({
  profile,
  lang,
  onSelectStage,
  onClose,
}: StoryStageModalProps) {
  const t = getText(lang);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-white">{t.chapters}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{t.tagline}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 space-y-4">
          {STAGES.map((stage) => {
            const unlocked = stage.order <= profile.highestStage;
            return (
              <div
                key={stage.id}
                className={`flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border p-5 transition-colors ${
                  unlocked
                    ? 'border-slate-800 bg-slate-900/50 hover:border-slate-700'
                    : 'border-slate-900 bg-slate-950/50 opacity-60'
                }`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span className="font-mono-num text-rose-400 font-semibold">
                      0{stage.order}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{lang === 'ar' ? stage.challengeTagAr : stage.challengeTagEn}</span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-0.5 text-amber-400">
                      {Array.from({ length: stage.difficulty }).map((_, i) => (
                        <Star key={i} className="h-3 w-3 fill-amber-400" />
                      ))}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white">
                    {lang === 'ar' ? stage.titleAr : stage.titleEn}
                  </h3>

                  <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
                    {lang === 'ar' ? stage.storyIntroAr : stage.storyIntroEn}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-400">
                    <span className="inline-flex items-center gap-1.5 text-rose-300">
                      <Swords className="h-3.5 w-3.5" />
                      {t.bossLabel}: {lang === 'ar' ? stage.bossNameAr : stage.bossNameEn}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-num text-sky-400">
                      +{stage.rewardGems} {t.gems}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-num text-emerald-300">
                      +{stage.rewardXp} {t.xp}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  {unlocked ? (
                    <button
                      type="button"
                      onClick={() => onSelectStage(stage.id)}
                      className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-rose-500 transition-colors whitespace-nowrap"
                    >
                      <Play className="h-4 w-4" />
                      <span>{t.playStage}</span>
                    </button>
                  ) : (
                    <div className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900/70 px-5 py-2.5 text-sm font-semibold text-slate-500 whitespace-nowrap">
                      <Lock className="h-4 w-4" />
                      <span>{t.locked}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
