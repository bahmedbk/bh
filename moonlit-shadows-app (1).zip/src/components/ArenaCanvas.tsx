import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Flame,
  Gem,
  LogOut,
  Pause,
  Play,
  RotateCcw,
  Skull,
  Smartphone,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  ARENA_GUNS,
  ARENA_KILL_TARGET,
  ARENA_MATCH_DURATION_SEC,
  ArenaEngine,
} from '../engine/ArenaEngine';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import { multiplayerClient } from '../lib/multiplayerSocket';
import type {
  ArenaHudSnapshot,
  EffectsQuality,
  Language,
  MatchResult,
  MultiplayerRoomState,
  PlayerProfile,
  RoomPlayer,
  TouchDisplayMode,
} from '../types/game';
import { DualStickControls } from './DualStickControls';

interface ArenaCanvasProps {
  profile: PlayerProfile;
  lang: Language;
  multiplayerRoom: MultiplayerRoomState | null;
  localPlayerId: string;
  touchMode: TouchDisplayMode;
  effectsQuality: EffectsQuality;
  onMatchComplete: (result: MatchResult) => void;
  onExitToTitle: () => void;
}

export function ArenaCanvas({
  profile,
  lang,
  multiplayerRoom,
  localPlayerId,
  touchMode,
  effectsQuality,
  onMatchComplete,
  onExitToTitle,
}: ArenaCanvasProps) {
  const t = getText(lang);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const radarCanvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<ArenaEngine | null>(null);
  const peersMapRef = useRef<Map<string, RoomPlayer>>(new Map());

  const [paused, setPaused] = useState(false);
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [muted, setMuted] = useState(soundEngine.isMuted());
  const [runSeed, setRunSeed] = useState(0);
  const [touchVisible, setTouchVisible] = useState(() => {
    if (touchMode === 'on') return true;
    if (touchMode === 'off') return false;
    return typeof window !== 'undefined'
      ? window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 900
      : false;
  });

  const [hud, setHud] = useState<ArenaHudSnapshot>({
    hp: 110 + profile.skillHealth * 12,
    maxHp: 110 + profile.skillHealth * 12,
    fuel: 100,
    maxFuel: 100,
    gunId: 'shuriken_smg',
    ammo: 24,
    maxAmmo: 24,
    reloading: false,
    reloadProgress: 1,
    activeWeaponSlot: 0,
    weapons: [
      {
        gunId: 'shuriken_smg',
        ammo: 24,
        maxAmmo: 24,
        reloading: false,
        reloadProgress: 1,
      },
      null,
    ],
    grenades: 3,
    kills: 0,
    deaths: 0,
    killTarget: ARENA_KILL_TARGET,
    timeRemainingSec: ARENA_MATCH_DURATION_SEC,
    respawnRemainingSec: 0,
    killFeed: [],
    standings: [],
  });

  useEffect(() => {
    engineRef.current?.setEffectsQuality(effectsQuality);
  }, [effectsQuality]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const updateSize = () => {
      canvas.width = container.clientWidth || window.innerWidth;
      canvas.height = container.clientHeight || Math.max(240, window.innerHeight - 60);
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(container);

    const isOnline = Boolean(multiplayerRoom);
    const engine = new ArenaEngine(
      canvas,
      profile,
      lang,
      localPlayerId,
      isOnline,
      {
        onHudUpdate: (snap) => setHud(snap),
        onMatchComplete: (res) => {
          setMatchResult(res);
          onMatchComplete(res);
        },
        onLocalStateSync: isOnline
          ? (sync) => {
              multiplayerClient.sendPlayerState({
                ...sync,
                weapon: profile.equippedWeapon,
                skin: profile.equippedSkin,
              });
            }
          : undefined,
        onArenaShot: isOnline
          ? (x, y, angle, gunId) => multiplayerClient.sendArenaShot(x, y, angle, gunId)
          : undefined,
        onArenaGrenade: isOnline
          ? (x, y, vx, vy) => multiplayerClient.sendArenaGrenade(x, y, vx, vy)
          : undefined,
        onArenaHit: isOnline
          ? (targetId, dmg, weaponLabel) => multiplayerClient.sendArenaHit(targetId, dmg, weaponLabel)
          : undefined,
        onLocalKilled: isOnline
          ? (killerId, weaponLabel, droppedGun) =>
              multiplayerClient.sendArenaKill(killerId, weaponLabel, droppedGun)
          : undefined,
        onArenaTimeExpired: isOnline ? () => multiplayerClient.sendArenaFinish() : undefined,
      },
      effectsQuality
    );

    engine.setRadarCanvas(radarCanvasRef.current);
    engineRef.current = engine;
    engine.start();

    if (multiplayerRoom) {
      for (const p of multiplayerRoom.players) {
        if (p.id !== localPlayerId) {
          peersMapRef.current.set(p.id, p);
        }
      }
      engine.setPeers(Array.from(peersMapRef.current.values()));

      multiplayerClient.setHandlers({
        onPeerState: (peer) => {
          if (peer.id !== localPlayerId) {
            peersMapRef.current.set(peer.id, peer);
            engine.setPeers(Array.from(peersMapRef.current.values()));
          }
        },
        onArenaShot: (payload) => {
          if (payload.shooterId !== localPlayerId) {
            engine.addRemoteShot(
              payload.x,
              payload.y,
              payload.angle,
              payload.gunId,
              payload.shooterId
            );
          }
        },
        onArenaGrenade: (payload) => {
          if (payload.throwerId !== localPlayerId) {
            engine.addRemoteGrenade(
              payload.x,
              payload.y,
              payload.vx,
              payload.vy,
              payload.throwerId
            );
          }
        },
        onArenaHit: (payload) => {
          if (payload.targetId === localPlayerId) {
            engine.applyRemoteHit(payload.damage, payload.attackerId, payload.weaponLabel);
          }
        },
        onArenaKill: (payload) => {
          engine.pushKillEvent(
            payload.killerName,
            payload.victimName,
            payload.weaponLabel,
            payload.killerId,
            payload.droppedGun,
            payload.victimX,
            payload.victimY
          );
          for (const p of payload.room.players) {
            if (p.id !== localPlayerId) {
              peersMapRef.current.set(p.id, p);
            }
          }
          engine.setPeers(Array.from(peersMapRef.current.values()));
        },
        onMatchVictory: (payload) => {
          if (payload.mode === 'arena') {
            engine.finishOnlineMatch(payload.room.players, payload.winnerId, payload.winReason);
          }
        },
      });
    }

    return () => {
      ro.disconnect();
      engine.setRadarCanvas(null);
      engine.stop();
      engineRef.current = null;
      peersMapRef.current.clear();
    };
  }, [runSeed, multiplayerRoom?.code]);

  useEffect(() => {
    const engine = engineRef.current;
    if (engine) {
      engine.setPaused(paused || Boolean(matchResult));
    }
    if (!paused && !matchResult) {
      soundEngine.startArenaMusic();
    } else {
      soundEngine.stopArenaMusic();
    }
  }, [paused, matchResult]);

  useEffect(() => {
    return () => {
      soundEngine.stopArenaMusic();
    };
  }, []);

  useEffect(() => {
    const keys = { left: false, right: false, jet: false };
    const syncMove = () => {
      engineRef.current?.setKeyMove(keys.left, keys.right, keys.jet);
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (!matchResult) setPaused((p) => !p);
        return;
      }
      if (paused || matchResult) return;

      const c = e.code;
      if (c === 'KeyA' || c === 'ArrowLeft') {
        keys.left = true;
        syncMove();
      } else if (c === 'KeyD' || c === 'ArrowRight') {
        keys.right = true;
        syncMove();
      } else if (c === 'KeyW' || c === 'ArrowUp' || c === 'Space') {
        e.preventDefault();
        keys.jet = true;
        syncMove();
      } else if (c === 'KeyG' && !e.repeat) {
        engineRef.current?.throwGrenade();
      } else if (c === 'KeyR' && !e.repeat) {
        engineRef.current?.triggerReload();
      } else if ((c === 'KeyQ' || c === 'KeyF') && !e.repeat) {
        engineRef.current?.triggerMelee();
      } else if ((c === 'KeyE' || c === 'Tab') && !e.repeat) {
        e.preventDefault();
        engineRef.current?.switchWeaponSlot();
      } else if (c === 'Digit1' && !e.repeat) {
        engineRef.current?.switchWeaponSlot(0);
      } else if (c === 'Digit2' && !e.repeat) {
        engineRef.current?.switchWeaponSlot(1);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const c = e.code;
      if (c === 'KeyA' || c === 'ArrowLeft') {
        keys.left = false;
        syncMove();
      } else if (c === 'KeyD' || c === 'ArrowRight') {
        keys.right = false;
        syncMove();
      } else if (c === 'KeyW' || c === 'ArrowUp' || c === 'Space') {
        keys.jet = false;
        syncMove();
      }
    };

    const onBlur = () => {
      keys.left = false;
      keys.right = false;
      keys.jet = false;
      syncMove();
      engineRef.current?.setFiring(false);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [paused, matchResult]);

  const toggleMute = () => {
    const next = !muted;
    soundEngine.setMuted(next);
    setMuted(next);
  };

  const mins = Math.floor(hud.timeRemainingSec / 60);
  const secs = hud.timeRemainingSec % 60;
  const timeText = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  const leader = hud.standings[0];
  const rivalNearWin = Boolean(!matchResult && leader && !leader.isLocal && leader.kills >= hud.killTarget - 2);
  const latestKill = hud.killFeed[0];

  return (
    <div className="flex h-full w-full flex-col overflow-hidden bg-[#070B14] select-none">
      {/* Slim Unified Command Bar completely above the battlefield */}
      <header
        title={!touchVisible ? t.arenaControlsHint : undefined}
        className="shrink-0 border-b border-slate-800/90 bg-[#0A0F1A] px-2.5 py-1.5"
      >
        <div className="flex items-center justify-between gap-2 overflow-x-auto">
          {/* Vitals: HP, Jetpack Fuel & Grenades */}
          <div className="flex shrink-0 items-center gap-2.5 rounded-lg border border-slate-800/80 bg-slate-950/85 px-2.5 py-1">
            <div className="w-20 sm:w-24">
              <div className="flex items-center justify-between text-[10px] font-bold">
                <span className="text-slate-300">{t.hp}</span>
                <span className="font-mono-num text-rose-300">
                  {hud.hp}/{hud.maxHp}
                </span>
              </div>
              <div className="mt-0.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-rose-600 transition-[width] duration-100"
                  style={{ width: `${Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100))}%` }}
                />
              </div>
            </div>

            <div className="w-16 sm:w-20 border-s border-slate-800 ps-2">
              <div className="flex items-center justify-between text-[10px] font-bold">
                <span className="text-slate-400">{t.fuelLabel}</span>
                <span className="font-mono-num text-sky-300">{hud.fuel}%</span>
              </div>
              <div className="mt-0.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-sky-400 transition-[width] duration-75"
                  style={{ width: `${Math.max(0, Math.min(100, hud.fuel))}%` }}
                />
              </div>
            </div>

            <div className="flex items-center gap-1 border-s border-slate-800 ps-2 text-xs font-bold text-amber-300">
              <Flame className="h-3.5 w-3.5 shrink-0" />
              <span className="font-mono-num text-white">{hud.grenades}</span>
            </div>
          </div>

          {/* Dual Weapon Slots (Slot 1 & Slot 2) */}
          <div className="flex shrink-0 items-center gap-1.5">
            {([0, 1] as const).map((slotIdx) => {
              const slot = hud.weapons[slotIdx];
              const isActive = hud.activeWeaponSlot === slotIdx;
              if (!slot) {
                return (
                  <div
                    key={slotIdx}
                    className="flex h-10 min-w-[96px] items-center justify-between gap-2 rounded-lg border border-dashed border-slate-800 bg-slate-950/50 px-2.5 text-[10px] text-slate-500"
                  >
                    <span className="font-mono-num font-bold">{slotIdx + 1}</span>
                    <span className="truncate">{t.emptySlotLabel}</span>
                  </div>
                );
              }
              const spec = ARENA_GUNS[slot.gunId];
              return (
                <button
                  key={slotIdx}
                  type="button"
                  onClick={() => engineRef.current?.switchWeaponSlot(slotIdx)}
                  className={`flex h-10 min-w-[116px] sm:min-w-[132px] flex-col justify-center rounded-lg border px-2.5 text-start transition-colors ${
                    isActive
                      ? 'border-amber-400/80 bg-slate-900 shadow-sm'
                      : 'border-slate-800 bg-slate-950/75 opacity-80 hover:opacity-100 hover:border-slate-600'
                  }`}
                >
                  <div className="flex w-full items-center justify-between gap-1.5 text-[10px] font-bold">
                    <span className="flex items-center gap-1 truncate text-slate-100">
                      <span
                        className="inline-block h-2 w-2 shrink-0 rounded-full"
                        style={{ backgroundColor: spec.color }}
                      />
                      <span className="font-mono-num text-slate-400">{slotIdx + 1}.</span>
                      <span className="truncate">{lang === 'ar' ? spec.nameAr : spec.nameEn}</span>
                    </span>
                  </div>
                  <div className="mt-0.5 flex w-full items-center justify-between gap-2 text-[10px]">
                    <div className="h-1 flex-1 overflow-hidden rounded-full bg-slate-800">
                      <div
                        className="h-full transition-[width] duration-75"
                        style={{
                          width: `${
                            slot.reloading
                              ? Math.round(slot.reloadProgress * 100)
                              : Math.round((slot.ammo / Math.max(1, slot.maxAmmo)) * 100)
                          }%`,
                          backgroundColor: slot.reloading ? '#F59E0B' : spec.color,
                        }}
                      />
                    </div>
                    <span className="font-mono-num font-bold text-amber-300">
                      {slot.reloading ? t.reloadingLabel : `${slot.ammo}/${slot.maxAmmo}`}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Match Clock, 10-Kill Race & Compact Kill Feed */}
          <div className="flex shrink-0 items-center gap-2.5 rounded-lg border border-slate-800/80 bg-slate-950/85 px-2.5 py-1 text-[11px] font-bold">
            <span className="font-mono-num text-sm text-white">{timeText}</span>
            <span className="text-slate-700">|</span>
            <span className="font-mono-num text-emerald-300">
              {t.killsLabel} {hud.kills}/{hud.killTarget}
            </span>
            <span className="font-mono-num text-rose-300 hidden md:inline">
              {t.deathsLabel} {hud.deaths}
            </span>

            {leader && (
              <div className="hidden sm:flex items-center gap-1.5 border-s border-slate-800 ps-2">
                <span className="max-w-[78px] truncate text-[10px] text-slate-300">{leader.name}</span>
                <div className="h-1.5 w-12 overflow-hidden rounded-full bg-slate-800">
                  <div
                    className={`h-full transition-[width] duration-150 ${
                      leader.isLocal ? 'bg-sky-400' : 'bg-rose-500'
                    }`}
                    style={{
                      width: `${Math.min(100, (leader.kills / Math.max(1, hud.killTarget)) * 100)}%`,
                    }}
                  />
                </div>
                <span className="font-mono-num text-[10px] text-sky-300">
                  {leader.kills}/{hud.killTarget}
                </span>
              </div>
            )}

            {rivalNearWin && (
              <span
                title={t.arenaDangerLead}
                className="flex items-center gap-1 rounded border border-rose-500/60 bg-rose-950/75 px-1.5 py-0.5 text-[10px] text-rose-200"
              >
                <AlertTriangle className="h-3 w-3 text-rose-400" />
                <span className="hidden xl:inline">{t.arenaDangerLead}</span>
              </span>
            )}

            {latestKill && (
              <div className="hidden xl:flex items-center gap-1 border-s border-slate-800 ps-2 text-[10px] font-normal text-slate-300 max-w-[205px] truncate">
                <span className="font-bold text-sky-300 truncate">{latestKill.killerName}</span>
                <span className="text-rose-400">⚔</span>
                <span className="font-bold text-rose-300 truncate">{latestKill.victimName}</span>
              </div>
            )}
          </div>

          {/* Embedded Mini-Radar & Utility Controls */}
          <div className="flex shrink-0 items-center gap-1.5">
            <canvas
              ref={radarCanvasRef}
              width={118}
              height={42}
              className="shrink-0 rounded-md border border-slate-700/80 bg-[#070B14]"
            />

            <button
              type="button"
              onClick={() => setTouchVisible((v) => !v)}
              title={touchVisible ? t.touchToggleOff : t.touchToggleOn}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700/80 bg-slate-950/85 text-slate-200 hover:border-slate-500 transition-colors"
            >
              <Smartphone className={`h-4 w-4 ${touchVisible ? 'text-rose-400' : 'text-slate-400'}`} />
            </button>

            <button
              type="button"
              onClick={toggleMute}
              title={muted ? t.unmuteAudio : t.muteAudio}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700/80 bg-slate-950/85 text-slate-200 hover:border-slate-500 transition-colors"
            >
              {muted ? <VolumeX className="h-4 w-4 text-slate-400" /> : <Volume2 className="h-4 w-4" />}
            </button>

            <button
              type="button"
              onClick={() => setPaused((p) => !p)}
              title={t.pause}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700/80 bg-slate-950/85 text-slate-200 hover:border-rose-500/70 transition-colors"
            >
              <Pause className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Unobstructed Full-Span Mountain Battlefield */}
      <div ref={containerRef} className="relative flex-1 min-h-0 w-full overflow-hidden">
        <canvas
          ref={canvasRef}
          onMouseMove={(e) => {
            engineRef.current?.setMouseScreenPos(e.clientX, e.clientY);
          }}
          onMouseDown={(e) => {
            if (e.button === 0) {
              engineRef.current?.setMouseScreenPos(e.clientX, e.clientY);
              engineRef.current?.setFiring(true);
            } else if (e.button === 2) {
              engineRef.current?.throwGrenade();
            }
          }}
          onMouseUp={(e) => {
            if (e.button === 0) engineRef.current?.setFiring(false);
          }}
          onWheel={() => {
            if (!paused && !matchResult) {
              engineRef.current?.switchWeaponSlot();
            }
          }}
          onContextMenu={(e) => e.preventDefault()}
          className="block h-full w-full cursor-crosshair"
        />

        {/* Mobile Dual-Stick Overlay (only when touch enabled) */}
        {touchVisible && !paused && !matchResult && (
          <DualStickControls
            engineRef={engineRef}
            lang={lang}
            grenades={hud.grenades}
            fuel={hud.fuel}
          />
        )}

        {/* Respawn Countdown Banner (only while dead) */}
        {hud.respawnRemainingSec > 0 && !matchResult && (
          <div className="pointer-events-none fixed inset-0 z-20 flex items-center justify-center">
            <div className="rounded-2xl border border-amber-700/70 bg-slate-950/90 px-7 py-4 text-center shadow-2xl">
              <div className="text-xl font-bold text-white font-mono-num">
                {t.respawnIn} {hud.respawnRemainingSec}s
              </div>
              <div className="mt-1 text-xs font-medium text-slate-300">{t.arenaRespawningNote}</div>
            </div>
          </div>
        )}
      </div>

      {/* Pause Modal */}
      {paused && !matchResult && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-[#0D1320] p-6 space-y-4 shadow-2xl text-center">
            <h2 className="text-2xl font-bold text-white">{t.pause}</h2>
            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={() => setPaused(false)}
                className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
              >
                <Play className="h-4 w-4" />
                <span>{t.resume}</span>
              </button>
              {!multiplayerRoom && (
                <button
                  type="button"
                  onClick={() => {
                    setPaused(false);
                    setMatchResult(null);
                    setRunSeed((s) => s + 1);
                  }}
                  className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm font-semibold text-slate-200 hover:border-slate-500 transition-colors"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>{t.restart}</span>
                </button>
              )}
              <button
                type="button"
                onClick={onExitToTitle}
                className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl border border-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-400 hover:text-white transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>{t.returnTitle}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Match End Scoreboard Modal */}
      {matchResult && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/85 p-4">
          <div
            className={`w-full max-w-lg rounded-2xl border bg-[#0D1320] p-6 space-y-5 shadow-2xl ${
              matchResult.victory ? 'border-amber-500/60' : 'border-rose-700/60'
            }`}
          >
            <div className="flex items-center gap-3">
              {matchResult.victory ? (
                <Trophy className="h-8 w-8 text-amber-400 shrink-0" />
              ) : (
                <Skull className="h-8 w-8 text-rose-400 shrink-0" />
              )}
              <div>
                <h2
                  className={`text-2xl font-bold ${
                    matchResult.victory ? 'text-amber-300' : 'text-rose-300'
                  }`}
                >
                  {matchResult.victory ? t.arenaVictoryTitle : t.arenaDefeatTitle}
                </h2>
                <p className="text-xs text-slate-300 mt-0.5">
                  {matchResult.victory
                    ? hud.winReason === 'target_reached'
                      ? t.arenaWinTargetReason
                      : t.arenaWinTimeReason
                    : hud.winReason === 'target_reached'
                    ? t.arenaLoseTargetReason
                    : t.arenaLoseTimeReason}
                  {' · '}
                  {t.arenaWinnerLabel}:{' '}
                  <strong className="text-white">
                    {hud.winnerName || hud.standings[0]?.name || profile.displayName}
                  </strong>
                </p>
              </div>
            </div>

            {/* Standings Table */}
            <div className="space-y-2">
              {hud.standings.map((entry, idx) => (
                <div
                  key={entry.id}
                  className={`flex items-center justify-between rounded-xl border px-4 py-2.5 text-sm ${
                    entry.isLocal
                      ? 'border-sky-500/60 bg-sky-950/35 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono-num font-bold text-amber-300">#{idx + 1}</span>
                    <span className="font-bold">{entry.name}</span>
                  </div>
                  <div className="flex items-center gap-4 font-mono-num text-xs">
                    <span className="text-emerald-300">
                      {t.killsLabel}: {entry.kills}
                    </span>
                    <span className="text-rose-300">
                      {t.deathsLabel}: {entry.deaths}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Rewards */}
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
                <div className="text-xs text-slate-400">{t.gemsEarned}</div>
                <div className="mt-1 flex items-center justify-center gap-1.5 font-mono-num text-lg font-bold text-sky-400">
                  <Gem className="h-4 w-4" />
                  <span>+{matchResult.gemsEarned}</span>
                </div>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
                <div className="text-xs text-slate-400">{t.xpEarned}</div>
                <div className="mt-1 font-mono-num text-lg font-bold text-emerald-300">
                  +{matchResult.xpEarned}
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              {!multiplayerRoom && (
                <button
                  type="button"
                  onClick={() => {
                    setMatchResult(null);
                    setPaused(false);
                    setRunSeed((s) => s + 1);
                  }}
                  className="flex-1 flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-rose-500 transition-colors"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>{t.playAgain}</span>
                </button>
              )}
              <button
                type="button"
                onClick={onExitToTitle}
                className="flex-1 flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm font-semibold text-slate-200 hover:border-slate-500 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>{t.returnTitle}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
