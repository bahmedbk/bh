import { ArrowLeft, ArrowRight, ArrowUp, Flame, Sword, Wind } from 'lucide-react';
import type { NinjaEngine } from '../engine/NinjaEngine';
import { getText } from '../i18n/translations';
import type { Language } from '../types/game';

interface TouchControlsProps {
  engineRef: React.RefObject<NinjaEngine | null>;
  lang: Language;
  dashCharge: number;
  specialCharge: number;
}

export function TouchControls({
  engineRef,
  lang,
  dashCharge,
  specialCharge,
}: TouchControlsProps) {
  const t = getText(lang);

  const btnBase =
    'touch-control-zone pointer-events-auto flex flex-col items-center justify-center rounded-2xl border border-slate-400/25 bg-slate-950/70 text-slate-100 active:scale-95 active:bg-rose-600/80 transition-transform duration-100 select-none shadow-lg';

  return (
    <div
      dir="ltr"
      className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between px-4 pb-4 sm:px-6 sm:pb-6"
    >
      {/* Left Thumb Zone: Directional Movement */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          aria-label="Move Left"
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.setInput({ left: true });
          }}
          onPointerUp={() => engineRef.current?.setInput({ left: false })}
          onPointerLeave={() => engineRef.current?.setInput({ left: false })}
          onPointerCancel={() => engineRef.current?.setInput({ left: false })}
          className={`${btnBase} h-14 w-14 sm:h-16 sm:w-16`}
        >
          <ArrowLeft className="h-6 w-6" />
        </button>

        <button
          type="button"
          aria-label="Move Right"
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.setInput({ right: true });
          }}
          onPointerUp={() => engineRef.current?.setInput({ right: false })}
          onPointerLeave={() => engineRef.current?.setInput({ right: false })}
          onPointerCancel={() => engineRef.current?.setInput({ right: false })}
          className={`${btnBase} h-14 w-14 sm:h-16 sm:w-16`}
        >
          <ArrowRight className="h-6 w-6" />
        </button>
      </div>

      {/* Right Thumb Zone: Combat & Agility Arc */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
        <button
          type="button"
          aria-label={t.touchSkill}
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.triggerSpecial();
          }}
          className={`${btnBase} relative h-14 w-14 sm:h-15 sm:w-15 ${
            specialCharge >= 0.99 ? 'border-amber-400/70 text-amber-300' : 'opacity-65'
          }`}
        >
          <Flame className="h-5 w-5" />
          <span className="mt-0.5 text-[10px] font-semibold">{t.touchSkill}</span>
        </button>

        <button
          type="button"
          aria-label={t.touchJump}
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.triggerJump();
          }}
          onPointerUp={() => engineRef.current?.releaseJump()}
          onPointerCancel={() => engineRef.current?.releaseJump()}
          className={`${btnBase} h-14 w-14 sm:h-15 sm:w-15 border-slate-300/35`}
        >
          <ArrowUp className="h-5 w-5" />
          <span className="mt-0.5 text-[10px] font-semibold">{t.touchJump}</span>
        </button>

        <button
          type="button"
          aria-label={t.touchDash}
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.triggerDash();
          }}
          className={`${btnBase} h-14 w-14 sm:h-15 sm:w-15 ${
            dashCharge >= 0.99 ? 'border-sky-400/60 text-sky-200' : 'opacity-65'
          }`}
        >
          <Wind className="h-5 w-5" />
          <span className="mt-0.5 text-[10px] font-semibold">{t.touchDash}</span>
        </button>

        <button
          type="button"
          aria-label={t.touchAttack}
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.triggerAttack();
          }}
          className={`${btnBase} h-14 w-14 sm:h-15 sm:w-15 border-rose-500/70 bg-rose-950/75 text-rose-100`}
        >
          <Sword className="h-5 w-5" />
          <span className="mt-0.5 text-[10px] font-semibold">{t.touchAttack}</span>
        </button>
      </div>
    </div>
  );
}
