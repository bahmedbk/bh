import { useEffect, useState } from 'react';
import { Crown, RefreshCw, Trophy, X } from 'lucide-react';
import { WEAPONS } from '../data/gameCatalog';
import { getText } from '../i18n/translations';
import { fetchGlobalLeaderboard } from '../lib/firebase';
import type { Language, LeaderboardEntry } from '../types/game';

interface LeaderboardModalProps {
  currentUid?: string;
  lang: Language;
  onClose: () => void;
}

export function LeaderboardModal({
  currentUid,
  lang,
  onClose,
}: LeaderboardModalProps) {
  const t = getText(lang);
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const list = await fetchGlobalLeaderboard();
      setEntries(list);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to load leaderboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0D1320] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-3">
            <Trophy className="h-5 w-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">{t.leaderboard}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={load}
              aria-label="Refresh"
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.close}
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto p-6">
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="h-14 w-full animate-pulse rounded-xl bg-slate-900/80 border border-slate-800/50"
                />
              ))}
            </div>
          ) : errorMsg ? (
            <div className="rounded-xl border border-rose-900/50 bg-rose-950/20 p-6 text-center text-sm text-rose-200">
              {errorMsg}
            </div>
          ) : entries.length === 0 ? (
            <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-10 text-center text-sm text-slate-400">
              {t.noLeaderboard}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-xs text-slate-400">
                    <th className="py-3 px-3 text-start">{t.rank}</th>
                    <th className="py-3 px-3 text-start">{t.player}</th>
                    <th className="py-3 px-3 text-start">{t.weapon}</th>
                    <th className="py-3 px-3 text-start">{t.level}</th>
                    <th className="py-3 px-3 text-start">{t.chapter}</th>
                    <th className="py-3 px-3 text-end">{t.score}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {entries.map((row, idx) => {
                    const isSelf = currentUid && row.uid === currentUid;
                    const weaponObj = WEAPONS.find((w) => w.id === row.equippedWeapon) || WEAPONS[0];
                    return (
                      <tr
                        key={row.uid}
                        className={isSelf ? 'bg-rose-950/25' : 'hover:bg-slate-900/40'}
                      >
                        <td className="py-3.5 px-3 font-mono-num font-bold">
                          <span className="inline-flex items-center gap-1.5">
                            {idx === 0 && <Crown className="h-4 w-4 text-amber-400" />}
                            <span className={idx < 3 ? 'text-amber-300' : 'text-slate-400'}>
                              #{idx + 1}
                            </span>
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-semibold text-white">
                          {row.displayName}
                        </td>
                        <td className="py-3.5 px-3 text-slate-300">
                          {lang === 'ar' ? weaponObj.nameAr : weaponObj.nameEn}
                        </td>
                        <td className="py-3.5 px-3 font-mono-num text-emerald-300">
                          {row.level}
                        </td>
                        <td className="py-3.5 px-3 font-mono-num text-slate-300">
                          {row.highestStage}
                        </td>
                        <td className="py-3.5 px-3 text-end font-mono-num font-bold text-white">
                          {row.score.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
