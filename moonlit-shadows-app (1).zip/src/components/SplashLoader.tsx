import { useEffect, useState } from 'react';
import { getText } from '../i18n/translations';
import type { Language } from '../types/game';

interface SplashLoaderProps {
  lang: Language;
  onComplete: () => void;
}

const BOOT_DURATION_MS = 4200;

export function SplashLoader({ lang, onComplete }: SplashLoaderProps) {
  const t = getText(lang);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'studio' | 'loading' | 'fadeout'>('studio');

  useEffect(() => {
    const start = performance.now();
    let rafId = 0;
    let doneTimeout: number | undefined;

    const tick = (now: number) => {
      const elapsed = now - start;
      const ratio = Math.min(1, elapsed / BOOT_DURATION_MS);

      if (elapsed < 1350) {
        setPhase('studio');
      } else if (elapsed < BOOT_DURATION_MS - 350) {
        setPhase('loading');
      } else {
        setPhase('fadeout');
      }

      // Smooth non-linear game-engine loading progress curve
      const loadRatio = Math.max(0, Math.min(1, (elapsed - 1100) / (BOOT_DURATION_MS - 1450)));
      const eased = 1 - Math.pow(1 - loadRatio, 2.1);
      setProgress(Math.round(eased * 100));

      if (ratio < 1) {
        rafId = requestAnimationFrame(tick);
      } else {
        doneTimeout = window.setTimeout(onComplete, 120);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafId);
      if (doneTimeout !== undefined) clearTimeout(doneTimeout);
    };
  }, [onComplete]);

  const statusText =
    progress < 32
      ? t.loadingEngine
      : progress < 68
      ? t.loadingWorld
      : progress < 95
      ? t.loadingAudio
      : t.loadingReady;

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#06080F] px-6 transition-opacity duration-300 ${
        phase === 'fadeout' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Subtle Moonlit Horizon Vignette */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 42%, rgba(225, 29, 72, 0.14) 0%, rgba(15, 23, 42, 0.45) 45%, #06080F 85%)',
        }}
      />

      {/* Studio Emblem -> Game Title Lockup */}
      <div className="relative z-10 flex w-full max-w-md flex-col items-center text-center">
        <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-2xl border border-slate-800/90 bg-[#0B101C] shadow-2xl">
          <svg
            width="60"
            height="60"
            viewBox="0 0 48 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <circle cx="24" cy="24" r="21" stroke="#E2E8F0" strokeOpacity="0.22" strokeWidth="1.4" />
            <path
              d="M28.5 9.5C21.2 10.6 15.5 16.9 15.5 24.5C15.5 32.1 21.2 38.4 28.5 39.5C22.4 39.9 12 34.4 12 24.5C12 14.6 22.4 9.1 28.5 9.5Z"
              fill="#F1F5F9"
            />
            <path
              d="M13 35L36 12M36 12L30.5 12.6M36 12L35.4 17.5"
              stroke="#E11D48"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {phase === 'studio' ? (
          <div className="font-display-en text-xs font-bold tracking-[0.34em] text-rose-400 uppercase">
            {t.studioName}
          </div>
        ) : (
          <div className="w-full space-y-5 animate-[fadeIn_0.35s_ease-out]">
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                {t.gameTitle}
              </h1>
            </div>

            <div className="space-y-2.5 pt-2">
              <div className="h-2 w-full overflow-hidden rounded-full border border-slate-800 bg-slate-950">
                <div
                  className="h-full bg-gradient-to-r from-rose-600 via-rose-500 to-amber-400 transition-[width] duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>{statusText}</span>
                <span className="font-mono-num font-bold text-slate-200">{progress}%</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
