import { X } from 'lucide-react';
import { soundEngine } from '../engine/audio';
import { getText } from '../i18n/translations';
import type { EffectsQuality, GameSettings, Language, TouchDisplayMode } from '../types/game';
import { MusicChannelIcon, SettingsGearIcon, SystemSoundIcon } from './GameIcons';

interface GameSettingsModalProps {
  settings: GameSettings;
  lang: Language;
  onUpdateSettings: (next: GameSettings) => void;
  onChangeLanguage: (nextLang: Language) => void;
  onResetDefaults: () => void;
  onClose: () => void;
}

export function GameSettingsModal({
  settings,
  lang,
  onUpdateSettings,
  onChangeLanguage,
  onResetDefaults,
  onClose,
}: GameSettingsModalProps) {
  const t = getText(lang);

  const musicPct = settings.musicMuted ? 0 : Math.round(settings.musicVolume * 100);
  const sfxPct = settings.sfxMuted ? 0 : Math.round(settings.sfxVolume * 100);

  const handleMusicToggle = () => {
    const nextMuted = !settings.musicMuted;
    onUpdateSettings({
      ...settings,
      musicMuted: nextMuted,
      musicVolume: !nextMuted && settings.musicVolume === 0 ? 0.75 : settings.musicVolume,
    });
    soundEngine.playUiClick();
  };

  const handleSfxToggle = () => {
    const nextMuted = !settings.sfxMuted;
    const nextSettings: GameSettings = {
      ...settings,
      sfxMuted: nextMuted,
      sfxVolume: !nextMuted && settings.sfxVolume === 0 ? 0.9 : settings.sfxVolume,
    };
    onUpdateSettings(nextSettings);
    if (!nextMuted) {
      soundEngine.setSfxMuted(false);
      soundEngine.setSfxVolume(nextSettings.sfxVolume);
      soundEngine.playUiClick();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4">
      <div className="flex max-h-[90vh] w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0B111E] shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800/90 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900 text-rose-400">
              <SettingsGearIcon className="h-5 w-5" />
            </div>
            <h2 className="text-lg font-bold text-white">{t.settingsTitle}</h2>
          </div>

          <button
            type="button"
            onClick={() => {
              soundEngine.playUiClick();
              onClose();
            }}
            aria-label={t.close}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-600 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="space-y-6 overflow-y-auto px-6 py-5">
          {/* Audio Channels Section */}
          <section className="space-y-3.5">
            <h3 className="text-xs font-bold tracking-wider text-slate-400 uppercase">
              {t.audioSection}
            </h3>

            {/* Music Volume & Mute */}
            <div className="rounded-xl border border-slate-800/90 bg-slate-900/60 p-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={handleMusicToggle}
                    aria-label={t.musicAudio}
                    className={`flex h-10 w-10 items-center justify-center rounded-lg border transition-colors ${
                      settings.musicMuted || settings.musicVolume === 0
                        ? 'border-slate-700 bg-slate-950 text-slate-500'
                        : 'border-rose-500/40 bg-rose-950/40 text-rose-400'
                    }`}
                  >
                    <MusicChannelIcon
                      muted={settings.musicMuted || settings.musicVolume === 0}
                      className="h-5 w-5"
                    />
                  </button>
                  <span className="text-sm font-semibold text-slate-100">{t.musicAudio}</span>
                </div>

                <span className="font-mono-num text-sm font-bold text-slate-200 w-12 text-end">
                  {musicPct}%
                </span>
              </div>

              <input
                type="range"
                min={0}
                max={100}
                value={musicPct}
                aria-label={t.musicAudio}
                onChange={(e) => {
                  const val = Number(e.target.value) / 100;
                  onUpdateSettings({
                    ...settings,
                    musicVolume: val,
                    musicMuted: val === 0,
                  });
                }}
                className="h-2 w-full cursor-pointer appearance-none rounded-full bg-slate-800 accent-rose-500"
              />
            </div>

            {/* System & Combat SFX Volume & Mute */}
            <div className="rounded-xl border border-slate-800/90 bg-slate-900/60 p-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={handleSfxToggle}
                    aria-label={t.systemSfx}
                    className={`flex h-10 w-10 items-center justify-center rounded-lg border transition-colors ${
                      settings.sfxMuted || settings.sfxVolume === 0
                        ? 'border-slate-700 bg-slate-950 text-slate-500'
                        : 'border-sky-500/40 bg-sky-950/40 text-sky-400'
                    }`}
                  >
                    <SystemSoundIcon
                      muted={settings.sfxMuted || settings.sfxVolume === 0}
                      className="h-5 w-5"
                    />
                  </button>
                  <span className="text-sm font-semibold text-slate-100">{t.systemSfx}</span>
                </div>

                <span className="font-mono-num text-sm font-bold text-slate-200 w-12 text-end">
                  {sfxPct}%
                </span>
              </div>

              <input
                type="range"
                min={0}
                max={100}
                value={sfxPct}
                aria-label={t.systemSfx}
                onChange={(e) => {
                  const val = Number(e.target.value) / 100;
                  onUpdateSettings({
                    ...settings,
                    sfxVolume: val,
                    sfxMuted: val === 0,
                  });
                }}
                onPointerUp={() => soundEngine.playUiClick()}
                onKeyUp={() => soundEngine.playUiClick()}
                className="h-2 w-full cursor-pointer appearance-none rounded-full bg-slate-800 accent-sky-400"
              />
            </div>
          </section>

          {/* Controls & Display Section */}
          <section className="space-y-3.5">
            <h3 className="text-xs font-bold tracking-wider text-slate-400 uppercase">
              {t.displayControlsSection}
            </h3>

            {/* Language Selector */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800/90 bg-slate-900/60 px-4 py-3">
              <span className="text-sm font-semibold text-slate-100">{t.languageLabel}</span>
              <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1">
                {(['ar', 'en'] as Language[]).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      soundEngine.playUiClick();
                      onChangeLanguage(opt);
                    }}
                    className={`min-h-[36px] rounded-md px-3.5 text-xs font-bold transition-colors whitespace-nowrap ${
                      lang === opt
                        ? 'bg-rose-600 text-white'
                        : 'text-slate-400 hover:text-slate-100'
                    }`}
                  >
                    {opt === 'ar' ? 'العربية' : 'English'}
                  </button>
                ))}
              </div>
            </div>

            {/* Touch Controls Mode */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800/90 bg-slate-900/60 px-4 py-3">
              <span className="text-sm font-semibold text-slate-100">{t.touchControlsLabel}</span>
              <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1">
                {(
                  [
                    { id: 'auto', label: t.touchAuto },
                    { id: 'on', label: t.touchOn },
                    { id: 'off', label: t.touchOff },
                  ] as { id: TouchDisplayMode; label: string }[]
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playUiClick();
                      onUpdateSettings({ ...settings, touchMode: item.id });
                    }}
                    className={`min-h-[36px] rounded-md px-3 text-xs font-bold transition-colors whitespace-nowrap ${
                      settings.touchMode === item.id
                        ? 'bg-slate-800 text-white border border-slate-700'
                        : 'text-slate-400 hover:text-slate-100'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Effects Quality */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800/90 bg-slate-900/60 px-4 py-3">
              <span className="text-sm font-semibold text-slate-100">{t.effectsQualityLabel}</span>
              <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1">
                {(
                  [
                    { id: 'high', label: t.qualityHigh },
                    { id: 'balanced', label: t.qualityBalanced },
                  ] as { id: EffectsQuality; label: string }[]
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playUiClick();
                      onUpdateSettings({ ...settings, effectsQuality: item.id });
                    }}
                    className={`min-h-[36px] rounded-md px-3.5 text-xs font-bold transition-colors whitespace-nowrap ${
                      settings.effectsQuality === item.id
                        ? 'bg-slate-800 text-white border border-slate-700'
                        : 'text-slate-400 hover:text-slate-100'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-800/90 px-6 py-4">
          <button
            type="button"
            onClick={() => {
              soundEngine.playUiClick();
              onResetDefaults();
            }}
            className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300 hover:border-slate-500 hover:text-white transition-colors whitespace-nowrap"
          >
            {t.resetSettings}
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playUiClick();
              onClose();
            }}
            className="min-h-[42px] rounded-xl bg-rose-600 px-6 py-2 text-xs font-bold text-white hover:bg-rose-500 transition-colors whitespace-nowrap"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
}
