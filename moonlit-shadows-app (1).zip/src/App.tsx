import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { ArenaCanvas } from './components/ArenaCanvas';
import { DailyRewardsModal } from './components/DailyRewardsModal';
import { DojoShopModal } from './components/DojoShopModal';
import { GameCanvas } from './components/GameCanvas';
import { GameSettingsModal } from './components/GameSettingsModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MultiplayerModal } from './components/MultiplayerModal';
import { ProfileSetupModal } from './components/ProfileSetupModal';
import { SeasonalUpdatesModal } from './components/SeasonalUpdatesModal';
import { SplashLoader } from './components/SplashLoader';
import { StoryCutscene3D } from './components/StoryCutscene3D';
import { StoryStageModal } from './components/StoryStageModal';
import { TitleScreen } from './components/TitleScreen';
import {
  createDefaultProfile,
  DEFAULT_SEASONAL_EVENT,
  getXpForNextLevel,
} from './data/gameCatalog';
import { getText } from './i18n/translations';
import { soundEngine } from './engine/audio';
import {
  auth,
  fetchActiveSeasons,
  loadOrCreatePlayerProfile,
  savePlayerProfile,
  signInWithGooglePopup,
  signOutFirebase,
  upsertLeaderboardEntry,
} from './lib/firebase';
import { multiplayerClient } from './lib/multiplayerSocket';
import type {
  ActiveModal,
  GameSettings,
  Language,
  MatchResult,
  MultiplayerRoomState,
  PlayerProfile,
  SeasonalEvent,
  WeaponId,
} from './types/game';

const LOCAL_STORAGE_KEY = 'moonlit_shadows_guest_profile_v1';
const SETTINGS_STORAGE_KEY = 'moonlit_shadows_settings_v1';
const LANG_STORAGE_KEY = 'moonlit_shadows_lang_v1';
const PROFILE_DONE_PREFIX = 'moonlit_profile_setup_done_';

const DEFAULT_SETTINGS: GameSettings = {
  sfxVolume: 0.9,
  sfxMuted: false,
  musicVolume: 0.75,
  musicMuted: false,
  touchMode: 'auto',
  effectsQuality: 'high',
};

function loadSavedSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
    }
  } catch {
    // Ignore invalid JSON
  }
  return DEFAULT_SETTINGS;
}

function loadSavedLanguage(): Language {
  try {
    const saved = localStorage.getItem(LANG_STORAGE_KEY);
    if (saved === 'en' || saved === 'ar') return saved;
  } catch {
    // Ignore storage error
  }
  return 'ar';
}

function loadGuestProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
      return {
        ...createDefaultProfile('guest', 'Shadow Shinobi'),
        ...parsed,
      };
    }
  } catch {
    // Ignore parse error
  }
  return createDefaultProfile('guest', 'Shadow Shinobi');
}

function applyXpAndLevel(profile: PlayerProfile, gainedXp: number): PlayerProfile {
  let xp = profile.xp + gainedXp;
  let level = profile.level;
  while (xp >= getXpForNextLevel(level) && level < 999) {
    xp -= getXpForNextLevel(level);
    level += 1;
  }
  return { ...profile, xp, level };
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => loadSavedLanguage());
  const [settings, setSettings] = useState<GameSettings>(() => loadSavedSettings());
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<PlayerProfile>(() => loadGuestProfile());
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [inGame, setInGame] = useState(false);
  const [gameMode, setGameMode] = useState<'story' | 'arena'>('story');
  const [activeStageId, setActiveStageId] = useState('1');
  const [activeSeason, setActiveSeason] = useState<SeasonalEvent>(DEFAULT_SEASONAL_EVENT);
  const [mpRoom, setMpRoom] = useState<MultiplayerRoomState | null>(null);
  const [authToast, setAuthToast] = useState<string | null>(null);

  // Startup sequence: Studio Splash -> Auto 20s 3D Story Cutscene -> Title Menu
  const [startupPhase, setStartupPhase] = useState<'splash' | 'cutscene' | 'ready'>('splash');

  // Login Gate after trial play & Profile Name Setup modal state
  const [loginGateOpen, setLoginGateOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  const [pendingRoomCode, setPendingRoomCode] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    const param = new URLSearchParams(window.location.search).get('room');
    if (param && param.trim()) {
      const cleaned = param.trim().toUpperCase().slice(0, 8);
      window.history.replaceState({}, '', window.location.pathname);
      return cleaned;
    }
    return null;
  });

  const guestPlayerIdRef = useRef(`guest_${Math.random().toString(36).slice(2, 8)}`);
  const localPlayerId = user?.uid || guestPlayerIdRef.current;
  const isAdmin = useMemo(() => user?.email === 'gaminbh47@gmail.com', [user]);

  const handleBootComplete = useCallback(() => {
    if (pendingRoomCode) {
      setStartupPhase('ready');
      setActiveModal('multiplayer');
    } else {
      setStartupPhase('cutscene');
    }
  }, [pendingRoomCode]);

  const handleCutsceneFinish = useCallback(() => {
    setStartupPhase('ready');
  }, []);

  // Keep SoundEngine & localStorage synced with GameSettings
  useEffect(() => {
    soundEngine.applySettings(settings);
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage quota issues
    }
  }, [settings]);

  // Pre-unlock Web Audio if the user interacts during the initial boot splash
  useEffect(() => {
    if (startupPhase !== 'splash') return;
    const unlockOnGesture = () => {
      void soundEngine.unlockAudio();
    };
    window.addEventListener('pointerdown', unlockOnGesture, { once: true, passive: true });
    window.addEventListener('keydown', unlockOnGesture, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlockOnGesture);
      window.removeEventListener('keydown', unlockOnGesture);
    };
  }, [startupPhase]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try {
      localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      // Ignore storage error
    }
  }, [lang]);

  useEffect(() => {
    fetchActiveSeasons().then((seasons) => {
      if (seasons.length > 0) {
        setActiveSeason(seasons[0]);
      }
    });
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        setLoginGateOpen(false);
        try {
          const cloudProfile = await loadOrCreatePlayerProfile(firebaseUser);
          setProfile(cloudProfile);
          await upsertLeaderboardEntry(cloudProfile);

          // Show in-game warrior profile name setup if first time signing in
          const setupDone = localStorage.getItem(`${PROFILE_DONE_PREFIX}${firebaseUser.uid}`) === 'true';
          if (!setupDone) {
            setProfileModalOpen(true);
          }
        } catch (err) {
          console.error('Cloud load failed:', err);
        }
      } else {
        setProfile(loadGuestProfile());
      }
    });
    return () => unsubscribe();
  }, []);

  const persistProfile = useCallback(
    async (next: PlayerProfile, syncLeaderboard = false) => {
      setProfile(next);
      if (user) {
        try {
          await savePlayerProfile(next);
          if (syncLeaderboard) {
            await upsertLeaderboardEntry(next);
          }
        } catch (err) {
          console.error('Cloud save error:', err);
        }
      } else {
        try {
          localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(next));
        } catch {
          // Ignore storage quota issues
        }
      }
    },
    [user]
  );

  const handleGoogleSignIn = async () => {
    try {
      setAuthToast(null);
      await signInWithGooglePopup();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in failed';
      if (!msg.includes('popup-closed-by-user')) {
        setAuthToast(msg);
      }
    }
  };

  const handleSignOut = async () => {
    await signOutFirebase();
    setActiveModal(null);
    setInGame(false);
  };

  const handleSaveProfileName = async (newName: string) => {
    const next: PlayerProfile = {
      ...profile,
      displayName: newName.slice(0, 40),
    };
    await persistProfile(next, true);
    if (user) {
      localStorage.setItem(`${PROFILE_DONE_PREFIX}${user.uid}`, 'true');
    }
    setProfileModalOpen(false);
  };

  const handleLaunchStage = (stageId: string, clearMp = true, mode: 'story' | 'arena' = 'story') => {
    if (clearMp && mpRoom) {
      multiplayerClient.leaveRoom();
      setMpRoom(null);
    }
    setGameMode(mode);
    setActiveStageId(stageId);
    setActiveModal(null);
    setInGame(true);
  };

  const handleStageComplete = (result: MatchResult) => {
    setProfile((prev) => {
      let next: PlayerProfile = {
        ...prev,
        gems: prev.gems + result.gemsEarned,
        totalScore: prev.totalScore + result.score,
      };
      next = applyXpAndLevel(next, result.xpEarned);

      if (result.victory) {
        const stageNum = Number(result.stageId);
        if (!Number.isNaN(stageNum)) {
          next.highestStage = Math.max(next.highestStage, Math.min(5, stageNum + 1));
        }
        if (result.isSeasonal && !next.completedSeasons.includes(activeSeason.id)) {
          next.completedSeasons = [...next.completedSeasons, activeSeason.id];
          next.gems += activeSeason.rewardGems;
          next = applyXpAndLevel(next, activeSeason.rewardXp);
        }
      }

      void persistProfile(next, true);
      return next;
    });
  };

  const handleWeaponChanged = (weaponId: WeaponId) => {
    setProfile((prev) => {
      const next = { ...prev, equippedWeapon: weaponId };
      void persistProfile(next, false);
      return next;
    });
  };

  const handleClaimDaily = (gems: number, xp: number, newStreak: number, todayKey: string) => {
    let next: PlayerProfile = {
      ...profile,
      gems: profile.gems + gems,
      dailyStreak: newStreak,
      lastDailyClaimDay: todayKey,
    };
    next = applyXpAndLevel(next, xp);
    void persistProfile(next, true);
  };

  const t = getText(lang);

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#090D16] text-slate-100">
      {authToast && (
        <div className="fixed top-4 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-rose-700 bg-slate-950 px-4 py-2.5 text-xs text-rose-200 shadow-xl">
          {authToast}
        </div>
      )}

      {startupPhase === 'splash' ? (
        <SplashLoader lang={lang} onComplete={handleBootComplete} />
      ) : startupPhase === 'cutscene' ? (
        <StoryCutscene3D lang={lang} onFinish={handleCutsceneFinish} />
      ) : !inGame ? (
        <TitleScreen
          profile={profile}
          lang={lang}
          isSignedIn={Boolean(user)}
          onGoogleSignIn={handleGoogleSignIn}
          onSignOut={handleSignOut}
          onEditProfile={() => setProfileModalOpen(true)}
          onStartQuickPlay={() => handleLaunchStage(String(Math.min(5, profile.highestStage)), true, 'story')}
          onStartArena={() => handleLaunchStage('arena', true, 'arena')}
          onOpenModal={(m) => setActiveModal(m)}
        />
      ) : gameMode === 'arena' ? (
        <ArenaCanvas
          profile={profile}
          lang={lang}
          multiplayerRoom={mpRoom}
          localPlayerId={localPlayerId}
          touchMode={settings.touchMode}
          effectsQuality={settings.effectsQuality}
          onMatchComplete={handleStageComplete}
          onExitToTitle={() => {
            if (mpRoom) {
              multiplayerClient.leaveRoom();
              setMpRoom(null);
            }
            setInGame(false);
          }}
        />
      ) : (
        <GameCanvas
          profile={profile}
          stageId={activeStageId}
          lang={lang}
          seasonalEvent={activeSeason}
          multiplayerRoom={mpRoom}
          localPlayerId={localPlayerId}
          isSignedIn={Boolean(user)}
          touchMode={settings.touchMode}
          effectsQuality={settings.effectsQuality}
          onWeaponChanged={handleWeaponChanged}
          onTrialGateReached={() => setLoginGateOpen(true)}
          onStageComplete={handleStageComplete}
          onExitToTitle={() => {
            if (mpRoom) {
              multiplayerClient.leaveRoom();
              setMpRoom(null);
            }
            setInGame(false);
          }}
          onSelectStage={(nextId) => setActiveStageId(nextId)}
        />
      )}

      {activeModal === 'settings' && (
        <GameSettingsModal
          settings={settings}
          lang={lang}
          onUpdateSettings={setSettings}
          onChangeLanguage={setLang}
          onResetDefaults={() => setSettings(DEFAULT_SETTINGS)}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'stages' && (
        <StoryStageModal
          profile={profile}
          lang={lang}
          onSelectStage={(id) => handleLaunchStage(id)}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'shop' && (
        <DojoShopModal
          profile={profile}
          lang={lang}
          onUpdateProfile={(next) => void persistProfile(next, true)}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'daily' && (
        <DailyRewardsModal
          profile={profile}
          lang={lang}
          onClaim={handleClaimDaily}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'leaderboard' && (
        <LeaderboardModal
          currentUid={user?.uid}
          lang={lang}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'multiplayer' && (
        <MultiplayerModal
          profile={profile}
          localPlayerId={localPlayerId}
          lang={lang}
          room={mpRoom}
          initialJoinCode={pendingRoomCode}
          onConsumeInitialJoinCode={() => setPendingRoomCode(null)}
          onRoomChange={setMpRoom}
          onMatchStart={(startedRoom) => {
            setMpRoom(startedRoom);
            handleLaunchStage(
              startedRoom.stageId,
              false,
              startedRoom.mode === 'arena' ? 'arena' : 'story'
            );
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'seasonal' && (
        <SeasonalUpdatesModal
          profile={profile}
          lang={lang}
          activeSeason={activeSeason}
          isAdmin={isAdmin}
          onLaunchSeasonal={() => handleLaunchStage('seasonal')}
          onSeasonPublished={(next) => {
            setActiveSeason(next);
            setAuthToast(t.cloudSaved);
            setTimeout(() => setAuthToast(null), 2500);
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* Mandatory Login Gate after short guest trial */}
      {loginGateOpen && !user && (
        <ProfileSetupModal
          mode="login_gate"
          lang={lang}
          initialName={profile.displayName}
          onGoogleSignIn={handleGoogleSignIn}
          onSaveProfileName={handleSaveProfileName}
          onClose={() => {
            setLoginGateOpen(false);
            setInGame(false);
          }}
        />
      )}

      {/* Warrior Profile Name Setup after Google Sign-In or Edit */}
      {profileModalOpen && user && (
        <ProfileSetupModal
          mode="profile_name"
          lang={lang}
          initialName={profile.displayName}
          allowClose={localStorage.getItem(`${PROFILE_DONE_PREFIX}${user.uid}`) === 'true'}
          onGoogleSignIn={handleGoogleSignIn}
          onSaveProfileName={handleSaveProfileName}
          onClose={() => setProfileModalOpen(false)}
        />
      )}
    </div>
  );
}
