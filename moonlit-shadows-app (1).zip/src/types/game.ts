export type Language = 'ar' | 'en';

export type WeaponId = 'katana' | 'kodachi' | 'kusarigama' | 'odachi';
export type SkinId = 'obsidian' | 'crimson_oni' | 'moon_jade' | 'eclipse_gold';
export type SeasonalModifier = 'blood_moon' | 'low_gravity' | 'shadow_rush';
export type GameScreenState = 'TITLE' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'GAME_OVER';
export type ActiveModal =
  | null
  | 'stages'
  | 'shop'
  | 'daily'
  | 'leaderboard'
  | 'multiplayer'
  | 'seasonal'
  | 'settings';

export type TouchDisplayMode = 'auto' | 'on' | 'off';
export type EffectsQuality = 'high' | 'balanced';

export interface GameSettings {
  sfxVolume: number;
  sfxMuted: boolean;
  musicVolume: number;
  musicMuted: boolean;
  touchMode: TouchDisplayMode;
  effectsQuality: EffectsQuality;
}

export interface WeaponDefinition {
  id: WeaponId;
  nameAr: string;
  nameEn: string;
  styleAr: string;
  styleEn: string;
  specialNameAr: string;
  specialNameEn: string;
  specialDescAr: string;
  specialDescEn: string;
  damage: number;
  speedMultiplier: number;
  range: number;
  specialCooldown: number;
  slashColor: string;
  accentColor: string;
  costGems: number;
  imageUrl: string;
}

export interface SkinDefinition {
  id: SkinId;
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  suitColor: string;
  trimColor: string;
  scarfColor: string;
  eyeColor: string;
  trailColor: string;
  costGems: number;
}

export interface SkillDefinition {
  key: 'skillHealth' | 'skillDash' | 'skillAttack' | 'skillXp';
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  maxRank: number;
  baseCost: number;
}

export interface PlayerProfile {
  uid: string;
  displayName: string;
  photoUrl: string;
  gems: number;
  xp: number;
  level: number;
  highestStage: number;
  totalScore: number;
  equippedWeapon: WeaponId;
  unlockedWeapons: WeaponId[];
  equippedSkin: SkinId;
  unlockedSkins: SkinId[];
  skillHealth: number;
  skillDash: number;
  skillAttack: number;
  skillXp: number;
  dailyStreak: number;
  lastDailyClaimDay: string;
  completedSeasons: string[];
}

export interface LeaderboardEntry {
  uid: string;
  displayName: string;
  score: number;
  level: number;
  highestStage: number;
  equippedWeapon: WeaponId;
  equippedSkin: SkinId;
}

export interface SeasonalEvent {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  modifier: SeasonalModifier;
  rewardGems: number;
  rewardXp: number;
  isActive: boolean;
  versionTag: string;
}

export interface StageConfig {
  id: string;
  order: number;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  storyIntroAr: string;
  storyIntroEn: string;
  storyOutroAr: string;
  storyOutroEn: string;
  challengeTagAr: string;
  challengeTagEn: string;
  bossNameAr: string;
  bossNameEn: string;
  difficulty: number;
  lengthPx: number;
  skyTop: string;
  skyBottom: string;
  moonColor: string;
  rewardGems: number;
  rewardXp: number;
}

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  dashCharge: number; // 0..1
  specialCharge: number; // 0..1
  combo: number;
  gemsCollected: number;
  xpCollected: number;
  score: number;
  progress: number; // 0..100
  bossActive: boolean;
  bossNameAr: string;
  bossNameEn: string;
  bossHp: number;
  bossMaxHp: number;
  elapsedSec: number;
  equippedWeapon: WeaponId;
}

export interface MatchResult {
  victory: boolean;
  stageId: string;
  score: number;
  gemsEarned: number;
  xpEarned: number;
  elapsedSec: number;
  bossDefeated: boolean;
  isSeasonal: boolean;
}

export type ArenaGunId = 'shuriken_smg' | 'venom_kunai' | 'fire_crossbow' | 'dragon_cannon';

export interface ArenaKillEvent {
  id: string;
  killerName: string;
  victimName: string;
  weaponLabel: string;
  timestampMs: number;
}

export interface ArenaStandingsEntry {
  id: string;
  name: string;
  kills: number;
  deaths: number;
  isLocal: boolean;
  isBot: boolean;
}

export interface ArenaWeaponSlotSnapshot {
  gunId: ArenaGunId;
  ammo: number;
  maxAmmo: number;
  reloading: boolean;
  reloadProgress: number;
}

export interface ArenaHudSnapshot {
  hp: number;
  maxHp: number;
  fuel: number;
  maxFuel: number;
  gunId: ArenaGunId;
  ammo: number;
  maxAmmo: number;
  reloading: boolean;
  reloadProgress: number;
  weapons: [ArenaWeaponSlotSnapshot, ArenaWeaponSlotSnapshot | null];
  activeWeaponSlot: 0 | 1;
  grenades: number;
  kills: number;
  deaths: number;
  killTarget: number;
  winReason?: 'target_reached' | 'time_up';
  winnerName?: string;
  timeRemainingSec: number;
  respawnRemainingSec: number;
  killFeed: ArenaKillEvent[];
  standings: ArenaStandingsEntry[];
}

export interface RoomPlayer {
  id: string;
  displayName: string;
  weapon: WeaponId;
  skin: SkinId;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  action: string;
  hp: number;
  maxHp: number;
  score: number;
  progress: number;
  ready: boolean;
  finished: boolean;
  finishTimeMs: number | null;
  aimAngle?: number;
  jetpackActive?: boolean;
  kills?: number;
  deaths?: number;
  arenaGun?: ArenaGunId;
  alive?: boolean;
}

export interface MultiplayerRoomState {
  code: string;
  hostId: string;
  mode: 'coop' | 'competitive' | 'arena';
  stageId: string;
  status: 'waiting' | 'playing' | 'finished';
  bossHp: number;
  bossMaxHp: number;
  startTimeMs: number | null;
  winnerId: string | null;
  players: RoomPlayer[];
}
