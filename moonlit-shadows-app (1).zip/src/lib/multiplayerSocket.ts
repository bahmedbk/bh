import type { ArenaGunId, MultiplayerRoomState, RoomPlayer, SkinId, WeaponId } from '../types/game';

export type WsEventHandlers = {
  onConnected?: (connected: boolean) => void;
  onRoomJoined?: (playerId: string, room: MultiplayerRoomState) => void;
  onRoomState?: (room: MultiplayerRoomState) => void;
  onMatchStarted?: (room: MultiplayerRoomState) => void;
  onPeerState?: (player: RoomPlayer) => void;
  onBossSync?: (bossHp: number, bossMaxHp: number) => void;
  onPvpHit?: (targetId: string, damage: number) => void;
  onArenaShot?: (payload: {
    shooterId: string;
    x: number;
    y: number;
    angle: number;
    gunId: ArenaGunId;
  }) => void;
  onArenaGrenade?: (payload: {
    throwerId: string;
    x: number;
    y: number;
    vx: number;
    vy: number;
  }) => void;
  onArenaHit?: (payload: {
    attackerId: string;
    targetId: string;
    damage: number;
    weaponLabel: string;
  }) => void;
  onArenaKill?: (payload: {
    killerId: string;
    killerName: string;
    victimId: string;
    victimName: string;
    weaponLabel: string;
    droppedGun?: ArenaGunId;
    victimX?: number;
    victimY?: number;
    room: MultiplayerRoomState;
  }) => void;
  onMatchVictory?: (payload: {
    mode: 'coop' | 'competitive' | 'arena';
    winnerId: string;
    winReason?: 'target_reached' | 'time_up';
    elapsedMs: number;
    room: MultiplayerRoomState;
  }) => void;
  onError?: (code: string) => void;
};

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private handlers: WsEventHandlers = {};

  public setHandlers(handlers: WsEventHandlers) {
    this.handlers = handlers;
  }

  public connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    this.ws = new WebSocket(url);

    this.ws.onopen = () => {
      this.handlers.onConnected?.(true);
    };

    this.ws.onclose = () => {
      this.handlers.onConnected?.(false);
    };

    this.ws.onmessage = (evt) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(evt.data);
      } catch {
        return;
      }

      const type = String(msg.type || '');
      if (type === 'room_joined') {
        this.handlers.onRoomJoined?.(String(msg.playerId), msg.room as MultiplayerRoomState);
      } else if (type === 'room_state') {
        this.handlers.onRoomState?.(msg.room as MultiplayerRoomState);
      } else if (type === 'match_started') {
        this.handlers.onMatchStarted?.(msg.room as MultiplayerRoomState);
      } else if (type === 'peer_state') {
        this.handlers.onPeerState?.(msg.player as RoomPlayer);
      } else if (type === 'boss_sync') {
        this.handlers.onBossSync?.(Number(msg.bossHp), Number(msg.bossMaxHp));
      } else if (type === 'pvp_hit') {
        this.handlers.onPvpHit?.(String(msg.targetId), Number(msg.damage));
      } else if (type === 'arena_shot') {
        this.handlers.onArenaShot?.({
          shooterId: String(msg.shooterId),
          x: Number(msg.x || 0),
          y: Number(msg.y || 0),
          angle: Number(msg.angle || 0),
          gunId: (String(msg.gunId || 'shuriken_smg') as ArenaGunId),
        });
      } else if (type === 'arena_grenade') {
        this.handlers.onArenaGrenade?.({
          throwerId: String(msg.throwerId),
          x: Number(msg.x || 0),
          y: Number(msg.y || 0),
          vx: Number(msg.vx || 0),
          vy: Number(msg.vy || 0),
        });
      } else if (type === 'arena_hit') {
        this.handlers.onArenaHit?.({
          attackerId: String(msg.attackerId),
          targetId: String(msg.targetId),
          damage: Number(msg.damage || 0),
          weaponLabel: String(msg.weaponLabel || 'Shuriken'),
        });
      } else if (type === 'arena_kill') {
        this.handlers.onArenaKill?.({
          killerId: String(msg.killerId),
          killerName: String(msg.killerName || 'Shinobi'),
          victimId: String(msg.victimId),
          victimName: String(msg.victimName || 'Shinobi'),
          weaponLabel: String(msg.weaponLabel || 'Shuriken'),
          droppedGun: (String(msg.droppedGun || 'shuriken_smg') as ArenaGunId),
          victimX: Number(msg.victimX || 1200),
          victimY: Number(msg.victimY || 900),
          room: msg.room as MultiplayerRoomState,
        });
      } else if (type === 'match_victory') {
        this.handlers.onMatchVictory?.({
          mode:
            msg.mode === 'arena'
              ? 'arena'
              : msg.mode === 'competitive'
              ? 'competitive'
              : 'coop',
          winnerId: String(msg.winnerId),
          winReason: msg.winReason === 'target_reached' ? 'target_reached' : 'time_up',
          elapsedMs: Number(msg.elapsedMs || 0),
          room: msg.room as MultiplayerRoomState,
        });
      } else if (type === 'room_error') {
        this.handlers.onError?.(String(msg.code || 'UNKNOWN'));
      }
    };
  }

  private send(payload: unknown) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  public createRoom(params: {
    playerId: string;
    displayName: string;
    mode: 'coop' | 'competitive' | 'arena';
    stageId: string;
    weapon: WeaponId;
    skin: SkinId;
  }) {
    this.connect();
    const attempt = () => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.send({ type: 'create_room', ...params });
      } else {
        setTimeout(attempt, 120);
      }
    };
    attempt();
  }

  public joinRoom(params: {
    code: string;
    playerId: string;
    displayName: string;
    weapon: WeaponId;
    skin: SkinId;
  }) {
    this.connect();
    const attempt = () => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.send({ type: 'join_room', ...params });
      } else {
        setTimeout(attempt, 120);
      }
    };
    attempt();
  }

  public updateRoomSettings(mode: 'coop' | 'competitive' | 'arena', stageId: string) {
    this.send({ type: 'update_room_settings', mode, stageId });
  }

  public startMatch() {
    this.send({ type: 'start_match' });
  }

  public sendPlayerState(payload: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    facing: number;
    action: string;
    weapon: WeaponId;
    skin: SkinId;
    hp: number;
    maxHp: number;
    score: number;
    progress: number;
    aimAngle?: number;
    jetpackActive?: boolean;
    arenaGun?: ArenaGunId;
    alive?: boolean;
  }) {
    this.send({ type: 'player_state', ...payload });
  }

  public sendBossDamage(damage: number) {
    this.send({ type: 'boss_damage', damage });
  }

  public sendPvpSlash(targetId: string, damage: number) {
    this.send({ type: 'pvp_slash', targetId, damage });
  }

  public sendArenaShot(x: number, y: number, angle: number, gunId: ArenaGunId) {
    this.send({ type: 'arena_shot', x, y, angle, gunId });
  }

  public sendArenaGrenade(x: number, y: number, vx: number, vy: number) {
    this.send({ type: 'arena_grenade', x, y, vx, vy });
  }

  public sendArenaHit(targetId: string, damage: number, weaponLabel: string) {
    this.send({ type: 'arena_hit', targetId, damage, weaponLabel });
  }

  public sendArenaKill(killerId: string, weaponLabel: string, droppedGun?: ArenaGunId) {
    this.send({ type: 'arena_kill', killerId, weaponLabel, droppedGun });
  }

  public sendArenaFinish() {
    this.send({ type: 'arena_finish' });
  }

  public sendStageFinished(score: number) {
    this.send({ type: 'stage_finished', score });
  }

  public leaveRoom() {
    this.send({ type: 'leave_room' });
  }

  public disconnect() {
    this.leaveRoom();
    this.ws?.close();
    this.ws = null;
  }
}

export const multiplayerClient = new MultiplayerClient();
