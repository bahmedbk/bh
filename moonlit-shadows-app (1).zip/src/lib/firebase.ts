import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { createDefaultProfile } from '../data/gameCatalog';
import type {
  LeaderboardEntry,
  PlayerProfile,
  SeasonalEvent,
  SkinId,
  WeaponId,
} from '../types/game';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
void testConnection();

export async function signInWithGooglePopup(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutFirebase(): Promise<void> {
  await signOut(auth);
}

const VALID_WEAPONS: WeaponId[] = ['katana', 'kodachi', 'kusarigama', 'odachi'];
const VALID_SKINS: SkinId[] = ['obsidian', 'crimson_oni', 'moon_jade', 'eclipse_gold'];

function sanitizeProfilePayload(profile: PlayerProfile) {
  const safeName = (profile.displayName || 'Shinobi').trim().slice(0, 40) || 'Shinobi';
  const safePhoto = (profile.photoUrl || '').slice(0, 500);
  const safeWeapon: WeaponId = VALID_WEAPONS.includes(profile.equippedWeapon)
    ? profile.equippedWeapon
    : 'katana';
  const safeSkin: SkinId = VALID_SKINS.includes(profile.equippedSkin)
    ? profile.equippedSkin
    : 'obsidian';

  const unlockedWeapons = Array.from(
    new Set(profile.unlockedWeapons.filter((w) => VALID_WEAPONS.includes(w)))
  );
  if (unlockedWeapons.length === 0) unlockedWeapons.push('katana');

  const unlockedSkins = Array.from(
    new Set(profile.unlockedSkins.filter((s) => VALID_SKINS.includes(s)))
  );
  if (unlockedSkins.length === 0) unlockedSkins.push('obsidian');

  return {
    uid: profile.uid.slice(0, 128),
    displayName: safeName,
    photoUrl: safePhoto,
    gems: Math.max(0, Math.min(10000000, Math.floor(profile.gems))),
    xp: Math.max(0, Math.min(100000000, Math.floor(profile.xp))),
    level: Math.max(1, Math.min(999, Math.floor(profile.level))),
    highestStage: Math.max(1, Math.min(50, Math.floor(profile.highestStage))),
    totalScore: Math.max(0, Math.min(1000000000, Math.floor(profile.totalScore))),
    equippedWeapon: safeWeapon,
    unlockedWeapons: unlockedWeapons.slice(0, 4),
    equippedSkin: safeSkin,
    unlockedSkins: unlockedSkins.slice(0, 4),
    skillHealth: Math.max(0, Math.min(10, Math.floor(profile.skillHealth))),
    skillDash: Math.max(0, Math.min(10, Math.floor(profile.skillDash))),
    skillAttack: Math.max(0, Math.min(10, Math.floor(profile.skillAttack))),
    skillXp: Math.max(0, Math.min(10, Math.floor(profile.skillXp))),
    dailyStreak: Math.max(0, Math.min(365, Math.floor(profile.dailyStreak))),
    lastDailyClaimDay: (profile.lastDailyClaimDay || '').slice(0, 20),
    completedSeasons: Array.from(new Set(profile.completedSeasons)).slice(0, 50),
  };
}

export async function loadOrCreatePlayerProfile(user: User): Promise<PlayerProfile> {
  const path = `players/${user.uid}`;
  const ref = doc(db, 'players', user.uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data();
      const base = createDefaultProfile(user.uid, user.displayName || 'Shinobi', user.photoURL || '');
      return {
        ...base,
        displayName: String(data.displayName || base.displayName),
        photoUrl: String(data.photoUrl || base.photoUrl),
        gems: Number(data.gems ?? base.gems),
        xp: Number(data.xp ?? base.xp),
        level: Number(data.level ?? base.level),
        highestStage: Number(data.highestStage ?? base.highestStage),
        totalScore: Number(data.totalScore ?? base.totalScore),
        equippedWeapon: VALID_WEAPONS.includes(data.equippedWeapon)
          ? data.equippedWeapon
          : 'katana',
        unlockedWeapons: Array.isArray(data.unlockedWeapons)
          ? data.unlockedWeapons
          : ['katana'],
        equippedSkin: VALID_SKINS.includes(data.equippedSkin) ? data.equippedSkin : 'obsidian',
        unlockedSkins: Array.isArray(data.unlockedSkins) ? data.unlockedSkins : ['obsidian'],
        skillHealth: Number(data.skillHealth ?? 0),
        skillDash: Number(data.skillDash ?? 0),
        skillAttack: Number(data.skillAttack ?? 0),
        skillXp: Number(data.skillXp ?? 0),
        dailyStreak: Number(data.dailyStreak ?? 0),
        lastDailyClaimDay: String(data.lastDailyClaimDay ?? ''),
        completedSeasons: Array.isArray(data.completedSeasons) ? data.completedSeasons : [],
      };
    }

    const fresh = createDefaultProfile(user.uid, user.displayName || 'Shinobi', user.photoURL || '');
    const payload = sanitizeProfilePayload(fresh);
    await setDoc(ref, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return fresh;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function savePlayerProfile(profile: PlayerProfile): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== profile.uid) return;
  const path = `players/${profile.uid}`;
  const ref = doc(db, 'players', profile.uid);
  const payload = sanitizeProfilePayload(profile);
  const { uid: _uid, ...updatableFields } = payload;

  try {
    await updateDoc(ref, {
      ...updatableFields,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    // Fallback if doc wasn't created yet
    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, {
          ...payload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return;
      }
      handleFirestoreError(error, OperationType.UPDATE, path);
    } catch (innerError) {
      handleFirestoreError(innerError, OperationType.WRITE, path);
    }
  }
}

export async function upsertLeaderboardEntry(profile: PlayerProfile): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== profile.uid) return;
  const path = `leaderboard/${profile.uid}`;
  const ref = doc(db, 'leaderboard', profile.uid);
  const sanitized = sanitizeProfilePayload(profile);

  const entryPayload = {
    uid: sanitized.uid,
    displayName: sanitized.displayName,
    score: sanitized.totalScore,
    level: sanitized.level,
    highestStage: sanitized.highestStage,
    equippedWeapon: sanitized.equippedWeapon,
    equippedSkin: sanitized.equippedSkin,
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(ref, entryPayload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function fetchGlobalLeaderboard(): Promise<LeaderboardEntry[]> {
  const path = 'leaderboard';
  try {
    const q = query(
      collection(db, path),
      where('score', '>=', 0),
      orderBy('score', 'desc'),
      limit(25)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        uid: String(data.uid || d.id),
        displayName: String(data.displayName || 'Shinobi'),
        score: Number(data.score || 0),
        level: Number(data.level || 1),
        highestStage: Number(data.highestStage || 1),
        equippedWeapon: VALID_WEAPONS.includes(data.equippedWeapon)
          ? data.equippedWeapon
          : 'katana',
        equippedSkin: VALID_SKINS.includes(data.equippedSkin) ? data.equippedSkin : 'obsidian',
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function fetchActiveSeasons(): Promise<SeasonalEvent[]> {
  const path = 'seasons';
  try {
    const q = query(collection(db, path), where('isActive', '==', true), limit(5));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: String(data.id || d.id),
        titleAr: String(data.titleAr || ''),
        titleEn: String(data.titleEn || ''),
        descriptionAr: String(data.descriptionAr || ''),
        descriptionEn: String(data.descriptionEn || ''),
        modifier:
          data.modifier === 'low_gravity' || data.modifier === 'shadow_rush'
            ? data.modifier
            : 'blood_moon',
        rewardGems: Number(data.rewardGems || 150),
        rewardXp: Number(data.rewardXp || 500),
        isActive: Boolean(data.isActive),
        versionTag: String(data.versionTag || 'v1.4'),
      };
    });
  } catch {
    return [];
  }
}

export async function publishSeasonalUpdate(event: SeasonalEvent): Promise<void> {
  const safeId = event.id.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64) || 'season_1';
  const path = `seasons/${safeId}`;
  try {
    await setDoc(doc(db, 'seasons', safeId), {
      id: safeId,
      titleAr: event.titleAr.slice(0, 80),
      titleEn: event.titleEn.slice(0, 80),
      descriptionAr: event.descriptionAr.slice(0, 300),
      descriptionEn: event.descriptionEn.slice(0, 300),
      modifier: event.modifier,
      rewardGems: Math.max(0, Math.min(10000, Math.floor(event.rewardGems))),
      rewardXp: Math.max(0, Math.min(100000, Math.floor(event.rewardXp))),
      isActive: true,
      versionTag: event.versionTag.slice(0, 24),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
