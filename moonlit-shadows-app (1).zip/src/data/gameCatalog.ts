import weaponKatanaUrl from '../assets/images/weapon_shadow_katana_1794530689320.jpg';
import weaponKodachiUrl from '../assets/images/weapon_twin_kodachi_1794530689134.jpg';
import weaponKusarigamaUrl from '../assets/images/weapon_kusarigama_chain_1794530689694.jpg';
import weaponOdachiUrl from '../assets/images/weapon_lunar_odachi_1794530690117.jpg';
import type {
  PlayerProfile,
  SeasonalEvent,
  SkillDefinition,
  SkinDefinition,
  StageConfig,
  WeaponDefinition,
} from '../types/game';

export const WEAPONS: WeaponDefinition[] = [
  {
    id: 'katana',
    nameAr: 'كاتانا الظل',
    nameEn: 'Shadow Katana',
    styleAr: 'توازن مثالي — ضربات قمرية متسلسلة من 3 حركات',
    styleEn: 'Balanced — Crisp 3-hit moonlit slash combo',
    specialNameAr: 'موجة الهلال القاطعة',
    specialNameEn: 'Crescent Moon Wave',
    specialDescAr: 'تطلق موجة طاقة قاطعة تخترق الأعداء عبر المنصات',
    specialDescEn: 'Fires a piercing lunar crescent wave across platforms',
    damage: 26,
    speedMultiplier: 1.0,
    range: 74,
    specialCooldown: 4.5,
    slashColor: '#E2E8F0',
    accentColor: '#38BDF8',
    costGems: 0,
    imageUrl: weaponKatanaUrl,
  },
  {
    id: 'kodachi',
    nameAr: 'خناجر التوأم',
    nameEn: 'Twin Kodachi',
    styleAr: 'سرعة خاطفة — وابل طعنات مزدوج مع خفة حركة',
    styleEn: 'Hyper-Speed — Rapid twin flurry with agile recovery',
    specialNameAr: 'وميض الاغتيال',
    specialNameEn: 'Shadow Blink Strike',
    specialDescAr: 'اندفاعة فورية تقطع مسافة وتضرب جميع الأعداء في المسار',
    specialDescEn: 'Instant phantom dash slashing every foe along your path',
    damage: 19,
    speedMultiplier: 1.55,
    range: 58,
    specialCooldown: 3.6,
    slashColor: '#FDA4AF',
    accentColor: '#E11D48',
    costGems: 90,
    imageUrl: weaponKodachiUrl,
  },
  {
    id: 'kusarigama',
    nameAr: 'منجل السلسلة',
    nameEn: 'Kusarigama Chain',
    styleAr: 'مدى واسع — تحكم بالمساحة وضرب الأعداء عن بعد',
    styleEn: 'Wide Sweep — Long chain reach for crowd control',
    specialNameAr: 'دوامة العاصفة',
    specialNameEn: 'Whirlwind Vortex',
    specialDescAr: 'دوران سلسلي 360° يضرب جميع الأعداء المحيطين ويكسر توازنهم',
    specialDescEn: '360-degree chain cyclone hitting all surrounding foes',
    damage: 24,
    speedMultiplier: 0.92,
    range: 108,
    specialCooldown: 5.0,
    slashColor: '#6EE7B7',
    accentColor: '#10B981',
    costGems: 160,
    imageUrl: weaponKusarigamaUrl,
  },
  {
    id: 'odachi',
    nameAr: 'السيف القمري العظيم',
    nameEn: 'Lunar Odachi',
    styleAr: 'قوة ساحقة — ضربات ثقيلة تحطم الدروع وتُجمد الصدمة',
    styleEn: 'Heavy Cleave — Armor-crushing arcs with massive impact',
    specialNameAr: 'صدمة الكسوف',
    specialNameEn: 'Eclipse Ground Slam',
    specialDescAr: 'ضربة أرضية تطلق موجتي صدمة قمرية مدمرتين على الجانبين',
    specialDescEn: 'Shattering slam unleashing twin eclipse shockwaves',
    damage: 42,
    speedMultiplier: 0.72,
    range: 96,
    specialCooldown: 5.8,
    slashColor: '#FDE68A',
    accentColor: '#F59E0B',
    costGems: 260,
    imageUrl: weaponOdachiUrl,
  },
];

export const SKINS: SkinDefinition[] = [
  {
    id: 'obsidian',
    nameAr: 'رداء الظل الكلاسيكي',
    nameEn: 'Obsidian Shinobi',
    descAr: 'ملابس نينجا سوداء تقليدية مع وشاح قرمزي متطاير',
    descEn: 'Traditional black shinobi garb with crimson flowing scarf',
    suitColor: '#0B0E14',
    trimColor: '#334155',
    scarfColor: '#E11D48',
    eyeColor: '#F8FAFC',
    trailColor: 'rgba(225, 29, 72, 0.45)',
    costGems: 0,
  },
  {
    id: 'crimson_oni',
    nameAr: 'شبح الأوني القرمزي',
    nameEn: 'Crimson Oni',
    descAr: 'درع قتالي داكن بقناع شياطين قرمزي ووشاح متوهج',
    descEn: 'Dark armored weave with demon crimson visor & glowing scarf',
    suitColor: '#13090E',
    trimColor: '#9F1239',
    scarfColor: '#FB7185',
    eyeColor: '#FDA4AF',
    trailColor: 'rgba(251, 113, 133, 0.5)',
    costGems: 110,
  },
  {
    id: 'moon_jade',
    nameAr: 'حارس اليشم القمري',
    nameEn: 'Moon Jade Guardian',
    descAr: 'رداء معبد ليلي مطرز بخيوط اليشم المضيئة في الظلام',
    descEn: 'Nocturnal shrine attire woven with luminous jade silk',
    suitColor: '#091514',
    trimColor: '#065F46',
    scarfColor: '#10B981',
    eyeColor: '#6EE7B7',
    trailColor: 'rgba(16, 185, 129, 0.48)',
    costGems: 180,
  },
  {
    id: 'eclipse_gold',
    nameAr: 'سيد الكسوف الذهبي',
    nameEn: 'Golden Eclipse',
    descAr: 'زي أسطوري أسود مزدان بحواف ذهبية ووشاح ناري ملكي',
    descEn: 'Legendary midnight silk inlaid with imperial eclipse gold',
    suitColor: '#100E09',
    trimColor: '#B45309',
    scarfColor: '#F59E0B',
    eyeColor: '#FDE68A',
    trailColor: 'rgba(245, 158, 11, 0.52)',
    costGems: 280,
  },
];

export const SKILLS: SkillDefinition[] = [
  {
    key: 'skillHealth',
    nameAr: 'صلابة الشينوبي',
    nameEn: 'Shinobi Vitality',
    descAr: 'يزيد الحد الأقصى للصحة (+15 لكل مستوى)',
    descEn: 'Increases maximum HP (+15 per rank)',
    maxRank: 10,
    baseCost: 30,
  },
  {
    key: 'skillAttack',
    nameAr: 'إتقان النصل',
    nameEn: 'Blade Mastery',
    descAr: 'يزيد ضرر جميع الأسلحة والمهارات (+10% لكل مستوى)',
    descEn: 'Boosts all weapon & skill damage (+10% per rank)',
    maxRank: 10,
    baseCost: 35,
  },
  {
    key: 'skillDash',
    nameAr: 'خطوة الظل',
    nameEn: 'Shadow Agility',
    descAr: 'يسرّع شحن الاندفاع السريع والمهارة الخاصة (+8% لكل مستوى)',
    descEn: 'Reduces dash & special skill cooldowns (+8% per rank)',
    maxRank: 10,
    baseCost: 30,
  },
  {
    key: 'skillXp',
    nameAr: 'حكمة القمر',
    nameEn: 'Moon Wisdom',
    descAr: 'يزيد نقاط الخبرة والجواهر المكتسبة (+12% لكل مستوى)',
    descEn: 'Increases XP & gem rewards (+12% per rank)',
    maxRank: 10,
    baseCost: 25,
  },
];

export const DAILY_REWARDS = [
  { day: 1, gems: 20, xp: 80 },
  { day: 2, gems: 35, xp: 120 },
  { day: 3, gems: 50, xp: 180 },
  { day: 4, gems: 75, xp: 240 },
  { day: 5, gems: 100, xp: 320 },
  { day: 6, gems: 140, xp: 450 },
  { day: 7, gems: 250, xp: 700 },
];

export const STAGES: StageConfig[] = [
  {
    id: '1',
    order: 1,
    titleAr: 'الفصل الأول: أسطح معبد القمر',
    titleEn: 'Chapter I: Moonlit Pagoda Roofs',
    subtitleAr: 'البداية فوق البلاط الفضي الساكن',
    subtitleEn: 'Silent traversal above silver-washed eaves',
    storyIntroAr:
      'سُرقت لفافة الكسوف من المعبد الأعلى. انطلق عبر أسطح المعبد المغمورة بضوء القمر، وتجاوز حراس الرونين المظلمين للوصول إلى الحارس الأول.',
    storyIntroEn:
      'The Eclipse Scroll was stolen from the High Sanctum. Cross the moon-drenched pagoda roofs and cut down the Shadow Ronin sentries.',
    storyOutroAr:
      'سقط الحارس كوروغاني، لكن صدى خطوات الأعداء يقود نحو جسر الضباب المعلق في السماء.',
    storyOutroEn:
      'Sentinel Kurogane falls, revealing tracks leading toward the mist-shrouded sky bridge.',
    challengeTagAr: 'أسطح منزلقة · حراس رونين',
    challengeTagEn: 'Rooftop leaps · Ronin sentries',
    bossNameAr: 'كوروغاني — حارس البوابة',
    bossNameEn: 'Kurogane, Gate Sentinel',
    difficulty: 1,
    lengthPx: 3400,
    skyTop: '#070B14',
    skyBottom: '#172036',
    moonColor: '#E2E8F0',
    rewardGems: 45,
    rewardXp: 150,
  },
  {
    id: '2',
    order: 2,
    titleAr: 'الفصل الثاني: جسر الضباب العائم',
    titleEn: 'Chapter II: Floating Mist Bridge',
    subtitleAr: 'منصات معلقة ورياح عاتية',
    subtitleEn: 'Suspended lanterns & cutting night winds',
    storyIntroAr:
      'بين السحب الكثيفة تطفو مصابيح المعبد المكسورة. تحكم بقفزاتك بدقة وتجنب سهام الشوريكين أثناء مواجهة سيد الرياح.',
    storyIntroEn:
      'Broken shrine lanterns drift through thick alpine mist. Time every double-jump and dash past shuriken traps.',
    storyOutroAr:
      'تلاشت رياح التينغو، وظهرت أختام البرج القرمزي تلمع في الأفق المظلم.',
    storyOutroEn:
      'The Tengu winds subside, revealing the glowing Crimson Seal Towers ahead.',
    challengeTagAr: 'منصات متحركة · رماة شوريكين',
    challengeTagEn: 'Moving platforms · Shuriken archers',
    bossNameAr: 'تينغو — نصل الرياح',
    bossNameEn: 'Tengu Wind-Blade',
    difficulty: 2,
    lengthPx: 3900,
    skyTop: '#080E1A',
    skyBottom: '#13293D',
    moonColor: '#BAE6FD',
    rewardGems: 65,
    rewardXp: 230,
  },
  {
    id: '3',
    order: 3,
    titleAr: 'الفصل الثالث: أبراج الأختام القرمزية',
    titleEn: 'Chapter III: Crimson Seal Towers',
    subtitleAr: 'قفز جداري وأشواك طاقة متناوبة',
    subtitleEn: 'Wall-jumps & pulsing spirit seals',
    storyIntroAr:
      'في قلب القلعة ترتفع الأبراج المحصنة. تسلق الجدران بالقفز المتتابع واخترق أختام الطاقة بالاندفاع السريع.',
    storyIntroEn:
      'Deep within the fortress stand twin sealed spires. Chain wall-jumps and shadow-dash cleanly through spirit barriers.',
    storyOutroAr:
      'انكسر الختم القرمزي، ولم يبقَ أمامك سوى وادي الظلال الصامتة.',
    storyOutroEn:
      'The crimson seal shatters, opening the descent into the Valley of Silent Shadows.',
    challengeTagAr: 'قفز جداري · بلاطات متهالكة',
    challengeTagEn: 'Wall-jumps · Crumbling tiles',
    bossNameAr: 'الجنرال أكاكاغي',
    bossNameEn: 'General Akakage',
    difficulty: 3,
    lengthPx: 4300,
    skyTop: '#100712',
    skyBottom: '#2B1228',
    moonColor: '#FECDD3',
    rewardGems: 90,
    rewardXp: 340,
  },
  {
    id: '4',
    order: 4,
    titleAr: 'الفصل الرابع: وادي الظلال الصامتة',
    titleEn: 'Chapter IV: Valley of Silent Shadows',
    subtitleAr: 'ساموراي مدرعون ومواجهات خاطفة',
    subtitleEn: 'Armored samurai & high-precision duels',
    storyIntroAr:
      'هنا يتجول الحرس المدرع الذي لا تهزمه الضربات العادية بسهولة. استخدم الاندفاع للالتفاف خلف الدروع أو أطلق مهارتك الخاصة.',
    storyIntroEn:
      'Heavy-armored vanguard guard this canyon. Dash behind their shields or unleash weapon arts to break their stance.',
    storyOutroAr:
      'انتصرت على نائبة الظلام، وأصبح عرش الكسوف على مرمى البصر.',
    storyOutroEn:
      'The mist weaver falls. Only the Throne of the Final Eclipse remains.',
    challengeTagAr: 'أعداء مدرعون · فخاخ متسارعة',
    challengeTagEn: 'Armored foes · High-speed traps',
    bossNameAr: 'يوري — ناسجة الضباب',
    bossNameEn: 'Yurei, Mist Weaver',
    difficulty: 4,
    lengthPx: 4700,
    skyTop: '#061113',
    skyBottom: '#0F292E',
    moonColor: '#A7F3D0',
    rewardGems: 120,
    rewardXp: 460,
  },
  {
    id: '5',
    order: 5,
    titleAr: 'الفصل الخامس: عرش الكسوف الأخير',
    titleEn: 'Chapter V: Throne of the Final Eclipse',
    subtitleAr: 'المعركة الحاسمة لاستعادة لفافة القمر',
    subtitleEn: 'Final showdown to reclaim the Lunar Scroll',
    storyIntroAr:
      'تحت ظل الكسوف التام، ينتظرك الشوغون المظلم اللورد كوروِي. اجمع كل مهاراتك في القفز والاندفاع والقتال لحسم المصير.',
    storyIntroEn:
      'Beneath the total eclipse awaits Lord Kuroi. Bring every ounce of blade precision, agility, and timing to reclaim the scroll.',
    storyOutroAr:
      'عاد النور الفضي إلى أسطح المعابد، وسُجل اسمك بين أساطير الشينوبي الخالدين.',
    storyOutroEn:
      'Silver moonlight returns to the sanctuaries, etching your name among the eternal shinobi legends.',
    challengeTagAr: 'تحدي الدقة الأعلى · زعيم الكسوف',
    challengeTagEn: 'Master gauntlet · Eclipse Shogun',
    bossNameAr: 'اللورد كوروِي — شوغون الكسوف',
    bossNameEn: 'Lord Kuroi, Eclipse Shogun',
    difficulty: 5,
    lengthPx: 5200,
    skyTop: '#09060D',
    skyBottom: '#280D1B',
    moonColor: '#F43F5E',
    rewardGems: 180,
    rewardXp: 680,
  },
];

export const SEASONAL_STAGE_CONFIG: StageConfig = {
  id: 'seasonal',
  order: 6,
  titleAr: 'التحدي الموسمي: معبد الكسوف الدموي',
  titleEn: 'Seasonal Trial: Blood Eclipse Shrine',
  subtitleAr: 'حدث متجدد بمكافآت مضاعفة وقوانين خاصة',
  subtitleEn: 'Rotating live event with boosted rewards & modifiers',
  storyIntroAr:
    'تفتح بوابة الكسوف لفترة محدودة! اختبر مهارتك تحت تأثير التعديل الموسمي النشط واحصد جواهر إضافية.',
  storyIntroEn:
    'The Eclipse Gate opens for a limited time! Conquer the shrine under active seasonal rules for massive gem rewards.',
  storyOutroAr:
    'أتممت التحدي الموسمي ببراعة! تم توثيق إنجازك وإضافة المكافآت إلى رصيدك السحابي.',
  storyOutroEn:
    'Seasonal trial conquered! Your cloud record and bonus rewards have been secured.',
  challengeTagAr: 'تحدي موسمي مباشر · مكافآت مضاعفة',
  challengeTagEn: 'Live Seasonal Event · 2x Rewards',
  bossNameAr: 'ظل الكسوف الأبدي',
  bossNameEn: 'Eternal Eclipse Shade',
  difficulty: 5,
  lengthPx: 4500,
  skyTop: '#12060B',
  skyBottom: '#3B0D1D',
  moonColor: '#E11D48',
  rewardGems: 200,
  rewardXp: 750,
};

export const DEFAULT_SEASONAL_EVENT: SeasonalEvent = {
  id: 'season_eclipse_01',
  titleAr: 'موسم كسوف القمر القرمزي',
  titleEn: 'Crimson Lunar Eclipse Season',
  descriptionAr:
    'سرعة اندفاع مضاعفة وأعداء أشد شراسة تحت ضوء القمر الأحمر — أكمل المرحلة لتحصل على مكافأة موسمية ضخمة.',
  descriptionEn:
    'Heightened agility and relentless shrine guardians under a crimson eclipse — clear the trial for bonus gems & XP.',
  modifier: 'blood_moon',
  rewardGems: 200,
  rewardXp: 750,
  isActive: true,
  versionTag: 'v1.4',
};

export function createDefaultProfile(uid: string, displayName: string, photoUrl = ''): PlayerProfile {
  return {
    uid,
    displayName: displayName.slice(0, 40) || 'Shinobi',
    photoUrl,
    gems: 60,
    xp: 0,
    level: 1,
    highestStage: 1,
    totalScore: 0,
    equippedWeapon: 'katana',
    unlockedWeapons: ['katana'],
    equippedSkin: 'obsidian',
    unlockedSkins: ['obsidian'],
    skillHealth: 0,
    skillDash: 0,
    skillAttack: 0,
    skillXp: 0,
    dailyStreak: 0,
    lastDailyClaimDay: '',
    completedSeasons: [],
  };
}

export function getXpForNextLevel(level: number): number {
  return Math.floor(150 * Math.pow(1.25, Math.max(0, level - 1)));
}

export function getSkillUpgradeCost(skill: SkillDefinition, currentRank: number): number {
  return Math.round(skill.baseCost * Math.pow(1.45, currentRank));
}

export function getStageById(stageId: string): StageConfig {
  if (stageId === 'seasonal') return SEASONAL_STAGE_CONFIG;
  return STAGES.find((s) => s.id === stageId) || STAGES[0];
}
