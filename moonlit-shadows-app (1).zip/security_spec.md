# Security Specification & Invariants

## Data Invariants
1. A `players/{playerId}` document can only be read, created, or updated by the authenticated, email-verified user whose `request.auth.uid == playerId`.
2. `players/{playerId}.uid` and `createdAt` are immutable after creation; `updatedAt` must always equal `request.time`.
3. Numeric progression bounds (`gems`, `xp`, `level`, `highestStage`, `totalScore`, `skill*`, `dailyStreak`) are strictly clamped against negative values or overflow poisoning.
4. `leaderboard/{playerId}` contains zero PII (no email, phone, or IP) and may only be created or updated by `request.auth.uid == playerId`.
5. `seasons/{seasonId}` is read-only for regular players; only verified administrators can create, update, or delete seasonal update records.

## Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated read/write to `/players/uid1` -> Denied (`request.auth == null`).
2. User A writing to `/players/UserB` -> Denied (`playerId != request.auth.uid`).
3. Creating `/players/uid1` with `uid: "other_uid"` -> Denied (`incoming().uid == request.auth.uid`).
4. Creating `/players/uid1` with shadow field `isAdmin: true` -> Denied (`keys().hasOnly(...)`).
5. Updating `/players/uid1` with modified `createdAt` -> Denied (immutable `createdAt`).
6. Updating `/players/uid1` with forged future `updatedAt` -> Denied (`incoming().updatedAt == request.time`).
7. Updating `/players/uid1` with negative `gems: -500` or excessive `skillAttack: 99` -> Denied (range checks).
8. Updating `/players/uid1` with invalid `equippedWeapon: "bazooka"` -> Denied (enum allowlist).
9. Updating `/players/uid1` with 2KB `displayName` -> Denied (`size() <= 40`).
10. Spoofed user with `email_verified: false` writing to `/leaderboard/uid1` -> Denied (`email_verified == true`).
11. User A overwriting `/leaderboard/UserB` with score 999999 -> Denied (`playerId == request.auth.uid`).
12. Non-admin user creating `/seasons/season_hack` -> Denied (`isAdmin()`).
